package android.support.v7.app;

import android.support.v7.internal.a.h;
import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.y;

final class o
  implements y
{
  private o(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase)
  {
  }

  public void a(i parami, boolean paramBoolean)
  {
    i locali = parami.p();
    if (locali != parami);
    ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState;
    for (int i = 1; ; i = 0)
    {
      ActionBarActivityDelegateBase localActionBarActivityDelegateBase = this.a;
      if (i != 0)
        parami = locali;
      localPanelFeatureState = ActionBarActivityDelegateBase.a(localActionBarActivityDelegateBase, parami);
      if (localPanelFeatureState != null)
      {
        if (i == 0)
          break;
        ActionBarActivityDelegateBase.a(this.a, localPanelFeatureState.a, localPanelFeatureState, locali);
        ActionBarActivityDelegateBase.a(this.a, localPanelFeatureState, true);
      }
      return;
    }
    this.a.a.closeOptionsMenu();
    ActionBarActivityDelegateBase.a(this.a, localPanelFeatureState, paramBoolean);
  }

  public boolean a(i parami)
  {
    if ((parami == null) && (this.a.b))
    {
      h localh = this.a.k();
      if ((localh != null) && (!this.a.m()))
        localh.c(8, parami);
    }
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.o
 * JD-Core Version:    0.6.2
 */