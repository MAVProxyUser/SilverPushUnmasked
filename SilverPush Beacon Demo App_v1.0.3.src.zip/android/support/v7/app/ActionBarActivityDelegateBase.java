package android.support.v7.app;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.aq;
import android.support.v4.view.au;
import android.support.v4.view.bn;
import android.support.v7.a.d;
import android.support.v7.internal.widget.ActionBarContextView;
import android.support.v7.internal.widget.ViewStubCompat;
import android.support.v7.internal.widget.as;
import android.support.v7.internal.widget.at;
import android.support.v7.internal.widget.av;
import android.support.v7.internal.widget.ay;
import android.support.v7.internal.widget.ba;
import android.support.v7.internal.widget.bh;
import android.support.v7.internal.widget.w;
import android.support.v7.internal.widget.z;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.PopupWindow;

class ActionBarActivityDelegateBase extends f
  implements android.support.v7.internal.view.menu.j
{
  private boolean A;
  private android.support.v7.internal.view.menu.g B;
  private Rect C;
  private Rect D;
  android.support.v7.b.a g;
  ActionBarContextView h;
  PopupWindow i;
  Runnable j;
  private w k;
  private l l;
  private o m;
  private boolean n;
  private ViewGroup o;
  private ViewGroup p;
  private View q;
  private CharSequence r;
  private boolean s;
  private boolean t;
  private boolean u;
  private ActionBarActivityDelegateBase.PanelFeatureState[] v;
  private ActionBarActivityDelegateBase.PanelFeatureState w;
  private boolean x;
  private int y;
  private final Runnable z = new h(this);

  ActionBarActivityDelegateBase(e parame)
  {
    super(parame);
  }

  private ActionBarActivityDelegateBase.PanelFeatureState a(int paramInt, boolean paramBoolean)
  {
    Object localObject = this.v;
    if ((localObject == null) || (localObject.length <= paramInt))
    {
      ActionBarActivityDelegateBase.PanelFeatureState[] arrayOfPanelFeatureState = new ActionBarActivityDelegateBase.PanelFeatureState[paramInt + 1];
      if (localObject != null)
        System.arraycopy(localObject, 0, arrayOfPanelFeatureState, 0, localObject.length);
      this.v = arrayOfPanelFeatureState;
      localObject = arrayOfPanelFeatureState;
    }
    ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState1 = localObject[paramInt];
    if (localPanelFeatureState1 == null)
    {
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState2 = new ActionBarActivityDelegateBase.PanelFeatureState(paramInt);
      localObject[paramInt] = localPanelFeatureState2;
      return localPanelFeatureState2;
    }
    return localPanelFeatureState1;
  }

  private ActionBarActivityDelegateBase.PanelFeatureState a(Menu paramMenu)
  {
    ActionBarActivityDelegateBase.PanelFeatureState[] arrayOfPanelFeatureState = this.v;
    int i1;
    if (arrayOfPanelFeatureState != null)
      i1 = arrayOfPanelFeatureState.length;
    for (int i2 = 0; ; i2++)
    {
      if (i2 >= i1)
        break label55;
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState = arrayOfPanelFeatureState[i2];
      if ((localPanelFeatureState != null) && (localPanelFeatureState.d == paramMenu))
      {
        return localPanelFeatureState;
        i1 = 0;
        break;
      }
    }
    label55: return null;
  }

  private void a(int paramInt, ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState, Menu paramMenu)
  {
    if (paramMenu == null)
    {
      if ((paramPanelFeatureState == null) && (paramInt >= 0) && (paramInt < this.v.length))
        paramPanelFeatureState = this.v[paramInt];
      if (paramPanelFeatureState != null)
        paramMenu = paramPanelFeatureState.d;
    }
    if ((paramPanelFeatureState != null) && (!paramPanelFeatureState.i))
      return;
    k().b(paramInt, paramMenu);
  }

  private void a(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState)
  {
    paramPanelFeatureState.b = this.o;
    paramPanelFeatureState.a(j());
  }

  private void a(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if ((paramPanelFeatureState.i) || (m()));
    label108: label114: label118: label120: 
    do
    {
      do
        while (true)
        {
          return;
          int i1;
          if (paramPanelFeatureState.a == 0)
          {
            e locale = this.a;
            if ((0xF & locale.getResources().getConfiguration().screenLayout) != 4)
              break label108;
            i1 = 1;
            if (locale.getApplicationInfo().targetSdkVersion < 11)
              break label114;
          }
          for (int i2 = 1; ; i2 = 0)
          {
            if ((i1 != 0) && (i2 != 0))
              break label118;
            android.support.v7.internal.a.h localh = k();
            if ((localh == null) || (localh.c(paramPanelFeatureState.a, paramPanelFeatureState.d)))
              break label120;
            a(paramPanelFeatureState, true);
            return;
            i1 = 0;
            break;
          }
        }
      while (!b(paramPanelFeatureState, paramKeyEvent));
      if ((paramPanelFeatureState.b == null) || (paramPanelFeatureState.k))
        a(paramPanelFeatureState);
    }
    while ((!c(paramPanelFeatureState)) || (!paramPanelFeatureState.a()));
    paramPanelFeatureState.h = false;
    paramPanelFeatureState.i = true;
  }

  private void a(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState, boolean paramBoolean)
  {
    if ((paramBoolean) && (paramPanelFeatureState.a == 0) && (this.k != null) && (this.k.e()))
      b(paramPanelFeatureState.d);
    do
    {
      return;
      if ((paramPanelFeatureState.i) && (paramBoolean))
        a(paramPanelFeatureState.a, paramPanelFeatureState, null);
      paramPanelFeatureState.g = false;
      paramPanelFeatureState.h = false;
      paramPanelFeatureState.i = false;
      paramPanelFeatureState.c = null;
      paramPanelFeatureState.k = true;
    }
    while (this.w != paramPanelFeatureState);
    this.w = null;
  }

  private void a(android.support.v7.internal.view.menu.i parami, boolean paramBoolean)
  {
    if ((this.k != null) && (this.k.d()) && ((!bn.a(ViewConfiguration.get(this.a))) || (this.k.f())))
    {
      android.support.v7.internal.a.h localh = k();
      if ((!this.k.e()) || (!paramBoolean))
        if ((localh != null) && (!m()))
        {
          if ((this.x) && ((0x1 & this.y) != 0))
          {
            this.o.removeCallbacks(this.z);
            this.z.run();
          }
          ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState2 = a(0, true);
          if ((localPanelFeatureState2.d != null) && (!localPanelFeatureState2.l) && (localh.a(0, null, localPanelFeatureState2.d)))
          {
            localh.c(8, localPanelFeatureState2.d);
            this.k.g();
          }
        }
      do
      {
        return;
        this.k.h();
      }
      while (m());
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState3 = a(0, true);
      this.a.onPanelClosed(8, localPanelFeatureState3.d);
      return;
    }
    ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState1 = a(0, true);
    localPanelFeatureState1.k = true;
    a(localPanelFeatureState1, false);
    a(localPanelFeatureState1, null);
  }

  private void b(android.support.v7.internal.view.menu.i parami)
  {
    if (this.u)
      return;
    this.u = true;
    this.k.j();
    android.support.v7.internal.a.h localh = k();
    if ((localh != null) && (!m()))
      localh.b(8, parami);
    this.u = false;
  }

  private boolean b(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState)
  {
    e locale = this.a;
    TypedValue localTypedValue;
    Resources.Theme localTheme1;
    Resources.Theme localTheme2;
    Object localObject;
    if (((paramPanelFeatureState.a == 0) || (paramPanelFeatureState.a == 8)) && (this.k != null))
    {
      localTypedValue = new TypedValue();
      localTheme1 = locale.getTheme();
      localTheme1.resolveAttribute(android.support.v7.a.b.actionBarTheme, localTypedValue, true);
      if (localTypedValue.resourceId != 0)
      {
        localTheme2 = locale.getResources().newTheme();
        localTheme2.setTo(localTheme1);
        localTheme2.applyStyle(localTypedValue.resourceId, true);
        localTheme2.resolveAttribute(android.support.v7.a.b.actionBarWidgetTheme, localTypedValue, true);
        if (localTypedValue.resourceId != 0)
        {
          if (localTheme2 == null)
          {
            localTheme2 = locale.getResources().newTheme();
            localTheme2.setTo(localTheme1);
          }
          localTheme2.applyStyle(localTypedValue.resourceId, true);
        }
        Resources.Theme localTheme3 = localTheme2;
        if (localTheme3 == null)
          break label207;
        localObject = new ContextThemeWrapper(locale, 0);
        ((Context)localObject).getTheme().setTo(localTheme3);
      }
    }
    while (true)
    {
      android.support.v7.internal.view.menu.i locali = new android.support.v7.internal.view.menu.i((Context)localObject);
      locali.a(this);
      paramPanelFeatureState.a(locali);
      return true;
      localTheme1.resolveAttribute(android.support.v7.a.b.actionBarWidgetTheme, localTypedValue, true);
      localTheme2 = null;
      break;
      label207: localObject = locale;
    }
  }

  private boolean b(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if (m())
      return false;
    if (paramPanelFeatureState.g)
      return true;
    if ((this.w != null) && (this.w != paramPanelFeatureState))
      a(this.w, false);
    if ((paramPanelFeatureState.a == 0) || (paramPanelFeatureState.a == 8));
    for (int i1 = 1; ; i1 = 0)
    {
      if ((i1 != 0) && (this.k != null))
        this.k.i();
      if ((paramPanelFeatureState.d != null) && (!paramPanelFeatureState.l))
        break label233;
      if ((paramPanelFeatureState.d == null) && ((!b(paramPanelFeatureState)) || (paramPanelFeatureState.d == null)))
        break;
      if ((i1 != 0) && (this.k != null))
      {
        if (this.l == null)
          this.l = new l(this, null);
        this.k.a(paramPanelFeatureState.d, this.l);
      }
      paramPanelFeatureState.d.g();
      if (k().a(paramPanelFeatureState.a, paramPanelFeatureState.d))
        break label228;
      paramPanelFeatureState.a(null);
      if ((i1 == 0) || (this.k == null))
        break;
      this.k.a(null, this.l);
      return false;
    }
    label228: paramPanelFeatureState.l = false;
    label233: paramPanelFeatureState.d.g();
    if (paramPanelFeatureState.m != null)
    {
      paramPanelFeatureState.d.b(paramPanelFeatureState.m);
      paramPanelFeatureState.m = null;
    }
    if (!k().a(0, null, paramPanelFeatureState.d))
    {
      if ((i1 != 0) && (this.k != null))
        this.k.a(null, this.l);
      paramPanelFeatureState.d.h();
      return false;
    }
    int i2;
    if (paramKeyEvent != null)
    {
      i2 = paramKeyEvent.getDeviceId();
      if (KeyCharacterMap.load(i2).getKeyboardType() == 1)
        break label387;
    }
    label387: for (boolean bool = true; ; bool = false)
    {
      paramPanelFeatureState.j = bool;
      paramPanelFeatureState.d.setQwertyMode(paramPanelFeatureState.j);
      paramPanelFeatureState.d.h();
      paramPanelFeatureState.g = true;
      paramPanelFeatureState.h = false;
      this.w = paramPanelFeatureState;
      return true;
      i2 = -1;
      break;
    }
  }

  private void c(int paramInt)
  {
    this.y |= 1 << paramInt;
    if ((!this.x) && (this.o != null))
    {
      au.a(this.o, this.z);
      this.x = true;
    }
  }

  private boolean c(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState)
  {
    if (paramPanelFeatureState.d == null)
      return false;
    if (this.m == null)
      this.m = new o(this, null);
    paramPanelFeatureState.c = ((View)paramPanelFeatureState.a(this.m));
    if (paramPanelFeatureState.c != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void d(int paramInt)
  {
    ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState1 = a(paramInt, true);
    if (localPanelFeatureState1.d != null)
    {
      Bundle localBundle = new Bundle();
      localPanelFeatureState1.d.a(localBundle);
      if (localBundle.size() > 0)
        localPanelFeatureState1.m = localBundle;
      localPanelFeatureState1.d.g();
      localPanelFeatureState1.d.clear();
    }
    localPanelFeatureState1.l = true;
    localPanelFeatureState1.k = true;
    if (((paramInt == 8) || (paramInt == 0)) && (this.k != null))
    {
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState2 = a(0, false);
      if (localPanelFeatureState2 != null)
      {
        localPanelFeatureState2.g = false;
        b(localPanelFeatureState2, null);
      }
    }
  }

  private int e(int paramInt)
  {
    int i1 = 1;
    ViewGroup.MarginLayoutParams localMarginLayoutParams;
    int i5;
    int i6;
    label198: label205: int i4;
    if ((this.h != null) && ((this.h.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)))
    {
      localMarginLayoutParams = (ViewGroup.MarginLayoutParams)this.h.getLayoutParams();
      if (this.h.isShown())
      {
        if (this.C == null)
        {
          this.C = new Rect();
          this.D = new Rect();
        }
        Rect localRect1 = this.C;
        Rect localRect2 = this.D;
        localRect1.set(0, paramInt, 0, 0);
        bh.a(this.p, localRect1, localRect2);
        if (localRect2.top == 0)
        {
          i5 = paramInt;
          if (localMarginLayoutParams.topMargin == i5)
            break label358;
          localMarginLayoutParams.topMargin = paramInt;
          if (this.q != null)
            break label279;
          this.q = new View(this.a);
          this.q.setBackgroundColor(this.a.getResources().getColor(d.abc_input_method_navigation_guard));
          this.p.addView(this.q, -1, new ViewGroup.LayoutParams(-1, paramInt));
          i6 = i1;
          if (this.q == null)
            break label318;
          if ((!this.d) && (i1 != 0))
            paramInt = 0;
          int i7 = i6;
          i4 = i1;
          i1 = i7;
          label228: if (i1 != 0)
            this.h.setLayoutParams(localMarginLayoutParams);
        }
      }
    }
    for (int i2 = i4; ; i2 = 0)
    {
      View localView;
      int i3;
      if (this.q != null)
      {
        localView = this.q;
        i3 = 0;
        if (i2 == 0)
          break label343;
      }
      while (true)
      {
        localView.setVisibility(i3);
        return paramInt;
        i5 = 0;
        break;
        label279: ViewGroup.LayoutParams localLayoutParams = this.q.getLayoutParams();
        if (localLayoutParams.height != paramInt)
        {
          localLayoutParams.height = paramInt;
          this.q.setLayoutParams(localLayoutParams);
        }
        i6 = i1;
        break label198;
        label318: i1 = 0;
        break label205;
        if (localMarginLayoutParams.topMargin == 0)
          break label350;
        localMarginLayoutParams.topMargin = 0;
        i4 = 0;
        break label228;
        label343: i3 = 8;
      }
      label350: i4 = 0;
      i1 = 0;
      break label228;
      label358: i6 = 0;
      break label198;
    }
  }

  private void p()
  {
    TypedArray localTypedArray = this.a.obtainStyledAttributes(android.support.v7.a.l.Theme);
    TypedValue localTypedValue1;
    if (localTypedArray.hasValue(android.support.v7.a.l.Theme_windowFixedWidthMajor))
      if (0 == 0)
      {
        localTypedValue1 = new TypedValue();
        localTypedArray.getValue(android.support.v7.a.l.Theme_windowFixedWidthMajor, localTypedValue1);
      }
    while (true)
    {
      TypedValue localTypedValue2;
      if (localTypedArray.hasValue(android.support.v7.a.l.Theme_windowFixedWidthMinor))
        if (0 == 0)
        {
          localTypedValue2 = new TypedValue();
          localTypedArray.getValue(android.support.v7.a.l.Theme_windowFixedWidthMinor, localTypedValue2);
        }
      while (true)
      {
        Object localObject;
        if (localTypedArray.hasValue(android.support.v7.a.l.Theme_windowFixedHeightMajor))
          if (0 == 0)
          {
            localObject = new TypedValue();
            localTypedArray.getValue(android.support.v7.a.l.Theme_windowFixedHeightMajor, (TypedValue)localObject);
          }
        while (true)
        {
          boolean bool = localTypedArray.hasValue(android.support.v7.a.l.Theme_windowFixedHeightMinor);
          TypedValue localTypedValue3 = null;
          if (bool)
          {
            localTypedValue3 = null;
            if (0 == 0)
              localTypedValue3 = new TypedValue();
            localTypedArray.getValue(android.support.v7.a.l.Theme_windowFixedHeightMinor, localTypedValue3);
          }
          DisplayMetrics localDisplayMetrics = this.a.getResources().getDisplayMetrics();
          int i1;
          label182: int i2;
          if (localDisplayMetrics.widthPixels < localDisplayMetrics.heightPixels)
          {
            i1 = 1;
            if (i1 == 0)
              break label284;
            if ((localTypedValue2 == null) || (localTypedValue2.type == 0))
              break label366;
            if (localTypedValue2.type != 5)
              break label289;
            i2 = (int)localTypedValue2.getDimension(localDisplayMetrics);
          }
          while (true)
          {
            label210: label215: int i3;
            if (i1 != 0)
            {
              if ((localObject == null) || (((TypedValue)localObject).type == 0))
                break label360;
              if (((TypedValue)localObject).type != 5)
                break label327;
              i3 = (int)((TypedValue)localObject).getDimension(localDisplayMetrics);
            }
            while (true)
            {
              if ((i2 != -1) || (i3 != -1))
                this.a.getWindow().setLayout(i2, i3);
              localTypedArray.recycle();
              return;
              i1 = 0;
              break;
              label284: localTypedValue2 = localTypedValue1;
              break label182;
              label289: if (localTypedValue2.type != 6)
                break label366;
              i2 = (int)localTypedValue2.getFraction(localDisplayMetrics.widthPixels, localDisplayMetrics.widthPixels);
              break label210;
              localObject = localTypedValue3;
              break label215;
              label327: if (((TypedValue)localObject).type == 6)
                i3 = (int)((TypedValue)localObject).getFraction(localDisplayMetrics.heightPixels, localDisplayMetrics.heightPixels);
              else
                label360: i3 = -1;
            }
            label366: i2 = -1;
          }
          localObject = null;
          break;
          localObject = null;
        }
        localTypedValue2 = null;
        break;
        localTypedValue2 = null;
      }
      localTypedValue1 = null;
      break;
      localTypedValue1 = null;
    }
  }

  private void q()
  {
    TypedValue localTypedValue;
    e locale;
    if (this.B == null)
    {
      localTypedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(android.support.v7.a.b.panelMenuListTheme, localTypedValue, true);
      locale = this.a;
      if (localTypedValue.resourceId == 0)
        break label74;
    }
    label74: for (int i1 = localTypedValue.resourceId; ; i1 = android.support.v7.a.k.Theme_AppCompat_CompactMenu)
    {
      this.B = new android.support.v7.internal.view.menu.g(new ContextThemeWrapper(locale, i1), android.support.v7.a.i.abc_list_menu_item_layout);
      return;
    }
  }

  public a a()
  {
    n();
    android.support.v7.internal.a.i locali = new android.support.v7.internal.a.i(this.a, this.c);
    locali.c(this.A);
    return locali;
  }

  android.support.v7.b.a a(android.support.v7.b.b paramb)
  {
    if (this.g != null)
      this.g.c();
    m localm = new m(this, paramb);
    Context localContext = j();
    boolean bool;
    if (this.h == null)
    {
      if (this.e)
      {
        this.h = new ActionBarContextView(localContext);
        this.i = new PopupWindow(localContext, null, android.support.v7.a.b.actionModePopupWindowStyle);
        this.i.setContentView(this.h);
        this.i.setWidth(-1);
        TypedValue localTypedValue = new TypedValue();
        this.a.getTheme().resolveAttribute(android.support.v7.a.b.actionBarSize, localTypedValue, true);
        int i1 = TypedValue.complexToDimensionPixelSize(localTypedValue.data, this.a.getResources().getDisplayMetrics());
        this.h.setContentHeight(i1);
        this.i.setHeight(-2);
        this.j = new k(this);
      }
    }
    else if (this.h != null)
    {
      this.h.c();
      ActionBarContextView localActionBarContextView = this.h;
      if (this.i != null)
        break label386;
      bool = true;
      label196: android.support.v7.internal.view.b localb = new android.support.v7.internal.view.b(localContext, localActionBarContextView, localm, bool);
      if (!paramb.a(localb, localb.b()))
        break label392;
      localb.d();
      this.h.a(localb);
      this.h.setVisibility(0);
      this.g = localb;
      if (this.i != null)
        this.a.getWindow().getDecorView().post(this.j);
      this.h.sendAccessibilityEvent(32);
      if (this.h.getParent() != null)
        au.k((View)this.h.getParent());
    }
    while (true)
    {
      if ((this.g != null) && (this.a != null))
        this.a.a(this.g);
      return this.g;
      ViewStubCompat localViewStubCompat = (ViewStubCompat)this.a.findViewById(android.support.v7.a.g.action_mode_bar_stub);
      if (localViewStubCompat == null)
        break;
      localViewStubCompat.setLayoutInflater(LayoutInflater.from(localContext));
      this.h = ((ActionBarContextView)localViewStubCompat.a());
      break;
      label386: bool = false;
      break label196;
      label392: this.g = null;
    }
  }

  View a(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    int i1;
    if (Build.VERSION.SDK_INT < 21)
    {
      i1 = -1;
      switch (paramString.hashCode())
      {
      default:
      case 1666676343:
      case -339785223:
      case 1601505219:
      case 776382189:
      case -1455429095:
      }
    }
    while (true)
      switch (i1)
      {
      default:
        return null;
        if (paramString.equals("EditText"))
        {
          i1 = 0;
          continue;
          if (paramString.equals("Spinner"))
          {
            i1 = 1;
            continue;
            if (paramString.equals("CheckBox"))
            {
              i1 = 2;
              continue;
              if (paramString.equals("RadioButton"))
              {
                i1 = 3;
                continue;
                if (paramString.equals("CheckedTextView"))
                  i1 = 4;
              }
            }
          }
        }
        break;
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      }
    return new av(paramContext, paramAttributeSet);
    return new ba(paramContext, paramAttributeSet);
    return new as(paramContext, paramAttributeSet);
    return new ay(paramContext, paramAttributeSet);
    return new at(paramContext, paramAttributeSet);
  }

  public void a(int paramInt)
  {
    n();
    ViewGroup localViewGroup = (ViewGroup)this.a.findViewById(16908290);
    localViewGroup.removeAllViews();
    this.a.getLayoutInflater().inflate(paramInt, localViewGroup);
    this.a.h();
  }

  public void a(int paramInt, Menu paramMenu)
  {
    ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState = a(paramInt, false);
    if (localPanelFeatureState != null)
      a(localPanelFeatureState, false);
    if (paramInt == 8)
    {
      locala = b();
      if (locala != null)
        locala.e(false);
    }
    while (m())
    {
      a locala;
      return;
    }
    this.a.b(paramInt, paramMenu);
  }

  public void a(Configuration paramConfiguration)
  {
    if ((this.b) && (this.n))
    {
      a locala = b();
      if (locala != null)
        locala.a(paramConfiguration);
    }
  }

  void a(Bundle paramBundle)
  {
    super.a(paramBundle);
    this.o = ((ViewGroup)this.a.getWindow().getDecorView());
    a locala;
    if (aq.b(this.a) != null)
    {
      locala = c();
      if (locala == null)
        this.A = true;
    }
    else
    {
      return;
    }
    locala.c(true);
  }

  public void a(android.support.v7.internal.view.menu.i parami)
  {
    a(parami, true);
  }

  void a(Toolbar paramToolbar)
  {
    a locala = b();
    if ((locala instanceof android.support.v7.internal.a.i))
      throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
    if ((locala instanceof android.support.v7.internal.a.a))
      ((android.support.v7.internal.a.a)locala).a(null);
    android.support.v7.internal.a.a locala1 = new android.support.v7.internal.a.a(paramToolbar, this.a.getTitle(), this.a.getWindow(), this.f);
    q();
    locala1.a(this.B);
    a(locala1);
    a(locala1.e());
    locala1.c();
  }

  public void a(View paramView)
  {
    n();
    ViewGroup localViewGroup = (ViewGroup)this.a.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView);
    this.a.h();
  }

  public void a(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    n();
    ViewGroup localViewGroup = (ViewGroup)this.a.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView, paramLayoutParams);
    this.a.h();
  }

  public void a(CharSequence paramCharSequence)
  {
    if (this.k != null)
    {
      this.k.setWindowTitle(paramCharSequence);
      return;
    }
    if (b() != null)
    {
      b().a(paramCharSequence);
      return;
    }
    this.r = paramCharSequence;
  }

  boolean a(int paramInt, KeyEvent paramKeyEvent)
  {
    return b(paramInt, paramKeyEvent);
  }

  public boolean a(int paramInt, View paramView, Menu paramMenu)
  {
    if (paramInt != 0)
      return k().a(paramInt, paramView, paramMenu);
    return false;
  }

  final boolean a(ActionBarActivityDelegateBase.PanelFeatureState paramPanelFeatureState, int paramInt1, KeyEvent paramKeyEvent, int paramInt2)
  {
    boolean bool1 = paramKeyEvent.isSystem();
    boolean bool2 = false;
    if (bool1);
    do
    {
      return bool2;
      if (!paramPanelFeatureState.g)
      {
        boolean bool3 = b(paramPanelFeatureState, paramKeyEvent);
        bool2 = false;
        if (!bool3);
      }
      else
      {
        android.support.v7.internal.view.menu.i locali = paramPanelFeatureState.d;
        bool2 = false;
        if (locali != null)
          bool2 = paramPanelFeatureState.d.performShortcut(paramInt1, paramKeyEvent, paramInt2);
      }
    }
    while ((!bool2) || ((paramInt2 & 0x1) != 0) || (this.k != null));
    a(paramPanelFeatureState, true);
    return bool2;
  }

  public boolean a(android.support.v7.internal.view.menu.i parami, MenuItem paramMenuItem)
  {
    android.support.v7.internal.a.h localh = k();
    if ((localh != null) && (!m()))
    {
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState = a(parami.p());
      if (localPanelFeatureState != null)
        return localh.a(localPanelFeatureState.a, paramMenuItem);
    }
    return false;
  }

  public android.support.v7.b.a b(android.support.v7.b.b paramb)
  {
    if (paramb == null)
      throw new IllegalArgumentException("ActionMode callback can not be null.");
    if (this.g != null)
      this.g.c();
    m localm = new m(this, paramb);
    a locala = b();
    if (locala != null)
    {
      this.g = locala.a(localm);
      if (this.g != null)
        this.a.a(this.g);
    }
    if (this.g == null)
      this.g = a(localm);
    return this.g;
  }

  public View b(int paramInt)
  {
    if (this.g == null)
    {
      android.support.v7.internal.a.h localh = k();
      if (localh != null);
      for (View localView = localh.a(paramInt); ; localView = null)
      {
        if ((localView == null) && (this.B == null))
        {
          ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState = a(paramInt, true);
          a(localPanelFeatureState, null);
          if (localPanelFeatureState.i)
            localView = localPanelFeatureState.c;
        }
        return localView;
      }
    }
    return null;
  }

  public void b(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    n();
    ((ViewGroup)this.a.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.a.h();
  }

  boolean b(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((this.w != null) && (a(this.w, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)))
      if (this.w != null)
        this.w.h = true;
    boolean bool;
    do
    {
      return true;
      if (this.w != null)
        break;
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState = a(0, true);
      b(localPanelFeatureState, paramKeyEvent);
      bool = a(localPanelFeatureState, paramKeyEvent.getKeyCode(), paramKeyEvent, 1);
      localPanelFeatureState.g = false;
    }
    while (bool);
    return false;
  }

  boolean b(int paramInt, Menu paramMenu)
  {
    if (paramInt == 8)
    {
      a locala = b();
      if (locala != null)
        locala.e(true);
      return true;
    }
    return this.a.c(paramInt, paramMenu);
  }

  public boolean c(int paramInt, Menu paramMenu)
  {
    if (paramInt != 0)
      return k().a(paramInt, paramMenu);
    return false;
  }

  public void e()
  {
    a locala = b();
    if (locala != null)
      locala.d(false);
  }

  public void f()
  {
    a locala = b();
    if (locala != null)
      locala.d(true);
  }

  public void g()
  {
    a locala = b();
    if ((locala != null) && (locala.c()))
      return;
    c(0);
  }

  public boolean h()
  {
    if (this.g != null)
      this.g.c();
    a locala;
    do
    {
      return true;
      locala = b();
    }
    while ((locala != null) && (locala.d()));
    return false;
  }

  public void i()
  {
  }

  final void n()
  {
    Object localObject;
    if (!this.n)
    {
      if (!this.b)
        break label318;
      TypedValue localTypedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(android.support.v7.a.b.actionBarTheme, localTypedValue, true);
      if (localTypedValue.resourceId == 0)
        break label310;
      localObject = new ContextThemeWrapper(this.a, localTypedValue.resourceId);
      this.p = ((ViewGroup)LayoutInflater.from((Context)localObject).inflate(android.support.v7.a.i.abc_screen_toolbar, null));
      this.k = ((w)this.p.findViewById(android.support.v7.a.g.decor_content_parent));
      this.k.setWindowCallback(k());
      if (this.c)
        this.k.a(9);
      if (this.s)
        this.k.a(2);
      if (this.t)
        this.k.a(5);
    }
    while (true)
    {
      bh.b(this.p);
      this.a.a(this.p);
      View localView = this.a.findViewById(16908290);
      localView.setId(-1);
      this.a.findViewById(android.support.v7.a.g.action_bar_activity_content).setId(16908290);
      if ((localView instanceof FrameLayout))
        ((FrameLayout)localView).setForeground(null);
      if ((this.r != null) && (this.k != null))
      {
        this.k.setWindowTitle(this.r);
        this.r = null;
      }
      p();
      o();
      this.n = true;
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState = a(0, false);
      if ((!m()) && ((localPanelFeatureState == null) || (localPanelFeatureState.d == null)))
        c(8);
      return;
      label310: localObject = this.a;
      break;
      label318: if (this.d);
      for (this.p = ((ViewGroup)LayoutInflater.from(this.a).inflate(android.support.v7.a.i.abc_screen_simple_overlay_action_mode, null)); ; this.p = ((ViewGroup)LayoutInflater.from(this.a).inflate(android.support.v7.a.i.abc_screen_simple, null)))
      {
        if (Build.VERSION.SDK_INT < 21)
          break label396;
        au.a(this.p, new i(this));
        break;
      }
      label396: ((z)this.p).setOnFitSystemWindowsListener(new j(this));
    }
  }

  void o()
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.ActionBarActivityDelegateBase
 * JD-Core Version:    0.6.2
 */