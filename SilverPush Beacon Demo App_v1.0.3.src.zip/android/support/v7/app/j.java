package android.support.v7.app;

import android.graphics.Rect;
import android.support.v7.internal.widget.aa;

class j
  implements aa
{
  j(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase)
  {
  }

  public void a(Rect paramRect)
  {
    paramRect.top = ActionBarActivityDelegateBase.c(this.a, paramRect.top);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.j
 * JD-Core Version:    0.6.2
 */