package android.support.v7.app;

import android.support.v4.view.an;
import android.support.v4.view.cy;
import android.view.View;

class i
  implements an
{
  i(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase)
  {
  }

  public cy a(View paramView, cy paramcy)
  {
    int i = paramcy.b();
    int j = ActionBarActivityDelegateBase.c(this.a, i);
    if (i != j)
      paramcy = paramcy.a(paramcy.a(), j, paramcy.c(), paramcy.d());
    return paramcy;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.i
 * JD-Core Version:    0.6.2
 */