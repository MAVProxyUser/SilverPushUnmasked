package android.support.v7.app;

import android.widget.PopupWindow;

class k
  implements Runnable
{
  k(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase)
  {
  }

  public void run()
  {
    this.a.i.showAtLocation(this.a.h, 55, 0, 0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.k
 * JD-Core Version:    0.6.2
 */