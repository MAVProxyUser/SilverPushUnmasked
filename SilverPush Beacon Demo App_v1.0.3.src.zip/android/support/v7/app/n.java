package android.support.v7.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class n
  implements Parcelable.Creator
{
  public ActionBarActivityDelegateBase.PanelFeatureState.SavedState a(Parcel paramParcel)
  {
    return ActionBarActivityDelegateBase.PanelFeatureState.SavedState.a(paramParcel);
  }

  public ActionBarActivityDelegateBase.PanelFeatureState.SavedState[] a(int paramInt)
  {
    return new ActionBarActivityDelegateBase.PanelFeatureState.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.n
 * JD-Core Version:    0.6.2
 */