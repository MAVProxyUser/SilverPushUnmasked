package android.support.v7.app;

class h
  implements Runnable
{
  h(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase)
  {
  }

  public void run()
  {
    if ((0x1 & ActionBarActivityDelegateBase.a(this.a)) != 0)
      ActionBarActivityDelegateBase.a(this.a, 0);
    if ((0x100 & ActionBarActivityDelegateBase.a(this.a)) != 0)
      ActionBarActivityDelegateBase.a(this.a, 8);
    ActionBarActivityDelegateBase.a(this.a, false);
    ActionBarActivityDelegateBase.b(this.a, 0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.h
 * JD-Core Version:    0.6.2
 */