package android.support.v7.app;

import android.support.v7.b.a;
import android.support.v7.b.b;
import android.support.v7.internal.a.h;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

class g
  implements h
{
  g(f paramf)
  {
  }

  public a a(b paramb)
  {
    return this.a.a(paramb);
  }

  public View a(int paramInt)
  {
    return null;
  }

  public boolean a(int paramInt, Menu paramMenu)
  {
    return this.a.a.a(paramInt, paramMenu);
  }

  public boolean a(int paramInt, MenuItem paramMenuItem)
  {
    return this.a.a.onMenuItemSelected(paramInt, paramMenuItem);
  }

  public boolean a(int paramInt, View paramView, Menu paramMenu)
  {
    return this.a.a.a(paramInt, paramView, paramMenu);
  }

  public void b(int paramInt, Menu paramMenu)
  {
    this.a.a.onPanelClosed(paramInt, paramMenu);
  }

  public boolean c(int paramInt, Menu paramMenu)
  {
    return this.a.a.onMenuOpened(paramInt, paramMenu);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.g
 * JD-Core Version:    0.6.2
 */