package android.support.v7.app;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Bundle;
import android.support.v7.a.b;
import android.support.v7.a.k;
import android.support.v7.internal.view.menu.g;
import android.support.v7.internal.view.menu.y;
import android.support.v7.internal.view.menu.z;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;

final class ActionBarActivityDelegateBase$PanelFeatureState
{
  int a;
  ViewGroup b;
  View c;
  android.support.v7.internal.view.menu.i d;
  g e;
  Context f;
  boolean g;
  boolean h;
  boolean i;
  public boolean j;
  boolean k;
  boolean l;
  Bundle m;

  ActionBarActivityDelegateBase$PanelFeatureState(int paramInt)
  {
    this.a = paramInt;
    this.k = false;
  }

  z a(y paramy)
  {
    if (this.d == null)
      return null;
    if (this.e == null)
    {
      this.e = new g(this.f, android.support.v7.a.i.abc_list_menu_item_layout);
      this.e.a(paramy);
      this.d.a(this.e);
    }
    return this.e.a(this.b);
  }

  void a(Context paramContext)
  {
    TypedValue localTypedValue = new TypedValue();
    Resources.Theme localTheme = paramContext.getResources().newTheme();
    localTheme.setTo(paramContext.getTheme());
    localTheme.resolveAttribute(b.actionBarPopupTheme, localTypedValue, true);
    if (localTypedValue.resourceId != 0)
      localTheme.applyStyle(localTypedValue.resourceId, true);
    localTheme.resolveAttribute(b.panelMenuListTheme, localTypedValue, true);
    if (localTypedValue.resourceId != 0)
      localTheme.applyStyle(localTypedValue.resourceId, true);
    while (true)
    {
      ContextThemeWrapper localContextThemeWrapper = new ContextThemeWrapper(paramContext, 0);
      localContextThemeWrapper.getTheme().setTo(localTheme);
      this.f = localContextThemeWrapper;
      return;
      localTheme.applyStyle(k.Theme_AppCompat_CompactMenu, true);
    }
  }

  void a(android.support.v7.internal.view.menu.i parami)
  {
    if (parami == this.d);
    do
    {
      return;
      if (this.d != null)
        this.d.b(this.e);
      this.d = parami;
    }
    while ((parami == null) || (this.e == null));
    parami.a(this.e);
  }

  public boolean a()
  {
    if (this.c == null);
    while (this.e.a().getCount() <= 0)
      return false;
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.ActionBarActivityDelegateBase.PanelFeatureState
 * JD-Core Version:    0.6.2
 */