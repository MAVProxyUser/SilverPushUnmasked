package android.support.v7.app;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.aq;
import android.support.v4.app.ay;
import android.support.v4.app.az;
import android.support.v4.app.o;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

public class e extends o
  implements az
{
  private f n;

  private f i()
  {
    if (this.n == null)
      this.n = f.a(this);
    return this.n;
  }

  public Intent a()
  {
    return aq.a(this);
  }

  public void a(ay paramay)
  {
    paramay.a(this);
  }

  public void a(android.support.v7.b.a parama)
  {
  }

  public void a(Toolbar paramToolbar)
  {
    i().a(paramToolbar);
  }

  void a(View paramView)
  {
    super.setContentView(paramView);
  }

  boolean a(int paramInt, Menu paramMenu)
  {
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }

  boolean a(int paramInt, View paramView, Menu paramMenu)
  {
    return super.onPreparePanel(paramInt, paramView, paramMenu);
  }

  public boolean a(Intent paramIntent)
  {
    return aq.a(this, paramIntent);
  }

  protected boolean a(View paramView, Menu paramMenu)
  {
    return i().a(paramView, paramMenu);
  }

  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    i().b(paramView, paramLayoutParams);
  }

  void b(int paramInt, Menu paramMenu)
  {
    super.onPanelClosed(paramInt, paramMenu);
  }

  public void b(Intent paramIntent)
  {
    aq.b(this, paramIntent);
  }

  public void b(ay paramay)
  {
  }

  public void b(android.support.v7.b.a parama)
  {
  }

  boolean b(View paramView, Menu paramMenu)
  {
    return super.a(paramView, paramMenu);
  }

  boolean c(int paramInt, Menu paramMenu)
  {
    return super.onMenuOpened(paramInt, paramMenu);
  }

  public void d()
  {
    i().g();
  }

  public a f()
  {
    return i().b();
  }

  public boolean g()
  {
    Intent localIntent = a();
    if (localIntent != null)
    {
      if (a(localIntent))
      {
        ay localay = ay.a(this);
        a(localay);
        b(localay);
        localay.a();
      }
      while (true)
      {
        try
        {
          android.support.v4.app.a.a(this);
          return true;
        }
        catch (IllegalStateException localIllegalStateException)
        {
          finish();
          continue;
        }
        b(localIntent);
      }
    }
    return false;
  }

  public MenuInflater getMenuInflater()
  {
    return i().d();
  }

  public void h()
  {
  }

  public void invalidateOptionsMenu()
  {
    i().g();
  }

  public void onBackPressed()
  {
    if (!i().h())
      super.onBackPressed();
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    i().a(paramConfiguration);
  }

  public final void onContentChanged()
  {
    i().i();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    i().a(paramBundle);
  }

  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    return i().c(paramInt, paramMenu);
  }

  public View onCreatePanelView(int paramInt)
  {
    if (paramInt == 0)
      return i().b(paramInt);
    return super.onCreatePanelView(paramInt);
  }

  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    View localView = super.onCreateView(paramString, paramContext, paramAttributeSet);
    if (localView != null)
      return localView;
    return i().a(paramString, paramContext, paramAttributeSet);
  }

  protected void onDestroy()
  {
    super.onDestroy();
    i().l();
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (super.onKeyDown(paramInt, paramKeyEvent))
      return true;
    return i().a(paramInt, paramKeyEvent);
  }

  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    return i().b(paramInt, paramKeyEvent);
  }

  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true;
    a locala = f();
    if ((paramMenuItem.getItemId() == 16908332) && (locala != null) && ((0x4 & locala.a()) != 0))
      return g();
    return false;
  }

  public boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    return i().b(paramInt, paramMenu);
  }

  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    i().a(paramInt, paramMenu);
  }

  protected void onPostResume()
  {
    super.onPostResume();
    i().f();
  }

  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    return i().a(paramInt, paramView, paramMenu);
  }

  protected void onStop()
  {
    super.onStop();
    i().e();
  }

  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt)
  {
    super.onTitleChanged(paramCharSequence, paramInt);
    i().a(paramCharSequence);
  }

  public void setContentView(int paramInt)
  {
    i().a(paramInt);
  }

  public void setContentView(View paramView)
  {
    i().a(paramView);
  }

  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    i().a(paramView, paramLayoutParams);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.e
 * JD-Core Version:    0.6.2
 */