package android.support.v7.app;

import android.support.v4.view.au;
import android.support.v7.b.a;
import android.support.v7.b.b;
import android.support.v7.internal.widget.ActionBarContextView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.PopupWindow;

class m
  implements b
{
  private b b;

  public m(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase, b paramb)
  {
    this.b = paramb;
  }

  public void a(a parama)
  {
    this.b.a(parama);
    if (this.a.i != null)
    {
      this.a.a.getWindow().getDecorView().removeCallbacks(this.a.j);
      this.a.i.dismiss();
    }
    while (true)
    {
      if (this.a.h != null)
        this.a.h.removeAllViews();
      if (this.a.a != null);
      try
      {
        this.a.a.b(this.a.g);
        label101: this.a.g = null;
        return;
        if (this.a.h == null)
          continue;
        this.a.h.setVisibility(8);
        if (this.a.h.getParent() == null)
          continue;
        au.k((View)this.a.h.getParent());
      }
      catch (AbstractMethodError localAbstractMethodError)
      {
        break label101;
      }
    }
  }

  public boolean a(a parama, Menu paramMenu)
  {
    return this.b.a(parama, paramMenu);
  }

  public boolean a(a parama, MenuItem paramMenuItem)
  {
    return this.b.a(parama, paramMenuItem);
  }

  public boolean b(a parama, Menu paramMenu)
  {
    return this.b.b(parama, paramMenu);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.m
 * JD-Core Version:    0.6.2
 */