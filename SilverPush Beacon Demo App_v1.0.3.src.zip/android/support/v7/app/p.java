package android.support.v7.app;

import android.annotation.TargetApi;
import android.support.v7.b.a;
import android.support.v7.internal.view.c;
import android.support.v7.internal.view.d;
import android.support.v7.internal.widget.NativeActionModeAwareLayout;
import android.support.v7.internal.widget.ad;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.KeyEvent;
import android.view.View;

@TargetApi(11)
class p extends ActionBarActivityDelegateBase
  implements ad
{
  private NativeActionModeAwareLayout k;

  p(e parame)
  {
    super(parame);
  }

  public ActionMode a(View paramView, ActionMode.Callback paramCallback)
  {
    a locala = b(new d(paramView.getContext(), paramCallback));
    if (locala != null)
      return new c(this.a, locala);
    return null;
  }

  boolean a(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }

  void o()
  {
    this.k = ((NativeActionModeAwareLayout)this.a.findViewById(16908290));
    if (this.k != null)
      this.k.setActionModeForChildListener(this);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.p
 * JD-Core Version:    0.6.2
 */