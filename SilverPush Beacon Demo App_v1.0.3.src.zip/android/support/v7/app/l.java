package android.support.v7.app;

import android.support.v7.internal.a.h;
import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.y;

final class l
  implements y
{
  private l(ActionBarActivityDelegateBase paramActionBarActivityDelegateBase)
  {
  }

  public void a(i parami, boolean paramBoolean)
  {
    ActionBarActivityDelegateBase.a(this.a, parami);
  }

  public boolean a(i parami)
  {
    h localh = this.a.k();
    if (localh != null)
      localh.c(8, parami);
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.app.l
 * JD-Core Version:    0.6.2
 */