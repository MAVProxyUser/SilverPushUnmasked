package android.support.v7.internal.view.menu;

public abstract interface aa
{
  public abstract void a(m paramm, int paramInt);

  public abstract boolean a();

  public abstract m getItemData();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.aa
 * JD-Core Version:    0.6.2
 */