package android.support.v7.internal.view.menu;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.os.IBinder;
import android.support.v7.a.k;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ListAdapter;

public class l
  implements DialogInterface.OnClickListener, DialogInterface.OnDismissListener, DialogInterface.OnKeyListener, y
{
  g a;
  private i b;
  private AlertDialog c;
  private y d;

  public l(i parami)
  {
    this.b = parami;
  }

  public void a()
  {
    if (this.c != null)
      this.c.dismiss();
  }

  public void a(IBinder paramIBinder)
  {
    i locali = this.b;
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(locali.e());
    this.a = new g(android.support.v7.a.i.abc_list_menu_item_layout, k.Theme_AppCompat_CompactMenu);
    this.a.a(this);
    this.b.a(this.a);
    localBuilder.setAdapter(this.a.a(), this);
    View localView = locali.o();
    if (localView != null)
      localBuilder.setCustomTitle(localView);
    while (true)
    {
      localBuilder.setOnKeyListener(this);
      this.c = localBuilder.create();
      this.c.setOnDismissListener(this);
      WindowManager.LayoutParams localLayoutParams = this.c.getWindow().getAttributes();
      localLayoutParams.type = 1003;
      if (paramIBinder != null)
        localLayoutParams.token = paramIBinder;
      localLayoutParams.flags = (0x20000 | localLayoutParams.flags);
      this.c.show();
      return;
      localBuilder.setIcon(locali.n()).setTitle(locali.m());
    }
  }

  public void a(i parami, boolean paramBoolean)
  {
    if ((paramBoolean) || (parami == this.b))
      a();
    if (this.d != null)
      this.d.a(parami, paramBoolean);
  }

  public boolean a(i parami)
  {
    if (this.d != null)
      return this.d.a(parami);
    return false;
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.b.a((m)this.a.a().getItem(paramInt), 0);
  }

  public void onDismiss(DialogInterface paramDialogInterface)
  {
    this.a.a(this.b, true);
  }

  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 82) || (paramInt == 4))
      if ((paramKeyEvent.getAction() == 0) && (paramKeyEvent.getRepeatCount() == 0))
      {
        Window localWindow2 = this.c.getWindow();
        if (localWindow2 != null)
        {
          View localView2 = localWindow2.getDecorView();
          if (localView2 != null)
          {
            KeyEvent.DispatcherState localDispatcherState2 = localView2.getKeyDispatcherState();
            if (localDispatcherState2 != null)
            {
              localDispatcherState2.startTracking(paramKeyEvent, this);
              return true;
            }
          }
        }
      }
      else if ((paramKeyEvent.getAction() == 1) && (!paramKeyEvent.isCanceled()))
      {
        Window localWindow1 = this.c.getWindow();
        if (localWindow1 != null)
        {
          View localView1 = localWindow1.getDecorView();
          if (localView1 != null)
          {
            KeyEvent.DispatcherState localDispatcherState1 = localView1.getKeyDispatcherState();
            if ((localDispatcherState1 != null) && (localDispatcherState1.isTracking(paramKeyEvent)))
            {
              this.b.a(true);
              paramDialogInterface.dismiss();
              return true;
            }
          }
        }
      }
    return this.b.performShortcut(paramInt, paramKeyEvent, 0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.l
 * JD-Core Version:    0.6.2
 */