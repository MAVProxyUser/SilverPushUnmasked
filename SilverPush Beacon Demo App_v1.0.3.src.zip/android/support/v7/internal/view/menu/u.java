package android.support.v7.internal.view.menu;

import android.content.Context;
import android.support.v4.view.i;
import android.view.ActionProvider;
import android.view.ActionProvider.VisibilityListener;
import android.view.MenuItem;
import android.view.View;

class u extends p
  implements ActionProvider.VisibilityListener
{
  i c;

  public u(t paramt, Context paramContext, ActionProvider paramActionProvider)
  {
    super(paramt, paramContext, paramActionProvider);
  }

  public View a(MenuItem paramMenuItem)
  {
    return this.a.onCreateActionView(paramMenuItem);
  }

  public void a(i parami)
  {
    this.c = parami;
    ActionProvider localActionProvider = this.a;
    if (parami != null);
    while (true)
    {
      localActionProvider.setVisibilityListener(this);
      return;
      this = null;
    }
  }

  public boolean b()
  {
    return this.a.overridesItemVisibility();
  }

  public boolean c()
  {
    return this.a.isVisible();
  }

  public void onActionProviderVisibilityChanged(boolean paramBoolean)
  {
    if (this.c != null)
      this.c.a(paramBoolean);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.u
 * JD-Core Version:    0.6.2
 */