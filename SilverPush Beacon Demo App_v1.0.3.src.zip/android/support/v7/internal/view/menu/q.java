package android.support.v7.internal.view.menu;

import android.support.v7.b.c;
import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;

class q extends FrameLayout
  implements c
{
  final CollapsibleActionView a;

  q(View paramView)
  {
    super(paramView.getContext());
    this.a = ((CollapsibleActionView)paramView);
    addView(paramView);
  }

  public void a()
  {
    this.a.onActionViewExpanded();
  }

  public void b()
  {
    this.a.onActionViewCollapsed();
  }

  View c()
  {
    return (View)this.a;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.q
 * JD-Core Version:    0.6.2
 */