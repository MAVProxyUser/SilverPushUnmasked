package android.support.v7.internal.view.menu;

class f
{
  final Object b;

  f(Object paramObject)
  {
    if (paramObject == null)
      throw new IllegalArgumentException("Wrapped Object can not be null.");
    this.b = paramObject;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.f
 * JD-Core Version:    0.6.2
 */