package android.support.v7.internal.view.menu;

import android.support.v7.widget.q;
import android.support.v7.widget.v;

class b extends v
{
  public b(ActionMenuItemView paramActionMenuItemView)
  {
    super(paramActionMenuItemView);
  }

  public q a()
  {
    if (ActionMenuItemView.a(this.a) != null)
      return ActionMenuItemView.a(this.a).a();
    return null;
  }

  protected boolean b()
  {
    k localk = ActionMenuItemView.b(this.a);
    boolean bool1 = false;
    if (localk != null)
    {
      boolean bool2 = ActionMenuItemView.b(this.a).a(ActionMenuItemView.c(this.a));
      bool1 = false;
      if (bool2)
      {
        q localq = a();
        bool1 = false;
        if (localq != null)
        {
          boolean bool3 = localq.b();
          bool1 = false;
          if (bool3)
            bool1 = true;
        }
      }
    }
    return bool1;
  }

  protected boolean c()
  {
    q localq = a();
    if (localq != null)
    {
      localq.a();
      return true;
    }
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.b
 * JD-Core Version:    0.6.2
 */