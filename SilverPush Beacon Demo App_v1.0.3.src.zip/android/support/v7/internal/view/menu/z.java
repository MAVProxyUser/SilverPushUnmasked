package android.support.v7.internal.view.menu;

public abstract interface z
{
  public abstract void a(i parami);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.z
 * JD-Core Version:    0.6.2
 */