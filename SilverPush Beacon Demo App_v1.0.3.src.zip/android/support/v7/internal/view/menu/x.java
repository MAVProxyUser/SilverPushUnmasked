package android.support.v7.internal.view.menu;

import android.content.Context;

public abstract interface x
{
  public abstract void a(Context paramContext, i parami);

  public abstract void a(i parami, boolean paramBoolean);

  public abstract void a(boolean paramBoolean);

  public abstract boolean a(ad paramad);

  public abstract boolean a(i parami, m paramm);

  public abstract boolean b();

  public abstract boolean b(i parami, m paramm);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.x
 * JD-Core Version:    0.6.2
 */