package android.support.v7.internal.view.menu;

import android.content.Context;
import android.support.v4.view.g;
import android.view.ActionProvider;
import android.view.SubMenu;
import android.view.View;

class p extends g
{
  final ActionProvider a;

  public p(o paramo, Context paramContext, ActionProvider paramActionProvider)
  {
    super(paramContext);
    this.a = paramActionProvider;
  }

  public View a()
  {
    return this.a.onCreateActionView();
  }

  public void a(SubMenu paramSubMenu)
  {
    this.a.onPrepareSubMenu(this.b.a(paramSubMenu));
  }

  public boolean d()
  {
    return this.a.onPerformDefaultAction();
  }

  public boolean e()
  {
    return this.a.hasSubMenu();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.p
 * JD-Core Version:    0.6.2
 */