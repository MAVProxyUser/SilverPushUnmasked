package android.support.v7.internal.view.menu;

class n
  implements android.support.v4.view.i
{
  n(m paramm)
  {
  }

  public void a(boolean paramBoolean)
  {
    m.a(this.a).a(this.a);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.n
 * JD-Core Version:    0.6.2
 */