package android.support.v7.internal.view.menu;

import android.view.MenuItem;

public abstract interface j
{
  public abstract void a(i parami);

  public abstract boolean a(i parami, MenuItem paramMenuItem);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.j
 * JD-Core Version:    0.6.2
 */