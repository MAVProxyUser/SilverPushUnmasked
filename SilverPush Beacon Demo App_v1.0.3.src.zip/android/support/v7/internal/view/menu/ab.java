package android.support.v7.internal.view.menu;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.v4.c.a.a;
import android.support.v4.c.a.b;
import android.support.v4.c.a.c;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

public final class ab
{
  public static Menu a(Context paramContext, a parama)
  {
    if (Build.VERSION.SDK_INT >= 14)
      return new ac(paramContext, parama);
    throw new UnsupportedOperationException();
  }

  public static MenuItem a(Context paramContext, b paramb)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new t(paramContext, paramb);
    if (Build.VERSION.SDK_INT >= 14)
      return new o(paramContext, paramb);
    throw new UnsupportedOperationException();
  }

  public static SubMenu a(Context paramContext, c paramc)
  {
    if (Build.VERSION.SDK_INT >= 14)
      return new ae(paramContext, paramc);
    throw new UnsupportedOperationException();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.ab
 * JD-Core Version:    0.6.2
 */