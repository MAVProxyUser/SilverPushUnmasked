package android.support.v7.internal.view.menu;

import android.content.Context;
import android.support.v4.c.a.b;
import android.support.v4.c.a.c;
import android.support.v4.f.a;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

abstract class e extends f
{
  final Context a;
  private Map c;
  private Map d;

  e(Context paramContext, Object paramObject)
  {
    super(paramObject);
    this.a = paramContext;
  }

  final MenuItem a(MenuItem paramMenuItem)
  {
    if ((paramMenuItem instanceof b))
    {
      b localb = (b)paramMenuItem;
      if (this.c == null)
        this.c = new a();
      MenuItem localMenuItem = (MenuItem)this.c.get(paramMenuItem);
      if (localMenuItem == null)
      {
        localMenuItem = ab.a(this.a, localb);
        this.c.put(localb, localMenuItem);
      }
      return localMenuItem;
    }
    return paramMenuItem;
  }

  final SubMenu a(SubMenu paramSubMenu)
  {
    if ((paramSubMenu instanceof c))
    {
      c localc = (c)paramSubMenu;
      if (this.d == null)
        this.d = new a();
      SubMenu localSubMenu = (SubMenu)this.d.get(localc);
      if (localSubMenu == null)
      {
        localSubMenu = ab.a(this.a, localc);
        this.d.put(localc, localSubMenu);
      }
      return localSubMenu;
    }
    return paramSubMenu;
  }

  final void a()
  {
    if (this.c != null)
      this.c.clear();
    if (this.d != null)
      this.d.clear();
  }

  final void a(int paramInt)
  {
    if (this.c == null);
    while (true)
    {
      return;
      Iterator localIterator = this.c.keySet().iterator();
      while (localIterator.hasNext())
        if (paramInt == ((MenuItem)localIterator.next()).getGroupId())
          localIterator.remove();
    }
  }

  final void b(int paramInt)
  {
    if (this.c == null);
    Iterator localIterator;
    do
    {
      return;
      while (!localIterator.hasNext())
        localIterator = this.c.keySet().iterator();
    }
    while (paramInt != ((MenuItem)localIterator.next()).getItemId());
    localIterator.remove();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.e
 * JD-Core Version:    0.6.2
 */