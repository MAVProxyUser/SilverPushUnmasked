package android.support.v7.internal.view.menu;

import android.annotation.TargetApi;
import android.content.Context;
import android.support.v4.c.a.b;
import android.view.ActionProvider;

@TargetApi(16)
class t extends o
{
  t(Context paramContext, b paramb)
  {
    super(paramContext, paramb);
  }

  p a(ActionProvider paramActionProvider)
  {
    return new u(this, this.a, paramActionProvider);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.t
 * JD-Core Version:    0.6.2
 */