package android.support.v7.internal.view.menu;

public abstract interface y
{
  public abstract void a(i parami, boolean paramBoolean);

  public abstract boolean a(i parami);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.menu.y
 * JD-Core Version:    0.6.2
 */