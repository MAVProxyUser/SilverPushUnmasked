package android.support.v7.internal.view;

import android.support.v4.view.cf;
import android.support.v4.view.cv;
import android.support.v4.view.cw;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Iterator;

public class h
{
  private final ArrayList a = new ArrayList();
  private long b = -1L;
  private Interpolator c;
  private cv d;
  private boolean e;
  private final cw f = new i(this);

  private void c()
  {
    this.e = false;
  }

  public h a(long paramLong)
  {
    if (!this.e)
      this.b = paramLong;
    return this;
  }

  public h a(cf paramcf)
  {
    if (!this.e)
      this.a.add(paramcf);
    return this;
  }

  public h a(cv paramcv)
  {
    if (!this.e)
      this.d = paramcv;
    return this;
  }

  public h a(Interpolator paramInterpolator)
  {
    if (!this.e)
      this.c = paramInterpolator;
    return this;
  }

  public void a()
  {
    if (this.e)
      return;
    Iterator localIterator = this.a.iterator();
    while (localIterator.hasNext())
    {
      cf localcf = (cf)localIterator.next();
      if (this.b >= 0L)
        localcf.a(this.b);
      if (this.c != null)
        localcf.a(this.c);
      if (this.d != null)
        localcf.a(this.f);
      localcf.b();
    }
    this.e = true;
  }

  public void b()
  {
    if (!this.e)
      return;
    Iterator localIterator = this.a.iterator();
    while (localIterator.hasNext())
      ((cf)localIterator.next()).a();
    this.e = false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.h
 * JD-Core Version:    0.6.2
 */