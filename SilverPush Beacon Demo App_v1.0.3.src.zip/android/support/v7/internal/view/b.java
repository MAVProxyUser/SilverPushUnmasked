package android.support.v7.internal.view;

import android.content.Context;
import android.support.v7.b.a;
import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.j;
import android.support.v7.internal.widget.ActionBarContextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.lang.ref.WeakReference;

public class b extends a
  implements j
{
  private Context a;
  private ActionBarContextView b;
  private android.support.v7.b.b c;
  private WeakReference d;
  private boolean e;
  private boolean f;
  private i g;

  public b(Context paramContext, ActionBarContextView paramActionBarContextView, android.support.v7.b.b paramb, boolean paramBoolean)
  {
    this.a = paramContext;
    this.b = paramActionBarContextView;
    this.c = paramb;
    this.g = new i(paramContext).a(1);
    this.g.a(this);
    this.f = paramBoolean;
  }

  public MenuInflater a()
  {
    return new MenuInflater(this.a);
  }

  public void a(int paramInt)
  {
    b(this.a.getString(paramInt));
  }

  public void a(i parami)
  {
    d();
    this.b.a();
  }

  public void a(View paramView)
  {
    this.b.setCustomView(paramView);
    if (paramView != null);
    for (WeakReference localWeakReference = new WeakReference(paramView); ; localWeakReference = null)
    {
      this.d = localWeakReference;
      return;
    }
  }

  public void a(CharSequence paramCharSequence)
  {
    this.b.setSubtitle(paramCharSequence);
  }

  public void a(boolean paramBoolean)
  {
    super.a(paramBoolean);
    this.b.setTitleOptional(paramBoolean);
  }

  public boolean a(i parami, MenuItem paramMenuItem)
  {
    return this.c.a(this, paramMenuItem);
  }

  public Menu b()
  {
    return this.g;
  }

  public void b(int paramInt)
  {
    a(this.a.getString(paramInt));
  }

  public void b(CharSequence paramCharSequence)
  {
    this.b.setTitle(paramCharSequence);
  }

  public void c()
  {
    if (this.e)
      return;
    this.e = true;
    this.b.sendAccessibilityEvent(32);
    this.c.a(this);
  }

  public void d()
  {
    this.c.b(this, this.g);
  }

  public CharSequence f()
  {
    return this.b.getTitle();
  }

  public CharSequence g()
  {
    return this.b.getSubtitle();
  }

  public boolean h()
  {
    return this.b.d();
  }

  public View i()
  {
    if (this.d != null)
      return (View)this.d.get();
    return null;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.b
 * JD-Core Version:    0.6.2
 */