package android.support.v7.internal.view;

import android.support.v4.view.cv;
import android.support.v4.view.cw;
import android.view.View;
import java.util.ArrayList;

class i extends cw
{
  private boolean b = false;
  private int c = 0;

  i(h paramh)
  {
  }

  void a()
  {
    this.c = 0;
    this.b = false;
    h.b(this.a);
  }

  public void a(View paramView)
  {
    if (this.b);
    do
    {
      return;
      this.b = true;
    }
    while (h.a(this.a) == null);
    h.a(this.a).a(null);
  }

  public void b(View paramView)
  {
    int i = 1 + this.c;
    this.c = i;
    if (i == h.c(this.a).size())
    {
      if (h.a(this.a) != null)
        h.a(this.a).b(null);
      a();
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.i
 * JD-Core Version:    0.6.2
 */