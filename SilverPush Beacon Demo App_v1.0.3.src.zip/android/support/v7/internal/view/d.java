package android.support.v7.internal.view;

import android.content.Context;
import android.support.v4.f.m;
import android.support.v7.internal.view.menu.ab;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuItem;

public class d
  implements android.support.v7.b.b
{
  final ActionMode.Callback a;
  final Context b;
  final m c;
  final m d;

  public d(Context paramContext, ActionMode.Callback paramCallback)
  {
    this.b = paramContext;
    this.a = paramCallback;
    this.c = new m();
    this.d = new m();
  }

  private Menu a(Menu paramMenu)
  {
    Menu localMenu = (Menu)this.d.get(paramMenu);
    if (localMenu == null)
    {
      localMenu = ab.a(this.b, (android.support.v4.c.a.a)paramMenu);
      this.d.put(paramMenu, localMenu);
    }
    return localMenu;
  }

  private ActionMode b(android.support.v7.b.a parama)
  {
    c localc1 = (c)this.c.get(parama);
    if (localc1 != null)
      return localc1;
    c localc2 = new c(this.b, parama);
    this.c.put(parama, localc2);
    return localc2;
  }

  public void a(android.support.v7.b.a parama)
  {
    this.a.onDestroyActionMode(b(parama));
  }

  public boolean a(android.support.v7.b.a parama, Menu paramMenu)
  {
    return this.a.onCreateActionMode(b(parama), a(paramMenu));
  }

  public boolean a(android.support.v7.b.a parama, MenuItem paramMenuItem)
  {
    return this.a.onActionItemClicked(b(parama), ab.a(this.b, (android.support.v4.c.a.b)paramMenuItem));
  }

  public boolean b(android.support.v7.b.a parama, Menu paramMenu)
  {
    return this.a.onPrepareActionMode(b(parama), a(paramMenu));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.view.d
 * JD-Core Version:    0.6.2
 */