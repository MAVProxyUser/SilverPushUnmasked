package android.support.v7.internal.widget;

import android.graphics.Rect;

public abstract interface aa
{
  public abstract void a(Rect paramRect);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.aa
 * JD-Core Version:    0.6.2
 */