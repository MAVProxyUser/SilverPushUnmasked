package android.support.v7.internal.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.widget.ListPopupWindow;
import android.widget.Spinner;
import java.lang.reflect.Field;

public class ba extends Spinner
{
  private static final int[] a = { 16842964, 16843126 };

  public ba(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16842881);
  }

  public ba(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    bb localbb = bb.a(paramContext, paramAttributeSet, a, paramInt, 0);
    setBackgroundDrawable(localbb.a(0));
    Drawable localDrawable;
    if (localbb.d(1))
    {
      localDrawable = localbb.a(1);
      if (Build.VERSION.SDK_INT < 16)
        break label66;
      setPopupBackgroundDrawable(localDrawable);
    }
    while (true)
    {
      localbb.b();
      return;
      label66: if (Build.VERSION.SDK_INT >= 11)
        a(this, localDrawable);
    }
  }

  @TargetApi(11)
  private static void a(Spinner paramSpinner, Drawable paramDrawable)
  {
    try
    {
      Field localField = Spinner.class.getDeclaredField("mPopup");
      localField.setAccessible(true);
      Object localObject = localField.get(paramSpinner);
      if ((localObject instanceof ListPopupWindow))
        ((ListPopupWindow)localObject).setBackgroundDrawable(paramDrawable);
      return;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      localNoSuchFieldException.printStackTrace();
      return;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      localIllegalAccessException.printStackTrace();
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ba
 * JD-Core Version:    0.6.2
 */