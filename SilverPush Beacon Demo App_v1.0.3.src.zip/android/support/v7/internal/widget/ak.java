package android.support.v7.internal.widget;

import android.support.v7.widget.q;
import android.support.v7.widget.v;
import android.view.View;

class ak extends v
{
  ak(SpinnerCompat paramSpinnerCompat, View paramView, ao paramao)
  {
    super(paramView);
  }

  public q a()
  {
    return this.a;
  }

  public boolean b()
  {
    if (!SpinnerCompat.a(this.b).b())
      SpinnerCompat.a(this.b).c();
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ak
 * JD-Core Version:    0.6.2
 */