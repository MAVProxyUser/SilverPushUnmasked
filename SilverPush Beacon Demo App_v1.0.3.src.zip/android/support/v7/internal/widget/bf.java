package android.support.v7.internal.widget;

import android.support.v4.view.cw;
import android.support.v7.widget.Toolbar;
import android.view.View;

class bf extends cw
{
  bf(bc parambc)
  {
  }

  public void a(View paramView)
  {
    bc.a(this.a).setVisibility(0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.bf
 * JD-Core Version:    0.6.2
 */