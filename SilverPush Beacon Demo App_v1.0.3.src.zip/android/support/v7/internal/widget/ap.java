package android.support.v7.internal.widget;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;

class ap
  implements AdapterView.OnItemClickListener
{
  ap(ao paramao, SpinnerCompat paramSpinnerCompat)
  {
  }

  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    this.b.a.setSelection(paramInt);
    if (this.b.a.s != null)
      this.b.a.a(paramView, paramInt, ao.a(this.b).getItemId(paramInt));
    this.b.a();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ap
 * JD-Core Version:    0.6.2
 */