package android.support.v7.internal.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class aq
  implements Parcelable.Creator
{
  public SpinnerCompat.SavedState a(Parcel paramParcel)
  {
    return new SpinnerCompat.SavedState(paramParcel, null);
  }

  public SpinnerCompat.SavedState[] a(int paramInt)
  {
    return new SpinnerCompat.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.aq
 * JD-Core Version:    0.6.2
 */