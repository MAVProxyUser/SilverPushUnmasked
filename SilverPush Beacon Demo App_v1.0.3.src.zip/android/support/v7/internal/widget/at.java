package android.support.v7.internal.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.CheckedTextView;

public class at extends CheckedTextView
{
  private static final int[] a = { 16843016 };
  private final aw b;

  public at(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16843720);
  }

  public at(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    bb localbb = bb.a(paramContext, paramAttributeSet, a, paramInt, 0);
    setCheckMarkDrawable(localbb.a(0));
    localbb.b();
    this.b = localbb.c();
  }

  public void setCheckMarkDrawable(int paramInt)
  {
    setCheckMarkDrawable(this.b.a(paramInt));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.at
 * JD-Core Version:    0.6.2
 */