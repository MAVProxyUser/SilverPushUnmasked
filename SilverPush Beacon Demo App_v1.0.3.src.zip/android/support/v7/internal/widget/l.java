package android.support.v7.internal.widget;

public abstract interface l
{
  public abstract void a(int paramInt);

  public abstract void g();

  public abstract void g(boolean paramBoolean);

  public abstract void h();

  public abstract void i();

  public abstract void j();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.l
 * JD-Core Version:    0.6.2
 */