package android.support.v7.internal.widget;

import android.widget.ListAdapter;

abstract interface ar
{
  public abstract void a();

  public abstract void a(ListAdapter paramListAdapter);

  public abstract void a(CharSequence paramCharSequence);

  public abstract boolean b();

  public abstract void c();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ar
 * JD-Core Version:    0.6.2
 */