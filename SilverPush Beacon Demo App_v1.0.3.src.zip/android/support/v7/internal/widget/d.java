package android.support.v7.internal.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class d
  implements Parcelable.Creator
{
  public AbsSpinnerCompat.SavedState a(Parcel paramParcel)
  {
    return new AbsSpinnerCompat.SavedState(paramParcel);
  }

  public AbsSpinnerCompat.SavedState[] a(int paramInt)
  {
    return new AbsSpinnerCompat.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.d
 * JD-Core Version:    0.6.2
 */