package android.support.v7.internal.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RadioButton;

public class ay extends RadioButton
{
  private static final int[] a = { 16843015 };
  private final aw b;

  public ay(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16842878);
  }

  public ay(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    bb localbb = bb.a(paramContext, paramAttributeSet, a, paramInt, 0);
    setButtonDrawable(localbb.a(0));
    localbb.b();
    this.b = localbb.c();
  }

  public void setButtonDrawable(int paramInt)
  {
    setButtonDrawable(this.b.a(paramInt));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ay
 * JD-Core Version:    0.6.2
 */