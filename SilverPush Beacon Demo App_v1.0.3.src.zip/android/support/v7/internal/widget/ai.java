package android.support.v7.internal.widget;

import android.support.v7.app.d;
import android.support.v7.widget.LinearLayoutCompat;
import android.view.View;
import android.view.View.OnClickListener;

class ai
  implements View.OnClickListener
{
  private ai(af paramaf)
  {
  }

  public void onClick(View paramView)
  {
    ((aj)paramView).b().d();
    int i = af.a(this.a).getChildCount();
    int j = 0;
    if (j < i)
    {
      View localView = af.a(this.a).getChildAt(j);
      if (localView == paramView);
      for (boolean bool = true; ; bool = false)
      {
        localView.setSelected(bool);
        j++;
        break;
      }
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ai
 * JD-Core Version:    0.6.2
 */