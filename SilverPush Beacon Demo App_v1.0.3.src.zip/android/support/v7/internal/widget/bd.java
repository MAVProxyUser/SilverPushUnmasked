package android.support.v7.internal.widget;

import android.support.v7.internal.a.h;
import android.support.v7.internal.view.menu.a;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.View.OnClickListener;

class bd
  implements View.OnClickListener
{
  final a a = new a(bc.a(this.b).getContext(), 0, 16908332, 0, 0, bc.b(this.b));

  bd(bc parambc)
  {
  }

  public void onClick(View paramView)
  {
    if ((bc.c(this.b) != null) && (bc.d(this.b)))
      bc.c(this.b).a(0, this.a);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.bd
 * JD-Core Version:    0.6.2
 */