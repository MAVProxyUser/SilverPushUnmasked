package android.support.v7.internal.widget;

import android.view.View;

public abstract interface bg
{
  public abstract void a(ViewStubCompat paramViewStubCompat, View paramView);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.bg
 * JD-Core Version:    0.6.2
 */