package android.support.v7.internal.widget;

import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.View;

public abstract interface ad
{
  public abstract ActionMode a(View paramView, ActionMode.Callback paramCallback);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ad
 * JD-Core Version:    0.6.2
 */