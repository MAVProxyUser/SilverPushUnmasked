package android.support.v7.internal.widget;

import android.graphics.Outline;
import android.graphics.drawable.Drawable;

class f extends e
{
  public f(ActionBarContainer paramActionBarContainer)
  {
    super(paramActionBarContainer);
  }

  public void getOutline(Outline paramOutline)
  {
    if (this.a.d)
      if (this.a.c != null)
        this.a.c.getOutline(paramOutline);
    while (this.a.a == null)
      return;
    this.a.a.getOutline(paramOutline);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.f
 * JD-Core Version:    0.6.2
 */