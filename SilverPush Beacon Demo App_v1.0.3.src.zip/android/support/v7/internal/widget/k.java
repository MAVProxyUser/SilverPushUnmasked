package android.support.v7.internal.widget;

import android.support.v4.view.au;
import android.support.v4.view.cf;

class k
  implements Runnable
{
  k(ActionBarOverlayLayout paramActionBarOverlayLayout)
  {
  }

  public void run()
  {
    ActionBarOverlayLayout.a(this.a);
    ActionBarOverlayLayout.a(this.a, au.i(ActionBarOverlayLayout.c(this.a)).c(-ActionBarOverlayLayout.c(this.a).getHeight()).a(ActionBarOverlayLayout.b(this.a)));
    if ((ActionBarOverlayLayout.d(this.a) != null) && (ActionBarOverlayLayout.d(this.a).getVisibility() != 8))
      ActionBarOverlayLayout.b(this.a, au.i(ActionBarOverlayLayout.d(this.a)).c(ActionBarOverlayLayout.d(this.a).getHeight()).a(ActionBarOverlayLayout.e(this.a)));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.k
 * JD-Core Version:    0.6.2
 */