package android.support.v7.internal.widget;

import android.support.v4.view.cw;
import android.view.View;

class i extends cw
{
  i(ActionBarOverlayLayout paramActionBarOverlayLayout)
  {
  }

  public void b(View paramView)
  {
    ActionBarOverlayLayout.b(this.a, null);
    ActionBarOverlayLayout.a(this.a, false);
  }

  public void c(View paramView)
  {
    ActionBarOverlayLayout.b(this.a, null);
    ActionBarOverlayLayout.a(this.a, false);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.i
 * JD-Core Version:    0.6.2
 */