package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.a.l;
import android.support.v7.internal.b.a;
import android.util.AttributeSet;
import android.widget.TextView;

public class v extends TextView
{
  public v(Context paramContext)
  {
    this(paramContext, null);
  }

  public v(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public v(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, l.CompatTextView, paramInt, 0);
    boolean bool = localTypedArray.getBoolean(l.CompatTextView_textAllCaps, false);
    localTypedArray.recycle();
    if (bool)
      setTransformationMethod(new a(paramContext));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.v
 * JD-Core Version:    0.6.2
 */