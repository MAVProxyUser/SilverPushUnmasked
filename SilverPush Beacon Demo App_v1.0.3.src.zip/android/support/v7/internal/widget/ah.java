package android.support.v7.internal.widget;

import android.support.v7.app.d;
import android.support.v7.widget.LinearLayoutCompat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

class ah extends BaseAdapter
{
  private ah(af paramaf)
  {
  }

  public int getCount()
  {
    return af.a(this.a).getChildCount();
  }

  public Object getItem(int paramInt)
  {
    return ((aj)af.a(this.a).getChildAt(paramInt)).b();
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    if (paramView == null)
      return af.a(this.a, (d)getItem(paramInt), true);
    ((aj)paramView).a((d)getItem(paramInt));
    return paramView;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ah
 * JD-Core Version:    0.6.2
 */