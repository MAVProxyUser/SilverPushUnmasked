package android.support.v7.internal.widget;

class t
  implements Runnable
{
  private t(n paramn)
  {
  }

  public void run()
  {
    if (this.a.u)
    {
      if (this.a.getAdapter() != null)
        this.a.post(this);
      return;
    }
    n.b(this.a);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.t
 * JD-Core Version:    0.6.2
 */