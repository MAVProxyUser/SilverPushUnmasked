package android.support.v7.internal.widget;

import android.content.Context;
import android.support.v7.widget.q;
import android.util.AttributeSet;
import android.widget.ListAdapter;

class ao extends q
  implements ar
{
  private CharSequence c;
  private ListAdapter d;

  public ao(SpinnerCompat paramSpinnerCompat, Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramSpinnerCompat);
    a(true);
    a(0);
    a(new ap(this, paramSpinnerCompat));
  }

  public void a(ListAdapter paramListAdapter)
  {
    super.a(paramListAdapter);
    this.d = paramListAdapter;
  }

  public void a(CharSequence paramCharSequence)
  {
    this.c = paramCharSequence;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.ao
 * JD-Core Version:    0.6.2
 */