package android.support.v7.internal.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class TintImageView extends ImageView
{
  private static final int[] a = { 16842964, 16843033 };
  private final aw b;

  public TintImageView(Context paramContext)
  {
    this(paramContext, null);
  }

  public TintImageView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public TintImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    bb localbb = bb.a(paramContext, paramAttributeSet, a, paramInt, 0);
    if (localbb.a() > 0)
    {
      if (localbb.d(0))
        setBackgroundDrawable(localbb.a(0));
      if (localbb.d(1))
        setImageDrawable(localbb.a(1));
    }
    localbb.b();
    this.b = localbb.c();
  }

  public void setImageResource(int paramInt)
  {
    setImageDrawable(this.b.a(paramInt));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.TintImageView
 * JD-Core Version:    0.6.2
 */