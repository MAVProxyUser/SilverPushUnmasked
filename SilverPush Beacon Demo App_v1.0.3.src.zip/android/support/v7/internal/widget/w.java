package android.support.v7.internal.widget;

import android.support.v7.internal.a.h;
import android.support.v7.internal.view.menu.y;
import android.view.Menu;

public abstract interface w
{
  public abstract void a(int paramInt);

  public abstract void a(Menu paramMenu, y paramy);

  public abstract boolean d();

  public abstract boolean e();

  public abstract boolean f();

  public abstract boolean g();

  public abstract boolean h();

  public abstract void i();

  public abstract void j();

  public abstract void setWindowCallback(h paramh);

  public abstract void setWindowTitle(CharSequence paramCharSequence);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.w
 * JD-Core Version:    0.6.2
 */