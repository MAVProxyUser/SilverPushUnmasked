package android.support.v7.internal.widget;

import android.support.v4.view.cf;
import android.support.v4.view.cv;
import android.support.v7.widget.ActionMenuView;
import android.view.View;

public class b
  implements cv
{
  int a;
  private boolean c = false;

  protected b(a parama)
  {
  }

  public b a(cf paramcf, int paramInt)
  {
    this.b.i = paramcf;
    this.a = paramInt;
    return this;
  }

  public void a(View paramView)
  {
    this.b.setVisibility(0);
    this.c = false;
  }

  public void b(View paramView)
  {
    if (this.c);
    do
    {
      return;
      this.b.i = null;
      this.b.setVisibility(this.a);
    }
    while ((this.b.e == null) || (this.b.c == null));
    this.b.c.setVisibility(this.a);
  }

  public void c(View paramView)
  {
    this.c = true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.b
 * JD-Core Version:    0.6.2
 */