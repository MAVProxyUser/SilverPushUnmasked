package android.support.v7.internal.widget;

import android.view.View;

public abstract interface s
{
  public abstract void a(n paramn);

  public abstract void a(n paramn, View paramView, int paramInt, long paramLong);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.s
 * JD-Core Version:    0.6.2
 */