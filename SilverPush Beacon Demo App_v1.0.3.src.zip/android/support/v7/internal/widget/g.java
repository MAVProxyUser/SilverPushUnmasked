package android.support.v7.internal.widget;

import android.support.v7.b.a;
import android.view.View;
import android.view.View.OnClickListener;

class g
  implements View.OnClickListener
{
  g(ActionBarContextView paramActionBarContextView, a parama)
  {
  }

  public void onClick(View paramView)
  {
    this.a.c();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.g
 * JD-Core Version:    0.6.2
 */