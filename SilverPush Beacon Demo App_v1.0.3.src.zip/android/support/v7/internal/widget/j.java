package android.support.v7.internal.widget;

import android.support.v4.view.au;
import android.support.v4.view.cf;

class j
  implements Runnable
{
  j(ActionBarOverlayLayout paramActionBarOverlayLayout)
  {
  }

  public void run()
  {
    ActionBarOverlayLayout.a(this.a);
    ActionBarOverlayLayout.a(this.a, au.i(ActionBarOverlayLayout.c(this.a)).c(0.0F).a(ActionBarOverlayLayout.b(this.a)));
    if ((ActionBarOverlayLayout.d(this.a) != null) && (ActionBarOverlayLayout.d(this.a).getVisibility() != 8))
      ActionBarOverlayLayout.b(this.a, au.i(ActionBarOverlayLayout.d(this.a)).c(0.0F).a(ActionBarOverlayLayout.e(this.a)));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.j
 * JD-Core Version:    0.6.2
 */