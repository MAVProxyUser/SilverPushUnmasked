package android.support.v7.internal.widget;

import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;

class al
  implements ViewTreeObserver.OnGlobalLayoutListener
{
  al(SpinnerCompat paramSpinnerCompat)
  {
  }

  public void onGlobalLayout()
  {
    if (!SpinnerCompat.a(this.a).b())
      SpinnerCompat.a(this.a).c();
    ViewTreeObserver localViewTreeObserver = this.a.getViewTreeObserver();
    if (localViewTreeObserver != null)
      localViewTreeObserver.removeGlobalOnLayoutListener(this);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.al
 * JD-Core Version:    0.6.2
 */