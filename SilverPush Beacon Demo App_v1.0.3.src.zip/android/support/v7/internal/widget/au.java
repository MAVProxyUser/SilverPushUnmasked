package android.support.v7.internal.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;

class au extends y
{
  private final ColorStateList a;
  private final PorterDuff.Mode b;
  private int c;

  public au(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
    this(paramDrawable, paramColorStateList, aw.a);
  }

  public au(Drawable paramDrawable, ColorStateList paramColorStateList, PorterDuff.Mode paramMode)
  {
    super(paramDrawable);
    this.a = paramColorStateList;
    this.b = paramMode;
  }

  private boolean a(int[] paramArrayOfInt)
  {
    if (this.a != null)
    {
      int i = this.a.getColorForState(paramArrayOfInt, this.c);
      if (i != this.c)
      {
        if (i != 0)
          setColorFilter(i, this.b);
        while (true)
        {
          this.c = i;
          return true;
          clearColorFilter();
        }
      }
    }
    return false;
  }

  public boolean isStateful()
  {
    return ((this.a != null) && (this.a.isStateful())) || (super.isStateful());
  }

  public boolean setState(int[] paramArrayOfInt)
  {
    boolean bool = super.setState(paramArrayOfInt);
    return (a(paramArrayOfInt)) || (bool);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.widget.au
 * JD-Core Version:    0.6.2
 */