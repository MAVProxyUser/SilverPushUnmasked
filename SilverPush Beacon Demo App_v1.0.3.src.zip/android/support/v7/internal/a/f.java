package android.support.v7.internal.a;

import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.y;
import android.view.Window;

final class f
  implements y
{
  private f(a parama)
  {
  }

  public void a(i parami, boolean paramBoolean)
  {
    if (a.a(this.a) != null)
      a.a(this.a).b(0, parami);
    a.g(this.a).closePanel(0);
  }

  public boolean a(i parami)
  {
    if ((parami == null) && (a.a(this.a) != null))
      a.a(this.a).c(0, parami);
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.f
 * JD-Core Version:    0.6.2
 */