package android.support.v7.internal.a;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v4.app.o;
import android.support.v4.view.au;
import android.support.v4.view.cf;
import android.support.v4.view.cv;
import android.support.v4.view.cx;
import android.support.v7.a.g;
import android.support.v7.app.c;
import android.support.v7.app.e;
import android.support.v7.internal.view.h;
import android.support.v7.internal.widget.ActionBarContainer;
import android.support.v7.internal.widget.ActionBarContextView;
import android.support.v7.internal.widget.ActionBarOverlayLayout;
import android.support.v7.internal.widget.af;
import android.support.v7.internal.widget.x;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.view.animation.AnimationUtils;
import java.util.ArrayList;

public class i extends android.support.v7.app.a
  implements android.support.v7.internal.widget.l
{
  private static final boolean i;
  private int A = 0;
  private boolean B = true;
  private boolean C;
  private boolean D;
  private boolean E;
  private boolean F = true;
  private h G;
  private boolean H;
  m a;
  android.support.v7.b.a b;
  android.support.v7.b.b c;
  boolean d;
  final cv e = new j(this);
  final cv f = new k(this);
  final cx g = new l(this);
  private Context j;
  private Context k;
  private o l;
  private ActionBarOverlayLayout m;
  private ActionBarContainer n;
  private x o;
  private ActionBarContextView p;
  private ActionBarContainer q;
  private View r;
  private af s;
  private ArrayList t = new ArrayList();
  private int u = -1;
  private boolean v;
  private boolean w;
  private ArrayList x = new ArrayList();
  private int y;
  private boolean z;

  static
  {
    boolean bool1 = true;
    boolean bool2;
    if (!i.class.desiredAssertionStatus())
    {
      bool2 = bool1;
      h = bool2;
      if (Build.VERSION.SDK_INT < 14)
        break label34;
    }
    while (true)
    {
      i = bool1;
      return;
      bool2 = false;
      break;
      label34: bool1 = false;
    }
  }

  public i(e parame, boolean paramBoolean)
  {
    this.l = parame;
    View localView = parame.getWindow().getDecorView();
    a(localView);
    if (!paramBoolean)
      this.r = localView.findViewById(16908290);
  }

  private void a(View paramView)
  {
    this.m = ((ActionBarOverlayLayout)paramView.findViewById(g.decor_content_parent));
    if (this.m != null)
      this.m.setActionBarVisibilityCallback(this);
    this.o = b(paramView.findViewById(g.action_bar));
    this.p = ((ActionBarContextView)paramView.findViewById(g.action_context_bar));
    this.n = ((ActionBarContainer)paramView.findViewById(g.action_bar_container));
    this.q = ((ActionBarContainer)paramView.findViewById(g.split_action_bar));
    if ((this.o == null) || (this.p == null) || (this.n == null))
      throw new IllegalStateException(getClass().getSimpleName() + " can only be used " + "with a compatible window decor layout");
    this.j = this.o.b();
    int i1;
    int i2;
    label193: android.support.v7.internal.view.a locala;
    if (this.o.c())
    {
      i1 = 1;
      this.y = i1;
      if ((0x4 & this.o.p()) == 0)
        break label309;
      i2 = 1;
      if (i2 != 0)
        this.v = true;
      locala = android.support.v7.internal.view.a.a(this.j);
      if ((!locala.f()) && (i2 == 0))
        break label314;
    }
    label309: label314: for (boolean bool = true; ; bool = false)
    {
      a(bool);
      k(locala.d());
      TypedArray localTypedArray = this.j.obtainStyledAttributes(null, android.support.v7.a.l.ActionBar, android.support.v7.a.b.actionBarStyle, 0);
      if (localTypedArray.getBoolean(android.support.v7.a.l.ActionBar_hideOnContentScroll, false))
        b(true);
      int i3 = localTypedArray.getDimensionPixelSize(android.support.v7.a.l.ActionBar_elevation, 0);
      if (i3 != 0)
        a(i3);
      localTypedArray.recycle();
      return;
      i1 = 0;
      break;
      i2 = 0;
      break label193;
    }
  }

  private x b(View paramView)
  {
    if ((paramView instanceof x))
      return (x)paramView;
    if ((paramView instanceof Toolbar))
      return ((Toolbar)paramView).getWrapper();
    throw new IllegalStateException("Can't make a decor toolbar out of " + paramView.getClass().getSimpleName());
  }

  private static boolean b(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    if (paramBoolean3);
    while ((!paramBoolean1) && (!paramBoolean2))
      return true;
    return false;
  }

  private void k()
  {
    if (!this.E)
    {
      this.E = true;
      if (this.m != null)
        this.m.setShowingForActionMode(true);
      l(false);
    }
  }

  private void k(boolean paramBoolean)
  {
    boolean bool1 = true;
    this.z = paramBoolean;
    boolean bool2;
    label45: label78: boolean bool3;
    label98: ActionBarOverlayLayout localActionBarOverlayLayout;
    if (!this.z)
    {
      this.o.a(null);
      this.n.setTabContainer(this.s);
      if (f() != 2)
        break label155;
      bool2 = bool1;
      if (this.s != null)
      {
        if (!bool2)
          break label160;
        this.s.setVisibility(0);
        if (this.m != null)
          au.k(this.m);
      }
      x localx = this.o;
      if ((this.z) || (!bool2))
        break label172;
      bool3 = bool1;
      localx.a(bool3);
      localActionBarOverlayLayout = this.m;
      if ((this.z) || (!bool2))
        break label178;
    }
    while (true)
    {
      localActionBarOverlayLayout.setHasNonEmbeddedTabs(bool1);
      return;
      this.n.setTabContainer(null);
      this.o.a(this.s);
      break;
      label155: bool2 = false;
      break label45;
      label160: this.s.setVisibility(8);
      break label78;
      label172: bool3 = false;
      break label98;
      label178: bool1 = false;
    }
  }

  private void l()
  {
    if (this.E)
    {
      this.E = false;
      if (this.m != null)
        this.m.setShowingForActionMode(false);
      l(false);
    }
  }

  private void l(boolean paramBoolean)
  {
    if (b(this.C, this.D, this.E))
      if (!this.F)
      {
        this.F = true;
        h(paramBoolean);
      }
    while (!this.F)
      return;
    this.F = false;
    i(paramBoolean);
  }

  public int a()
  {
    return this.o.p();
  }

  public android.support.v7.b.a a(android.support.v7.b.b paramb)
  {
    if (this.a != null)
      this.a.c();
    this.m.setHideOnContentScrollEnabled(false);
    this.p.c();
    m localm = new m(this, paramb);
    if (localm.e())
    {
      localm.d();
      this.p.a(localm);
      j(true);
      if ((this.q != null) && (this.y == 1) && (this.q.getVisibility() != 0))
      {
        this.q.setVisibility(0);
        if (this.m != null)
          au.k(this.m);
      }
      this.p.sendAccessibilityEvent(32);
      this.a = localm;
      return localm;
    }
    return null;
  }

  public void a(float paramFloat)
  {
    au.e(this.n, paramFloat);
    if (this.q != null)
      au.e(this.q, paramFloat);
  }

  public void a(int paramInt)
  {
    this.A = paramInt;
  }

  public void a(int paramInt1, int paramInt2)
  {
    int i1 = this.o.p();
    if ((paramInt2 & 0x4) != 0)
      this.v = true;
    this.o.c(paramInt1 & paramInt2 | i1 & (paramInt2 ^ 0xFFFFFFFF));
  }

  public void a(Configuration paramConfiguration)
  {
    k(android.support.v7.internal.view.a.a(this.j).d());
  }

  public void a(CharSequence paramCharSequence)
  {
    this.o.a(paramCharSequence);
  }

  public void a(boolean paramBoolean)
  {
    this.o.b(paramBoolean);
  }

  public Context b()
  {
    int i1;
    if (this.k == null)
    {
      TypedValue localTypedValue = new TypedValue();
      this.j.getTheme().resolveAttribute(android.support.v7.a.b.actionBarWidgetTheme, localTypedValue, true);
      i1 = localTypedValue.resourceId;
      if (i1 == 0)
        break label61;
    }
    label61: for (this.k = new ContextThemeWrapper(this.j, i1); ; this.k = this.j)
      return this.k;
  }

  public void b(boolean paramBoolean)
  {
    if ((paramBoolean) && (!this.m.a()))
      throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
    this.d = paramBoolean;
    this.m.setHideOnContentScrollEnabled(paramBoolean);
  }

  public void c(boolean paramBoolean)
  {
    if (!this.v)
      f(paramBoolean);
  }

  public void d(boolean paramBoolean)
  {
    this.H = paramBoolean;
    if ((!paramBoolean) && (this.G != null))
      this.G.b();
  }

  public boolean d()
  {
    if ((this.o != null) && (this.o.d()))
    {
      this.o.e();
      return true;
    }
    return false;
  }

  void e()
  {
    if (this.c != null)
    {
      this.c.a(this.b);
      this.b = null;
      this.c = null;
    }
  }

  public void e(boolean paramBoolean)
  {
    if (paramBoolean == this.w);
    while (true)
    {
      return;
      this.w = paramBoolean;
      int i1 = this.x.size();
      for (int i2 = 0; i2 < i1; i2++)
        ((c)this.x.get(i2)).a(paramBoolean);
    }
  }

  public int f()
  {
    return this.o.q();
  }

  public void f(boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i1 = 4; ; i1 = 0)
    {
      a(i1, 4);
      return;
    }
  }

  public void g()
  {
    if (this.D)
    {
      this.D = false;
      l(true);
    }
  }

  public void g(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }

  public void h()
  {
    if (!this.D)
    {
      this.D = true;
      l(true);
    }
  }

  public void h(boolean paramBoolean)
  {
    if (this.G != null)
      this.G.b();
    this.n.setVisibility(0);
    if ((this.A == 0) && (i) && ((this.H) || (paramBoolean)))
    {
      au.b(this.n, 0.0F);
      float f1 = -this.n.getHeight();
      if (paramBoolean)
      {
        int[] arrayOfInt = { 0, 0 };
        this.n.getLocationInWindow(arrayOfInt);
        f1 -= arrayOfInt[1];
      }
      au.b(this.n, f1);
      h localh = new h();
      cf localcf = au.i(this.n).c(0.0F);
      localcf.a(this.g);
      localh.a(localcf);
      if ((this.B) && (this.r != null))
      {
        au.b(this.r, f1);
        localh.a(au.i(this.r).c(0.0F));
      }
      if ((this.q != null) && (this.y == 1))
      {
        au.b(this.q, this.q.getHeight());
        this.q.setVisibility(0);
        localh.a(au.i(this.q).c(0.0F));
      }
      localh.a(AnimationUtils.loadInterpolator(this.j, 17432582));
      localh.a(250L);
      localh.a(this.f);
      this.G = localh;
      localh.a();
    }
    while (true)
    {
      if (this.m != null)
        au.k(this.m);
      return;
      au.c(this.n, 1.0F);
      au.b(this.n, 0.0F);
      if ((this.B) && (this.r != null))
        au.b(this.r, 0.0F);
      if ((this.q != null) && (this.y == 1))
      {
        au.c(this.q, 1.0F);
        au.b(this.q, 0.0F);
        this.q.setVisibility(0);
      }
      this.f.b(null);
    }
  }

  public void i()
  {
    if (this.G != null)
    {
      this.G.b();
      this.G = null;
    }
  }

  public void i(boolean paramBoolean)
  {
    if (this.G != null)
      this.G.b();
    if ((this.A == 0) && (i) && ((this.H) || (paramBoolean)))
    {
      au.c(this.n, 1.0F);
      this.n.setTransitioning(true);
      h localh = new h();
      float f1 = -this.n.getHeight();
      if (paramBoolean)
      {
        int[] arrayOfInt = { 0, 0 };
        this.n.getLocationInWindow(arrayOfInt);
        f1 -= arrayOfInt[1];
      }
      cf localcf = au.i(this.n).c(f1);
      localcf.a(this.g);
      localh.a(localcf);
      if ((this.B) && (this.r != null))
        localh.a(au.i(this.r).c(f1));
      if ((this.q != null) && (this.q.getVisibility() == 0))
      {
        au.c(this.q, 1.0F);
        localh.a(au.i(this.q).c(this.q.getHeight()));
      }
      localh.a(AnimationUtils.loadInterpolator(this.j, 17432581));
      localh.a(250L);
      localh.a(this.e);
      this.G = localh;
      localh.a();
      return;
    }
    this.e.b(null);
  }

  public void j()
  {
  }

  public void j(boolean paramBoolean)
  {
    int i1;
    label20: ActionBarContextView localActionBarContextView;
    int i2;
    if (paramBoolean)
    {
      k();
      x localx = this.o;
      if (!paramBoolean)
        break label55;
      i1 = 8;
      localx.d(i1);
      localActionBarContextView = this.p;
      i2 = 0;
      if (!paramBoolean)
        break label60;
    }
    while (true)
    {
      localActionBarContextView.a(i2);
      return;
      l();
      break;
      label55: i1 = 0;
      break label20;
      label60: i2 = 8;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.i
 * JD-Core Version:    0.6.2
 */