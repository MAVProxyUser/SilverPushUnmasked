package android.support.v7.internal.a;

class b
  implements Runnable
{
  b(a parama)
  {
  }

  public void run()
  {
    this.a.f();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.b
 * JD-Core Version:    0.6.2
 */