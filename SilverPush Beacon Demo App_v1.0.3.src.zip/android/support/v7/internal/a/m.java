package android.support.v7.internal.a;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.b.a;
import android.support.v7.b.b;
import android.support.v7.internal.view.e;
import android.support.v7.internal.view.menu.j;
import android.support.v7.internal.widget.ActionBarContextView;
import android.support.v7.internal.widget.ActionBarOverlayLayout;
import android.support.v7.internal.widget.x;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;

public class m extends a
  implements j
{
  private b b;
  private android.support.v7.internal.view.menu.i c;
  private WeakReference d;

  public m(i parami, b paramb)
  {
    this.b = paramb;
    this.c = new android.support.v7.internal.view.menu.i(parami.b()).a(1);
    this.c.a(this);
  }

  public MenuInflater a()
  {
    return new e(this.a.b());
  }

  public void a(int paramInt)
  {
    b(i.k(this.a).getResources().getString(paramInt));
  }

  public void a(android.support.v7.internal.view.menu.i parami)
  {
    if (this.b == null)
      return;
    d();
    i.i(this.a).a();
  }

  public void a(View paramView)
  {
    i.i(this.a).setCustomView(paramView);
    this.d = new WeakReference(paramView);
  }

  public void a(CharSequence paramCharSequence)
  {
    i.i(this.a).setSubtitle(paramCharSequence);
  }

  public void a(boolean paramBoolean)
  {
    super.a(paramBoolean);
    i.i(this.a).setTitleOptional(paramBoolean);
  }

  public boolean a(android.support.v7.internal.view.menu.i parami, MenuItem paramMenuItem)
  {
    if (this.b != null)
      return this.b.a(this, paramMenuItem);
    return false;
  }

  public Menu b()
  {
    return this.c;
  }

  public void b(int paramInt)
  {
    a(i.k(this.a).getResources().getString(paramInt));
  }

  public void b(CharSequence paramCharSequence)
  {
    i.i(this.a).setTitle(paramCharSequence);
  }

  public void c()
  {
    if (this.a.a != this)
      return;
    if (!i.a(i.g(this.a), i.h(this.a), false))
    {
      this.a.b = this;
      this.a.c = this.b;
    }
    while (true)
    {
      this.b = null;
      this.a.j(false);
      i.i(this.a).b();
      i.j(this.a).a().sendAccessibilityEvent(32);
      i.f(this.a).setHideOnContentScrollEnabled(this.a.d);
      this.a.a = null;
      return;
      this.b.a(this);
    }
  }

  public void d()
  {
    this.c.g();
    try
    {
      this.b.b(this, this.c);
      return;
    }
    finally
    {
      this.c.h();
    }
  }

  public boolean e()
  {
    this.c.g();
    try
    {
      boolean bool = this.b.a(this, this.c);
      return bool;
    }
    finally
    {
      this.c.h();
    }
  }

  public CharSequence f()
  {
    return i.i(this.a).getTitle();
  }

  public CharSequence g()
  {
    return i.i(this.a).getSubtitle();
  }

  public boolean h()
  {
    return i.i(this.a).d();
  }

  public View i()
  {
    if (this.d != null)
      return (View)this.d.get();
    return null;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.m
 * JD-Core Version:    0.6.2
 */