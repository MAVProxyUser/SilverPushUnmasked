package android.support.v7.internal.a;

import android.support.v4.view.cw;
import android.support.v7.internal.widget.ActionBarContainer;
import android.view.View;

class k extends cw
{
  k(i parami)
  {
  }

  public void b(View paramView)
  {
    i.a(this.a, null);
    i.c(this.a).requestLayout();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.k
 * JD-Core Version:    0.6.2
 */