package android.support.v7.internal.a;

import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.j;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

final class e
  implements j
{
  private e(a parama)
  {
  }

  public void a(i parami)
  {
    if (a.a(this.a) != null)
    {
      if (!a.e(this.a).b())
        break label39;
      a.a(this.a).b(8, parami);
    }
    label39: 
    while (!a.a(this.a).a(0, null, parami))
      return;
    a.a(this.a).c(8, parami);
  }

  public boolean a(i parami, MenuItem paramMenuItem)
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.e
 * JD-Core Version:    0.6.2
 */