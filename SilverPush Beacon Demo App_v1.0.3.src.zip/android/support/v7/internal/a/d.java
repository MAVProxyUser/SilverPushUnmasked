package android.support.v7.internal.a;

import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.y;
import android.support.v7.widget.Toolbar;

final class d
  implements y
{
  private boolean b;

  private d(a parama)
  {
  }

  public void a(i parami, boolean paramBoolean)
  {
    if (this.b)
      return;
    this.b = true;
    a.e(this.a).f();
    if (a.a(this.a) != null)
      a.a(this.a).b(8, parami);
    this.b = false;
  }

  public boolean a(i parami)
  {
    if (a.a(this.a) != null)
    {
      a.a(this.a).c(8, parami);
      return true;
    }
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.d
 * JD-Core Version:    0.6.2
 */