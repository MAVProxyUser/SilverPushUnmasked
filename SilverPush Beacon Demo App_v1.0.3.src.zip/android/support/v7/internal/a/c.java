package android.support.v7.internal.a;

import android.support.v7.widget.ao;
import android.view.MenuItem;

class c
  implements ao
{
  c(a parama)
  {
  }

  public boolean a(MenuItem paramMenuItem)
  {
    return a.a(this.a).a(0, paramMenuItem);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.c
 * JD-Core Version:    0.6.2
 */