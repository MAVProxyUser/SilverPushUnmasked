package android.support.v7.internal.a;

import android.support.v4.view.cx;
import android.support.v7.internal.widget.ActionBarContainer;
import android.view.View;

class l
  implements cx
{
  l(i parami)
  {
  }

  public void a(View paramView)
  {
    ((View)i.c(this.a).getParent()).invalidate();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.l
 * JD-Core Version:    0.6.2
 */