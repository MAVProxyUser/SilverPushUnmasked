package android.support.v7.internal.a;

import android.support.v7.b.a;
import android.support.v7.b.b;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public abstract interface h
{
  public abstract a a(b paramb);

  public abstract View a(int paramInt);

  public abstract boolean a(int paramInt, Menu paramMenu);

  public abstract boolean a(int paramInt, MenuItem paramMenuItem);

  public abstract boolean a(int paramInt, View paramView, Menu paramMenu);

  public abstract void b(int paramInt, Menu paramMenu);

  public abstract boolean c(int paramInt, Menu paramMenu);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.h
 * JD-Core Version:    0.6.2
 */