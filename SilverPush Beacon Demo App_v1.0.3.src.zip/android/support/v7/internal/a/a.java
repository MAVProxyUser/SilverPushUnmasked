package android.support.v7.internal.a;

import android.content.Context;
import android.content.res.Configuration;
import android.support.v4.view.au;
import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.widget.bc;
import android.support.v7.internal.widget.x;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.ao;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.ListAdapter;
import java.util.ArrayList;

public class a extends android.support.v7.app.a
{
  private Toolbar a;
  private x b;
  private boolean c;
  private h d;
  private boolean e;
  private boolean f;
  private ArrayList g = new ArrayList();
  private Window h;
  private android.support.v7.internal.view.menu.g i;
  private final Runnable j = new b(this);
  private final ao k = new c(this);

  public a(Toolbar paramToolbar, CharSequence paramCharSequence, Window paramWindow, h paramh)
  {
    this.a = paramToolbar;
    this.b = new bc(paramToolbar, false);
    this.d = new g(this, paramh);
    this.b.a(this.d);
    paramToolbar.setOnMenuItemClickListener(this.k);
    this.b.a(paramCharSequence);
    this.h = paramWindow;
  }

  private View a(Menu paramMenu)
  {
    if ((paramMenu == null) || (this.i == null));
    while (this.i.a().getCount() <= 0)
      return null;
    return (View)this.i.a(this.a);
  }

  private Menu g()
  {
    if (!this.e)
    {
      this.a.a(new d(this, null), new e(this, null));
      this.e = true;
    }
    return this.a.getMenu();
  }

  public int a()
  {
    return this.b.p();
  }

  public android.support.v7.b.a a(android.support.v7.b.b paramb)
  {
    return this.d.a(paramb);
  }

  public void a(float paramFloat)
  {
    au.e(this.a, paramFloat);
  }

  public void a(Configuration paramConfiguration)
  {
    super.a(paramConfiguration);
  }

  public void a(android.support.v7.internal.view.menu.g paramg)
  {
    Menu localMenu = g();
    if ((localMenu instanceof i))
    {
      i locali = (i)localMenu;
      if (this.i != null)
      {
        this.i.a(null);
        locali.b(this.i);
      }
      this.i = paramg;
      if (paramg != null)
      {
        paramg.a(new f(this, null));
        locali.a(paramg);
      }
    }
  }

  public void a(CharSequence paramCharSequence)
  {
    this.b.a(paramCharSequence);
  }

  public void a(boolean paramBoolean)
  {
  }

  public Context b()
  {
    return this.a.getContext();
  }

  public void c(boolean paramBoolean)
  {
  }

  public boolean c()
  {
    this.a.removeCallbacks(this.j);
    au.a(this.a, this.j);
    return true;
  }

  public void d(boolean paramBoolean)
  {
  }

  public boolean d()
  {
    if (this.a.g())
    {
      this.a.h();
      return true;
    }
    return false;
  }

  public h e()
  {
    return this.d;
  }

  public void e(boolean paramBoolean)
  {
    if (paramBoolean == this.f);
    while (true)
    {
      return;
      this.f = paramBoolean;
      int m = this.g.size();
      for (int n = 0; n < m; n++)
        ((android.support.v7.app.c)this.g.get(n)).a(paramBoolean);
    }
  }

  void f()
  {
    Menu localMenu = g();
    i locali;
    if ((localMenu instanceof i))
      locali = (i)localMenu;
    while (true)
    {
      if (locali != null)
        locali.g();
      try
      {
        localMenu.clear();
        if ((!this.d.a(0, localMenu)) || (!this.d.a(0, null, localMenu)))
          localMenu.clear();
        return;
        locali = null;
      }
      finally
      {
        if (locali != null)
          locali.h();
      }
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.a
 * JD-Core Version:    0.6.2
 */