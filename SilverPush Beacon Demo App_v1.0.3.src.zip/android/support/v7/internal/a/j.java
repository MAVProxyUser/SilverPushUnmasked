package android.support.v7.internal.a;

import android.support.v4.view.au;
import android.support.v4.view.cw;
import android.support.v7.internal.widget.ActionBarContainer;
import android.view.View;

class j extends cw
{
  j(i parami)
  {
  }

  public void b(View paramView)
  {
    if ((i.a(this.a)) && (i.b(this.a) != null))
    {
      au.b(i.b(this.a), 0.0F);
      au.b(i.c(this.a), 0.0F);
    }
    if ((i.d(this.a) != null) && (i.e(this.a) == 1))
      i.d(this.a).setVisibility(8);
    i.c(this.a).setVisibility(8);
    i.c(this.a).setTransitioning(false);
    i.a(this.a, null);
    this.a.e();
    if (i.f(this.a) != null)
      au.k(i.f(this.a));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.j
 * JD-Core Version:    0.6.2
 */