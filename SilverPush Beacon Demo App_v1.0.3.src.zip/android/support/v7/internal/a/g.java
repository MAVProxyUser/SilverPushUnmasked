package android.support.v7.internal.a;

import android.support.v7.internal.widget.x;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.aq;
import android.view.Menu;
import android.view.View;

class g extends aq
{
  public g(a parama, h paramh)
  {
    super(paramh);
  }

  public View a(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    }
    Menu localMenu;
    do
    {
      do
      {
        return super.a(paramInt);
        if (!a.b(this.a))
        {
          this.a.f();
          a.e(this.a).removeCallbacks(a.d(this.a));
        }
      }
      while ((!a.b(this.a)) || (a.a(this.a) == null));
      localMenu = a.f(this.a);
    }
    while ((!a.a(this.a).a(paramInt, null, localMenu)) || (!a.a(this.a).c(paramInt, localMenu)));
    return a.a(this.a, localMenu);
  }

  public boolean a(int paramInt, View paramView, Menu paramMenu)
  {
    boolean bool = super.a(paramInt, paramView, paramMenu);
    if ((bool) && (!a.b(this.a)))
    {
      a.c(this.a).n();
      a.a(this.a, true);
    }
    return bool;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a.g
 * JD-Core Version:    0.6.2
 */