package android.support.v7.internal;

import android.os.Build.VERSION;

public class a
{
  public static boolean a()
  {
    return Build.VERSION.SDK_INT >= 21;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.internal.a
 * JD-Core Version:    0.6.2
 */