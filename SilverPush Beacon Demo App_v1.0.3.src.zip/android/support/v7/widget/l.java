package android.support.v7.widget;

import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.y;

class l
  implements y
{
  private l(ActionMenuView paramActionMenuView)
  {
  }

  public void a(i parami, boolean paramBoolean)
  {
  }

  public boolean a(i parami)
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.l
 * JD-Core Version:    0.6.2
 */