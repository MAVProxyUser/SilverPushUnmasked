package android.support.v7.widget;

class x
  implements Runnable
{
  private x(v paramv)
  {
  }

  public void run()
  {
    v.b(this.a);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.x
 * JD-Core Version:    0.6.2
 */