package android.support.v7.widget;

import android.view.MenuItem;

class aj
  implements o
{
  aj(Toolbar paramToolbar)
  {
  }

  public boolean a(MenuItem paramMenuItem)
  {
    if (Toolbar.a(this.a) != null)
      return Toolbar.a(this.a).a(paramMenuItem);
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.aj
 * JD-Core Version:    0.6.2
 */