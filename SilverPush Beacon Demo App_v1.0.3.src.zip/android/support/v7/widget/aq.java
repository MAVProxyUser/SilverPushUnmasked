package android.support.v7.widget;

import android.support.v7.b.a;
import android.support.v7.b.b;
import android.support.v7.internal.a.h;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class aq
  implements h
{
  private h a;

  public aq(h paramh)
  {
    if (paramh == null)
      throw new IllegalArgumentException("Window callback may not be null");
    this.a = paramh;
  }

  public a a(b paramb)
  {
    return this.a.a(paramb);
  }

  public View a(int paramInt)
  {
    return this.a.a(paramInt);
  }

  public boolean a(int paramInt, Menu paramMenu)
  {
    return this.a.a(paramInt, paramMenu);
  }

  public boolean a(int paramInt, MenuItem paramMenuItem)
  {
    return this.a.a(paramInt, paramMenuItem);
  }

  public boolean a(int paramInt, View paramView, Menu paramMenu)
  {
    return this.a.a(paramInt, paramView, paramMenu);
  }

  public void b(int paramInt, Menu paramMenu)
  {
    this.a.b(paramInt, paramMenu);
  }

  public boolean c(int paramInt, Menu paramMenu)
  {
    return this.a.c(paramInt, paramMenu);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.aq
 * JD-Core Version:    0.6.2
 */