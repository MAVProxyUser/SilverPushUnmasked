package android.support.v7.widget;

public abstract interface af
{
  public abstract boolean a(String paramString);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.af
 * JD-Core Version:    0.6.2
 */