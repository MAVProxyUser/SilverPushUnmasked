package android.support.v7.widget;

import android.widget.PopupWindow;

class ac
  implements Runnable
{
  private ac(q paramq)
  {
  }

  public void run()
  {
    if ((q.a(this.a) != null) && (q.a(this.a).getCount() > q.a(this.a).getChildCount()) && (q.a(this.a).getChildCount() <= this.a.b))
    {
      q.b(this.a).setInputMethodMode(2);
      this.a.c();
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.ac
 * JD-Core Version:    0.6.2
 */