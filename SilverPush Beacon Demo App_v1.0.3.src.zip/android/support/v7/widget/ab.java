package android.support.v7.widget;

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.PopupWindow;

class ab
  implements View.OnTouchListener
{
  private ab(q paramq)
  {
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getAction();
    int j = (int)paramMotionEvent.getX();
    int k = (int)paramMotionEvent.getY();
    if ((i == 0) && (q.b(this.a) != null) && (q.b(this.a).isShowing()) && (j >= 0) && (j < q.b(this.a).getWidth()) && (k >= 0) && (k < q.b(this.a).getHeight()))
      q.d(this.a).postDelayed(q.c(this.a), 250L);
    while (true)
    {
      return false;
      if (i == 1)
        q.d(this.a).removeCallbacks(q.c(this.a));
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.ab
 * JD-Core Version:    0.6.2
 */