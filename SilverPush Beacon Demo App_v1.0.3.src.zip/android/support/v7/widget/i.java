package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class i
  implements Parcelable.Creator
{
  public ActionMenuPresenter.SavedState a(Parcel paramParcel)
  {
    return new ActionMenuPresenter.SavedState(paramParcel);
  }

  public ActionMenuPresenter.SavedState[] a(int paramInt)
  {
    return new ActionMenuPresenter.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.i
 * JD-Core Version:    0.6.2
 */