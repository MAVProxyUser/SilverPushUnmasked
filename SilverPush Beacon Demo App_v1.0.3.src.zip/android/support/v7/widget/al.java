package android.support.v7.widget;

import android.view.View;
import android.view.View.OnClickListener;

class al
  implements View.OnClickListener
{
  al(Toolbar paramToolbar)
  {
  }

  public void onClick(View paramView)
  {
    this.a.h();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.al
 * JD-Core Version:    0.6.2
 */