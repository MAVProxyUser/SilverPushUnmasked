package android.support.v7.widget;

import android.os.Handler;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.PopupWindow;

class aa
  implements AbsListView.OnScrollListener
{
  private aa(q paramq)
  {
  }

  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    if ((paramInt == 1) && (!this.a.f()) && (q.b(this.a).getContentView() != null))
    {
      q.d(this.a).removeCallbacks(q.c(this.a));
      q.c(this.a).run();
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.aa
 * JD-Core Version:    0.6.2
 */