package android.support.v7.widget;

import android.view.View;

class s
  implements Runnable
{
  s(q paramq)
  {
  }

  public void run()
  {
    View localView = this.a.d();
    if ((localView != null) && (localView.getWindowToken() != null))
      this.a.c();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.s
 * JD-Core Version:    0.6.2
 */