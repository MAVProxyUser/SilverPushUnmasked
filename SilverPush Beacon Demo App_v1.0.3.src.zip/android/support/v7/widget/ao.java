package android.support.v7.widget;

import android.view.MenuItem;

public abstract interface ao
{
  public abstract boolean a(MenuItem paramMenuItem);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.ao
 * JD-Core Version:    0.6.2
 */