package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class ap
  implements Parcelable.Creator
{
  public Toolbar.SavedState a(Parcel paramParcel)
  {
    return new Toolbar.SavedState(paramParcel);
  }

  public Toolbar.SavedState[] a(int paramInt)
  {
    return new Toolbar.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.ap
 * JD-Core Version:    0.6.2
 */