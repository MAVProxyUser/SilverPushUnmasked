package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.a.l;
import android.util.AttributeSet;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

public class p extends ViewGroup.MarginLayoutParams
{
  public float g;
  public int h = -1;

  public p(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
    this.g = 0.0F;
  }

  public p(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, l.LinearLayoutCompat_Layout);
    this.g = localTypedArray.getFloat(l.LinearLayoutCompat_Layout_android_layout_weight, 0.0F);
    this.h = localTypedArray.getInt(l.LinearLayoutCompat_Layout_android_layout_gravity, -1);
    localTypedArray.recycle();
  }

  public p(ViewGroup.LayoutParams paramLayoutParams)
  {
    super(paramLayoutParams);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.p
 * JD-Core Version:    0.6.2
 */