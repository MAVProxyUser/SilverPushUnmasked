package android.support.v7.widget;

import android.support.v7.internal.view.menu.ad;
import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.y;
import android.view.MenuItem;

class h
  implements y
{
  private h(ActionMenuPresenter paramActionMenuPresenter)
  {
  }

  public void a(i parami, boolean paramBoolean)
  {
    if ((parami instanceof ad))
      ((ad)parami).p().a(false);
    y localy = this.a.a();
    if (localy != null)
      localy.a(parami, paramBoolean);
  }

  public boolean a(i parami)
  {
    if (parami == null)
      return false;
    this.a.h = ((ad)parami).getItem().getItemId();
    y localy = this.a.a();
    if (localy != null);
    for (boolean bool = localy.a(parami); ; bool = false)
      return bool;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.h
 * JD-Core Version:    0.6.2
 */