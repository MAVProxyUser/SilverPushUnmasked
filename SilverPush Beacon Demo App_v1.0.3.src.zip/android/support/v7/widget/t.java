package android.support.v7.widget;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

class t
  implements AdapterView.OnItemSelectedListener
{
  t(q paramq)
  {
  }

  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    if (paramInt != -1)
    {
      u localu = q.a(this.a);
      if (localu != null)
        u.a(localu, false);
    }
  }

  public void onNothingSelected(AdapterView paramAdapterView)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.t
 * JD-Core Version:    0.6.2
 */