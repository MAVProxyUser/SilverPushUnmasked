package android.support.v7.widget;

class c extends android.support.v7.internal.view.menu.c
{
  private c(ActionMenuPresenter paramActionMenuPresenter)
  {
  }

  public q a()
  {
    if (ActionMenuPresenter.h(this.a) != null)
      return ActionMenuPresenter.h(this.a).c();
    return null;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.c
 * JD-Core Version:    0.6.2
 */