package android.support.v7.widget;

import android.support.v7.a.g;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

final class ai
{
  public final TextView a;
  public final TextView b;
  public final ImageView c;
  public final ImageView d;
  public final ImageView e;

  public ai(View paramView)
  {
    this.a = ((TextView)paramView.findViewById(16908308));
    this.b = ((TextView)paramView.findViewById(16908309));
    this.c = ((ImageView)paramView.findViewById(16908295));
    this.d = ((ImageView)paramView.findViewById(16908296));
    this.e = ((ImageView)paramView.findViewById(g.edit_query));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.ai
 * JD-Core Version:    0.6.2
 */