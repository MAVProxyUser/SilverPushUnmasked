package android.support.v7.widget;

import android.support.v7.internal.view.menu.i;
import android.support.v7.internal.view.menu.j;
import android.view.MenuItem;

class n
  implements j
{
  private n(ActionMenuView paramActionMenuView)
  {
  }

  public void a(i parami)
  {
    if (ActionMenuView.b(this.a) != null)
      ActionMenuView.b(this.a).a(parami);
  }

  public boolean a(i parami, MenuItem paramMenuItem)
  {
    return (ActionMenuView.a(this.a) != null) && (ActionMenuView.a(this.a).a(paramMenuItem));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.n
 * JD-Core Version:    0.6.2
 */