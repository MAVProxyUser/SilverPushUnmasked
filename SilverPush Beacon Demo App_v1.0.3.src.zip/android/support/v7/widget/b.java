package android.support.v7.widget;

import android.content.Context;
import android.support.v7.internal.view.menu.ad;
import android.support.v7.internal.view.menu.m;
import android.support.v7.internal.view.menu.v;
import android.view.MenuItem;
import android.view.View;

class b extends v
{
  private ad d;

  public b(ActionMenuPresenter paramActionMenuPresenter, Context paramContext, ad paramad)
  {
    super(paramContext, paramad, null, false, android.support.v7.a.b.actionOverflowMenuStyle);
    this.d = paramad;
    View localView;
    int i;
    if (!((m)paramad.getItem()).j())
    {
      if (ActionMenuPresenter.d(paramActionMenuPresenter) == null)
      {
        localView = (View)ActionMenuPresenter.e(paramActionMenuPresenter);
        a(localView);
      }
    }
    else
    {
      a(paramActionMenuPresenter.g);
      i = paramad.size();
    }
    for (int j = 0; ; j++)
    {
      boolean bool = false;
      if (j < i)
      {
        MenuItem localMenuItem = paramad.getItem(j);
        if ((localMenuItem.isVisible()) && (localMenuItem.getIcon() != null))
          bool = true;
      }
      else
      {
        b(bool);
        return;
        localView = ActionMenuPresenter.d(paramActionMenuPresenter);
        break;
      }
    }
  }

  public void onDismiss()
  {
    super.onDismiss();
    ActionMenuPresenter.a(this.c, null);
    this.c.h = 0;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.b
 * JD-Core Version:    0.6.2
 */