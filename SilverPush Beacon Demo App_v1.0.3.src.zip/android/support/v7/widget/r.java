package android.support.v7.widget;

class r extends v
{
  public q a()
  {
    return this.a;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.r
 * JD-Core Version:    0.6.2
 */