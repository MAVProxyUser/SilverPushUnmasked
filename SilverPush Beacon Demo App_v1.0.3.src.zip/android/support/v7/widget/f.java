package android.support.v7.widget;

import android.view.View;

class f extends v
{
  f(e parame, View paramView, ActionMenuPresenter paramActionMenuPresenter)
  {
    super(paramView);
  }

  public q a()
  {
    if (ActionMenuPresenter.a(this.b.a) == null)
      return null;
    return ActionMenuPresenter.a(this.b.a).c();
  }

  public boolean b()
  {
    this.b.a.c();
    return true;
  }

  public boolean c()
  {
    if (ActionMenuPresenter.b(this.b.a) != null)
      return false;
    this.b.a.d();
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.f
 * JD-Core Version:    0.6.2
 */