package android.support.v7.widget;

import android.support.v7.internal.view.menu.i;
import android.view.View;

class d
  implements Runnable
{
  private g b;

  public d(ActionMenuPresenter paramActionMenuPresenter, g paramg)
  {
    this.b = paramg;
  }

  public void run()
  {
    ActionMenuPresenter.f(this.a).f();
    View localView = (View)ActionMenuPresenter.g(this.a);
    if ((localView != null) && (localView.getWindowToken() != null) && (this.b.d()))
      ActionMenuPresenter.a(this.a, this.b);
    ActionMenuPresenter.a(this.a, null);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.d
 * JD-Core Version:    0.6.2
 */