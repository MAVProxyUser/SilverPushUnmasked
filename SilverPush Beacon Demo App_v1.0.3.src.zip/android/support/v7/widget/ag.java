package android.support.v7.widget;

public abstract interface ag
{
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.widget.ag
 * JD-Core Version:    0.6.2
 */