package android.support.v7.a;

public final class i
{
  public static final int abc_action_bar_title_item = 2130968576;
  public static final int abc_action_bar_up_container = 2130968577;
  public static final int abc_action_bar_view_list_nav_layout = 2130968578;
  public static final int abc_action_menu_item_layout = 2130968579;
  public static final int abc_action_menu_layout = 2130968580;
  public static final int abc_action_mode_bar = 2130968581;
  public static final int abc_action_mode_close_item_material = 2130968582;
  public static final int abc_activity_chooser_view = 2130968583;
  public static final int abc_activity_chooser_view_include = 2130968584;
  public static final int abc_activity_chooser_view_list_item = 2130968585;
  public static final int abc_expanded_menu_layout = 2130968586;
  public static final int abc_list_menu_item_checkbox = 2130968587;
  public static final int abc_list_menu_item_icon = 2130968588;
  public static final int abc_list_menu_item_layout = 2130968589;
  public static final int abc_list_menu_item_radio = 2130968590;
  public static final int abc_popup_menu_item_layout = 2130968591;
  public static final int abc_screen_content_include = 2130968592;
  public static final int abc_screen_simple = 2130968593;
  public static final int abc_screen_simple_overlay_action_mode = 2130968594;
  public static final int abc_screen_toolbar = 2130968595;
  public static final int abc_search_dropdown_item_icons_2line = 2130968596;
  public static final int abc_search_view = 2130968597;
  public static final int abc_simple_dropdown_hint = 2130968598;
  public static final int support_simple_spinner_dropdown_item = 2130968601;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.i
 * JD-Core Version:    0.6.2
 */