package android.support.v7.a;

public final class d
{
  public static final int abc_background_cache_hint_selector_material_dark = 2131165244;
  public static final int abc_background_cache_hint_selector_material_light = 2131165245;
  public static final int abc_input_method_navigation_guard = 2131165186;
  public static final int abc_primary_text_disable_only_material_dark = 2131165246;
  public static final int abc_primary_text_disable_only_material_light = 2131165247;
  public static final int abc_primary_text_material_dark = 2131165248;
  public static final int abc_primary_text_material_light = 2131165249;
  public static final int abc_search_url_text = 2131165250;
  public static final int abc_search_url_text_normal = 2131165187;
  public static final int abc_search_url_text_pressed = 2131165188;
  public static final int abc_search_url_text_selected = 2131165189;
  public static final int abc_secondary_text_material_dark = 2131165251;
  public static final int abc_secondary_text_material_light = 2131165252;
  public static final int accent_material_dark = 2131165190;
  public static final int accent_material_light = 2131165191;
  public static final int background_floating_material_dark = 2131165192;
  public static final int background_floating_material_light = 2131165193;
  public static final int background_material_dark = 2131165194;
  public static final int background_material_light = 2131165195;
  public static final int bright_foreground_disabled_material_dark = 2131165196;
  public static final int bright_foreground_disabled_material_light = 2131165197;
  public static final int bright_foreground_inverse_material_dark = 2131165198;
  public static final int bright_foreground_inverse_material_light = 2131165199;
  public static final int bright_foreground_material_dark = 2131165200;
  public static final int bright_foreground_material_light = 2131165201;
  public static final int button_material_dark = 2131165202;
  public static final int button_material_light = 2131165203;
  public static final int dim_foreground_disabled_material_dark = 2131165213;
  public static final int dim_foreground_disabled_material_light = 2131165214;
  public static final int dim_foreground_material_dark = 2131165215;
  public static final int dim_foreground_material_light = 2131165216;
  public static final int highlighted_text_material_dark = 2131165217;
  public static final int highlighted_text_material_light = 2131165218;
  public static final int hint_foreground_material_dark = 2131165219;
  public static final int hint_foreground_material_light = 2131165220;
  public static final int link_text_material_dark = 2131165221;
  public static final int link_text_material_light = 2131165222;
  public static final int material_blue_grey_800 = 2131165223;
  public static final int material_blue_grey_900 = 2131165224;
  public static final int material_blue_grey_950 = 2131165225;
  public static final int material_deep_teal_200 = 2131165226;
  public static final int material_deep_teal_500 = 2131165227;
  public static final int primary_dark_material_dark = 2131165228;
  public static final int primary_dark_material_light = 2131165229;
  public static final int primary_material_dark = 2131165230;
  public static final int primary_material_light = 2131165231;
  public static final int primary_text_default_material_dark = 2131165232;
  public static final int primary_text_default_material_light = 2131165233;
  public static final int primary_text_disabled_material_dark = 2131165234;
  public static final int primary_text_disabled_material_light = 2131165235;
  public static final int ripple_material_dark = 2131165236;
  public static final int ripple_material_light = 2131165237;
  public static final int secondary_text_default_material_dark = 2131165238;
  public static final int secondary_text_default_material_light = 2131165239;
  public static final int secondary_text_disabled_material_dark = 2131165240;
  public static final int secondary_text_disabled_material_light = 2131165241;
  public static final int switch_thumb_normal_material_dark = 2131165242;
  public static final int switch_thumb_normal_material_light = 2131165243;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.d
 * JD-Core Version:    0.6.2
 */