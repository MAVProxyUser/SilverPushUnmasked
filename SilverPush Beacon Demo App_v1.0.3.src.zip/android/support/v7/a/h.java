package android.support.v7.a;

public final class h
{
  public static final int abc_max_action_buttons = 2131361792;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.h
 * JD-Core Version:    0.6.2
 */