package android.support.v7.a;

public final class e
{
  public static final int abc_action_bar_default_height_material = 2131230720;
  public static final int abc_action_bar_default_padding_material = 2131230721;
  public static final int abc_action_bar_icon_vertical_padding_material = 2131230722;
  public static final int abc_action_bar_progress_bar_size = 2131230723;
  public static final int abc_action_bar_stacked_max_height = 2131230724;
  public static final int abc_action_bar_stacked_tab_max_width = 2131230725;
  public static final int abc_action_bar_subtitle_bottom_margin_material = 2131230726;
  public static final int abc_action_bar_subtitle_top_margin_material = 2131230727;
  public static final int abc_action_button_min_height_material = 2131230728;
  public static final int abc_action_button_min_width_material = 2131230729;
  public static final int abc_action_button_min_width_overflow_material = 2131230730;
  public static final int abc_config_prefDialogWidth = 2131230731;
  public static final int abc_control_inset_material = 2131230732;
  public static final int abc_control_padding_material = 2131230733;
  public static final int abc_dropdownitem_icon_width = 2131230734;
  public static final int abc_dropdownitem_text_padding_left = 2131230735;
  public static final int abc_dropdownitem_text_padding_right = 2131230736;
  public static final int abc_panel_menu_list_width = 2131230737;
  public static final int abc_search_view_preferred_width = 2131230738;
  public static final int abc_search_view_text_min_width = 2131230739;
  public static final int abc_text_size_body_1_material = 2131230740;
  public static final int abc_text_size_body_2_material = 2131230741;
  public static final int abc_text_size_button_material = 2131230742;
  public static final int abc_text_size_caption_material = 2131230743;
  public static final int abc_text_size_display_1_material = 2131230744;
  public static final int abc_text_size_display_2_material = 2131230745;
  public static final int abc_text_size_display_3_material = 2131230746;
  public static final int abc_text_size_display_4_material = 2131230747;
  public static final int abc_text_size_headline_material = 2131230748;
  public static final int abc_text_size_large_material = 2131230749;
  public static final int abc_text_size_medium_material = 2131230750;
  public static final int abc_text_size_menu_material = 2131230751;
  public static final int abc_text_size_small_material = 2131230752;
  public static final int abc_text_size_subhead_material = 2131230753;
  public static final int abc_text_size_subtitle_material_toolbar = 2131230754;
  public static final int abc_text_size_title_material = 2131230755;
  public static final int abc_text_size_title_material_toolbar = 2131230756;
  public static final int dialog_fixed_height_major = 2131230760;
  public static final int dialog_fixed_height_minor = 2131230761;
  public static final int dialog_fixed_width_major = 2131230762;
  public static final int dialog_fixed_width_minor = 2131230763;
  public static final int disabled_alpha_material_dark = 2131230764;
  public static final int disabled_alpha_material_light = 2131230765;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.e
 * JD-Core Version:    0.6.2
 */