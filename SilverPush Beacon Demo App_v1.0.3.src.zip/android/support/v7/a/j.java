package android.support.v7.a;

public final class j
{
  public static final int abc_action_bar_home_description = 2131427328;
  public static final int abc_action_bar_home_description_format = 2131427329;
  public static final int abc_action_bar_home_subtitle_description_format = 2131427330;
  public static final int abc_action_bar_up_description = 2131427331;
  public static final int abc_action_menu_overflow_description = 2131427332;
  public static final int abc_action_mode_done = 2131427333;
  public static final int abc_activity_chooser_view_see_all = 2131427334;
  public static final int abc_activitychooserview_choose_application = 2131427335;
  public static final int abc_searchview_description_clear = 2131427336;
  public static final int abc_searchview_description_query = 2131427337;
  public static final int abc_searchview_description_search = 2131427338;
  public static final int abc_searchview_description_submit = 2131427339;
  public static final int abc_searchview_description_voice = 2131427340;
  public static final int abc_shareactionprovider_share_with = 2131427341;
  public static final int abc_shareactionprovider_share_with_application = 2131427342;
  public static final int abc_toolbar_collapse_description = 2131427343;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.j
 * JD-Core Version:    0.6.2
 */