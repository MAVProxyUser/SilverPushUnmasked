package android.support.v7.a;

public final class c
{
  public static final int abc_action_bar_embed_tabs = 2131099648;
  public static final int abc_action_bar_embed_tabs_pre_jb = 2131099649;
  public static final int abc_action_bar_expanded_action_views_exclusive = 2131099650;
  public static final int abc_config_actionMenuItemAllCaps = 2131099651;
  public static final int abc_config_allowActionMenuItemTextWithIcon = 2131099652;
  public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131099653;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.c
 * JD-Core Version:    0.6.2
 */