package android.support.v7.a;

public final class g
{
  public static final int action_bar = 2131296305;
  public static final int action_bar_activity_content = 2131296256;
  public static final int action_bar_container = 2131296304;
  public static final int action_bar_root = 2131296300;
  public static final int action_bar_spinner = 2131296257;
  public static final int action_bar_subtitle = 2131296287;
  public static final int action_bar_title = 2131296286;
  public static final int action_context_bar = 2131296306;
  public static final int action_menu_divider = 2131296258;
  public static final int action_menu_presenter = 2131296259;
  public static final int action_mode_bar = 2131296302;
  public static final int action_mode_bar_stub = 2131296301;
  public static final int action_mode_close_button = 2131296288;
  public static final int activity_chooser_view_content = 2131296289;
  public static final int always = 2131296278;
  public static final int beginning = 2131296275;
  public static final int checkbox = 2131296297;
  public static final int collapseActionView = 2131296279;
  public static final int decor_content_parent = 2131296303;
  public static final int default_activity_button = 2131296292;
  public static final int dialog = 2131296283;
  public static final int disableHome = 2131296268;
  public static final int dropdown = 2131296284;
  public static final int edit_query = 2131296307;
  public static final int end = 2131296276;
  public static final int expand_activities_button = 2131296290;
  public static final int expanded_menu = 2131296296;
  public static final int home = 2131296260;
  public static final int homeAsUp = 2131296269;
  public static final int icon = 2131296294;
  public static final int ifRoom = 2131296280;
  public static final int image = 2131296291;
  public static final int listMode = 2131296265;
  public static final int list_item = 2131296293;
  public static final int middle = 2131296277;
  public static final int never = 2131296281;
  public static final int none = 2131296270;
  public static final int normal = 2131296266;
  public static final int progress_circular = 2131296261;
  public static final int progress_horizontal = 2131296262;
  public static final int radio = 2131296299;
  public static final int search_badge = 2131296309;
  public static final int search_bar = 2131296308;
  public static final int search_button = 2131296310;
  public static final int search_close_btn = 2131296315;
  public static final int search_edit_frame = 2131296311;
  public static final int search_go_btn = 2131296317;
  public static final int search_mag_icon = 2131296312;
  public static final int search_plate = 2131296313;
  public static final int search_src_text = 2131296314;
  public static final int search_voice_btn = 2131296318;
  public static final int shortcut = 2131296298;
  public static final int showCustom = 2131296271;
  public static final int showHome = 2131296272;
  public static final int showTitle = 2131296273;
  public static final int split_action_bar = 2131296263;
  public static final int submit_area = 2131296316;
  public static final int tabMode = 2131296267;
  public static final int title = 2131296295;
  public static final int up = 2131296264;
  public static final int useLogo = 2131296274;
  public static final int withText = 2131296282;
  public static final int wrap_content = 2131296285;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.a.g
 * JD-Core Version:    0.6.2
 */