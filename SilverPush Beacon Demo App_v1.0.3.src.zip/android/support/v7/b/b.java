package android.support.v7.b;

import android.view.Menu;
import android.view.MenuItem;

public abstract interface b
{
  public abstract void a(a parama);

  public abstract boolean a(a parama, Menu paramMenu);

  public abstract boolean a(a parama, MenuItem paramMenuItem);

  public abstract boolean b(a parama, Menu paramMenu);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.b.b
 * JD-Core Version:    0.6.2
 */