package android.support.v7.b;

public abstract interface c
{
  public abstract void a();

  public abstract void b();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v7.b.c
 * JD-Core Version:    0.6.2
 */