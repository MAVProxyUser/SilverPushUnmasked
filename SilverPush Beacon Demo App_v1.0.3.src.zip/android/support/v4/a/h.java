package android.support.v4.a;

import android.content.ComponentName;
import android.content.Intent;

class h extends g
{
  public Intent a(ComponentName paramComponentName)
  {
    return j.a(paramComponentName);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.a.h
 * JD-Core Version:    0.6.2
 */