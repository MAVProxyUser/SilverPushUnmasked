package android.support.v4.a;

import android.content.ComponentName;
import android.content.Intent;

abstract interface f
{
  public abstract Intent a(ComponentName paramComponentName);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.a.f
 * JD-Core Version:    0.6.2
 */