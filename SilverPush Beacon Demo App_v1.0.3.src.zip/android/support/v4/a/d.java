package android.support.v4.a;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

class d
{
  public static void a(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    paramContext.startActivities(paramArrayOfIntent, paramBundle);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.a.d
 * JD-Core Version:    0.6.2
 */