package android.support.v4.a;

public abstract interface l
{
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.a.l
 * JD-Core Version:    0.6.2
 */