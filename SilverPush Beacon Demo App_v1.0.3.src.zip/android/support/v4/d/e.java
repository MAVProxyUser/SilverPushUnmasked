package android.support.v4.d;

import android.os.Parcelable.Creator;

class e
{
  static Parcelable.Creator a(c paramc)
  {
    return new d(paramc);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.d.e
 * JD-Core Version:    0.6.2
 */