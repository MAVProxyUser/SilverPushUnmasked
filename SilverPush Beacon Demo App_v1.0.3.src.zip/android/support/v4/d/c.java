package android.support.v4.d;

import android.os.Parcel;

public abstract interface c
{
  public abstract Object a(Parcel paramParcel, ClassLoader paramClassLoader);

  public abstract Object[] a(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.d.c
 * JD-Core Version:    0.6.2
 */