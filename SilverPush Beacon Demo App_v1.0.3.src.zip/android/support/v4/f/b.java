package android.support.v4.f;

import java.util.Map;

class b extends g
{
  b(a parama)
  {
  }

  protected int a()
  {
    return this.a.h;
  }

  protected int a(Object paramObject)
  {
    return this.a.a(paramObject);
  }

  protected Object a(int paramInt1, int paramInt2)
  {
    return this.a.g[(paramInt2 + (paramInt1 << 1))];
  }

  protected Object a(int paramInt, Object paramObject)
  {
    return this.a.a(paramInt, paramObject);
  }

  protected void a(int paramInt)
  {
    this.a.d(paramInt);
  }

  protected void a(Object paramObject1, Object paramObject2)
  {
    this.a.put(paramObject1, paramObject2);
  }

  protected int b(Object paramObject)
  {
    return this.a.b(paramObject);
  }

  protected Map b()
  {
    return this.a;
  }

  protected void c()
  {
    this.a.clear();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.f.b
 * JD-Core Version:    0.6.2
 */