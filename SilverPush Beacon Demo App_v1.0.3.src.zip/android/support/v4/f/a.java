package android.support.v4.f;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class a extends m
  implements Map
{
  g a;

  private g b()
  {
    if (this.a == null)
      this.a = new b(this);
    return this.a;
  }

  public boolean a(Collection paramCollection)
  {
    return g.c(this, paramCollection);
  }

  public Set entrySet()
  {
    return b().d();
  }

  public Set keySet()
  {
    return b().e();
  }

  public void putAll(Map paramMap)
  {
    a(this.h + paramMap.size());
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      put(localEntry.getKey(), localEntry.getValue());
    }
  }

  public Collection values()
  {
    return b().f();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.f.a
 * JD-Core Version:    0.6.2
 */