package android.support.v4.e;

class c
  implements b
{
  public String a(String paramString)
  {
    return null;
  }

  public String b(String paramString)
  {
    return paramString;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.e.c
 * JD-Core Version:    0.6.2
 */