package android.support.v4.e;

class d
  implements b
{
  public String a(String paramString)
  {
    return e.a(paramString);
  }

  public String b(String paramString)
  {
    return e.b(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.e.d
 * JD-Core Version:    0.6.2
 */