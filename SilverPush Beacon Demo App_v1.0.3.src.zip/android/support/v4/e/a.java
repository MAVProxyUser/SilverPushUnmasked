package android.support.v4.e;

import android.os.Build.VERSION;

public class a
{
  private static final b a = new c();

  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      a = new d();
      return;
    }
  }

  public static String a(String paramString)
  {
    return a.a(paramString);
  }

  public static String b(String paramString)
  {
    return a.b(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.e.a
 * JD-Core Version:    0.6.2
 */