package android.support.v4.e;

abstract interface b
{
  public abstract String a(String paramString);

  public abstract String b(String paramString);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.e.b
 * JD-Core Version:    0.6.2
 */