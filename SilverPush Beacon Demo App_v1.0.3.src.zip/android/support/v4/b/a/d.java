package android.support.v4.b.a;

import android.graphics.drawable.Drawable;

class d extends b
{
  public void a(Drawable paramDrawable)
  {
    g.a(paramDrawable);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.b.a.d
 * JD-Core Version:    0.6.2
 */