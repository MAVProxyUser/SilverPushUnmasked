package android.support.v4.b.a;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;

class b
  implements c
{
  public void a(Drawable paramDrawable)
  {
  }

  public void a(Drawable paramDrawable, float paramFloat1, float paramFloat2)
  {
  }

  public void a(Drawable paramDrawable, int paramInt)
  {
  }

  public void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
  }

  public void a(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
  }

  public void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
  {
  }

  public void a(Drawable paramDrawable, boolean paramBoolean)
  {
  }

  public boolean b(Drawable paramDrawable)
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.b.a.b
 * JD-Core Version:    0.6.2
 */