package android.support.v4.b.a;

import android.graphics.drawable.Drawable;

class e extends d
{
  public void a(Drawable paramDrawable, boolean paramBoolean)
  {
    h.a(paramDrawable, paramBoolean);
  }

  public boolean b(Drawable paramDrawable)
  {
    return h.a(paramDrawable);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.b.a.e
 * JD-Core Version:    0.6.2
 */