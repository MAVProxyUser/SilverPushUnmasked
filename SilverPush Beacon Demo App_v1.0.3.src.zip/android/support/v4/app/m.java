package android.support.v4.app;

public class m extends RuntimeException
{
  public m(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.m
 * JD-Core Version:    0.6.2
 */