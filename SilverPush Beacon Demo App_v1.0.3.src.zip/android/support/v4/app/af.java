package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.Map;

class af
{
  public static Object a(Object paramObject)
  {
    if (paramObject != null)
      paramObject = ((Transition)paramObject).clone();
    return paramObject;
  }

  public static Object a(Object paramObject, View paramView, ArrayList paramArrayList, Map paramMap)
  {
    if (paramObject != null)
    {
      b(paramArrayList, paramView);
      if (paramMap != null)
        paramArrayList.removeAll(paramMap.values());
      if (paramArrayList.isEmpty())
        paramObject = null;
    }
    else
    {
      return paramObject;
    }
    b((Transition)paramObject, paramArrayList);
    return paramObject;
  }

  public static Object a(Object paramObject1, Object paramObject2, Object paramObject3, boolean paramBoolean)
  {
    Transition localTransition1 = (Transition)paramObject1;
    Transition localTransition2 = (Transition)paramObject2;
    Transition localTransition3 = (Transition)paramObject3;
    if ((localTransition1 != null) && (localTransition2 != null));
    while (true)
    {
      if (paramBoolean)
      {
        TransitionSet localTransitionSet1 = new TransitionSet();
        if (localTransition1 != null)
          localTransitionSet1.addTransition(localTransition1);
        if (localTransition2 != null)
          localTransitionSet1.addTransition(localTransition2);
        if (localTransition3 != null)
          localTransitionSet1.addTransition(localTransition3);
        return localTransitionSet1;
      }
      Object localObject;
      if ((localTransition2 != null) && (localTransition1 != null))
        localObject = new TransitionSet().addTransition(localTransition2).addTransition(localTransition1).setOrdering(1);
      while (localTransition3 != null)
      {
        TransitionSet localTransitionSet2 = new TransitionSet();
        if (localObject != null)
          localTransitionSet2.addTransition((Transition)localObject);
        localTransitionSet2.addTransition(localTransition3);
        return localTransitionSet2;
        if (localTransition2 != null)
        {
          localObject = localTransition2;
        }
        else
        {
          localObject = null;
          if (localTransition1 != null)
            localObject = localTransition1;
        }
      }
      return localObject;
      paramBoolean = true;
    }
  }

  public static String a(View paramView)
  {
    return paramView.getTransitionName();
  }

  private static void a(Transition paramTransition, ak paramak)
  {
    if (paramTransition != null)
      paramTransition.setEpicenterCallback(new ai(paramak));
  }

  public static void a(View paramView1, View paramView2, Object paramObject1, ArrayList paramArrayList1, Object paramObject2, ArrayList paramArrayList2, Object paramObject3, ArrayList paramArrayList3, Object paramObject4, ArrayList paramArrayList4, Map paramMap)
  {
    Transition localTransition1 = (Transition)paramObject1;
    Transition localTransition2 = (Transition)paramObject2;
    Transition localTransition3 = (Transition)paramObject3;
    Transition localTransition4 = (Transition)paramObject4;
    if (localTransition4 != null)
      paramView1.getViewTreeObserver().addOnPreDrawListener(new aj(paramView1, localTransition1, paramView2, paramArrayList1, localTransition2, paramArrayList2, localTransition3, paramArrayList3, paramMap, paramArrayList4, localTransition4));
  }

  public static void a(ViewGroup paramViewGroup, Object paramObject)
  {
    TransitionManager.beginDelayedTransition(paramViewGroup, (Transition)paramObject);
  }

  public static void a(Object paramObject, View paramView)
  {
    ((Transition)paramObject).setEpicenterCallback(new ag(c(paramView)));
  }

  public static void a(Object paramObject, View paramView, boolean paramBoolean)
  {
    ((Transition)paramObject).excludeTarget(paramView, paramBoolean);
  }

  public static void a(Object paramObject1, Object paramObject2, View paramView1, al paramal, View paramView2, ak paramak, Map paramMap1, ArrayList paramArrayList1, Map paramMap2, ArrayList paramArrayList2)
  {
    if ((paramObject1 != null) || (paramObject2 != null))
    {
      Transition localTransition = (Transition)paramObject1;
      if (localTransition != null)
        localTransition.addTarget(paramView2);
      if (paramObject2 != null)
        b((Transition)paramObject2, paramArrayList2);
      if (paramal != null)
        paramView1.getViewTreeObserver().addOnPreDrawListener(new ah(paramView1, paramal, paramMap1, paramMap2, localTransition, paramArrayList1));
      a(localTransition, paramak);
    }
  }

  public static void a(Object paramObject, ArrayList paramArrayList)
  {
    Transition localTransition = (Transition)paramObject;
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
      localTransition.removeTarget((View)paramArrayList.get(j));
  }

  public static void a(Map paramMap, View paramView)
  {
    if (paramView.getVisibility() == 0)
    {
      String str = paramView.getTransitionName();
      if (str != null)
        paramMap.put(str, paramView);
      if ((paramView instanceof ViewGroup))
      {
        ViewGroup localViewGroup = (ViewGroup)paramView;
        int i = localViewGroup.getChildCount();
        for (int j = 0; j < i; j++)
          a(paramMap, localViewGroup.getChildAt(j));
      }
    }
  }

  public static void b(Object paramObject, ArrayList paramArrayList)
  {
    Transition localTransition = (Transition)paramObject;
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
      localTransition.addTarget((View)paramArrayList.get(j));
  }

  private static void b(ArrayList paramArrayList, View paramView)
  {
    ViewGroup localViewGroup;
    if (paramView.getVisibility() == 0)
    {
      if (!(paramView instanceof ViewGroup))
        break label65;
      localViewGroup = (ViewGroup)paramView;
      if (!localViewGroup.isTransitionGroup())
        break label33;
      paramArrayList.add(localViewGroup);
    }
    while (true)
    {
      return;
      label33: int i = localViewGroup.getChildCount();
      for (int j = 0; j < i; j++)
        b(paramArrayList, localViewGroup.getChildAt(j));
    }
    label65: paramArrayList.add(paramView);
  }

  private static Rect c(View paramView)
  {
    Rect localRect = new Rect();
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    localRect.set(arrayOfInt[0], arrayOfInt[1], arrayOfInt[0] + paramView.getWidth(), arrayOfInt[1] + paramView.getHeight());
    return localRect;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.af
 * JD-Core Version:    0.6.2
 */