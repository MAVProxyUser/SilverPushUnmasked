package android.support.v4.app;

import android.os.Build.VERSION;
import android.support.v4.f.a;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

final class e extends ae
  implements Runnable
{
  final v a;
  i b;
  i c;
  int d;
  int e;
  int f;
  int g;
  int h;
  int i;
  int j;
  boolean k;
  boolean l = true;
  String m;
  boolean n;
  int o = -1;
  int p;
  CharSequence q;
  int r;
  CharSequence s;
  ArrayList t;
  ArrayList u;

  public e(v paramv)
  {
    this.a = paramv;
  }

  private j a(SparseArray paramSparseArray1, SparseArray paramSparseArray2, boolean paramBoolean)
  {
    j localj = new j(this);
    localj.d = new View(this.a.o);
    int i1 = 0;
    int i2 = 0;
    int i3 = paramSparseArray1.size();
    int i4 = 0;
    if (i1 < i3)
      if (!a(paramSparseArray1.keyAt(i1), localj, paramBoolean, paramSparseArray1, paramSparseArray2))
        break label142;
    label142: for (int i6 = 1; ; i6 = i2)
    {
      i1++;
      i2 = i6;
      break;
      while (i4 < paramSparseArray2.size())
      {
        int i5 = paramSparseArray2.keyAt(i4);
        if ((paramSparseArray1.get(i5) == null) && (a(i5, localj, paramBoolean, paramSparseArray1, paramSparseArray2)))
          i2 = 1;
        i4++;
      }
      if (i2 == 0)
        localj = null;
      return localj;
    }
  }

  private a a(j paramj, Fragment paramFragment, boolean paramBoolean)
  {
    a locala = new a();
    if (this.t != null)
    {
      af.a(locala, paramFragment.h());
      if (!paramBoolean)
        break label74;
      locala.a(this.u);
    }
    while (paramBoolean)
    {
      if (paramFragment.Y != null)
        paramFragment.Y.a(this.u, locala);
      a(paramj, locala, false);
      return locala;
      label74: locala = a(this.t, this.u, locala);
    }
    if (paramFragment.Z != null)
      paramFragment.Z.a(this.u, locala);
    b(paramj, locala, false);
    return locala;
  }

  private a a(j paramj, boolean paramBoolean, Fragment paramFragment)
  {
    a locala = b(paramj, paramFragment, paramBoolean);
    if (paramBoolean)
    {
      if (paramFragment.Z != null)
        paramFragment.Z.a(this.u, locala);
      a(paramj, locala, true);
      return locala;
    }
    if (paramFragment.Y != null)
      paramFragment.Y.a(this.u, locala);
    b(paramj, locala, true);
    return locala;
  }

  private static a a(ArrayList paramArrayList1, ArrayList paramArrayList2, a parama)
  {
    if (parama.isEmpty())
      return parama;
    a locala = new a();
    int i1 = paramArrayList1.size();
    for (int i2 = 0; i2 < i1; i2++)
    {
      View localView = (View)parama.get(paramArrayList1.get(i2));
      if (localView != null)
        locala.put(paramArrayList2.get(i2), localView);
    }
    return locala;
  }

  private static Object a(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean)
  {
    if ((paramFragment1 == null) || (paramFragment2 == null))
      return null;
    if (paramBoolean);
    for (Object localObject = paramFragment2.w(); ; localObject = paramFragment1.v())
      return af.a(localObject);
  }

  private static Object a(Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null)
      return null;
    if (paramBoolean);
    for (Object localObject = paramFragment.u(); ; localObject = paramFragment.r())
      return af.a(localObject);
  }

  private static Object a(Object paramObject, Fragment paramFragment, ArrayList paramArrayList, a parama)
  {
    if (paramObject != null)
      paramObject = af.a(paramObject, paramFragment.h(), paramArrayList, parama);
    return paramObject;
  }

  private void a(int paramInt1, Fragment paramFragment, String paramString, int paramInt2)
  {
    paramFragment.t = this.a;
    if (paramString != null)
    {
      if ((paramFragment.z != null) && (!paramString.equals(paramFragment.z)))
        throw new IllegalStateException("Can't change tag of fragment " + paramFragment + ": was " + paramFragment.z + " now " + paramString);
      paramFragment.z = paramString;
    }
    if (paramInt1 != 0)
    {
      if ((paramFragment.x != 0) && (paramFragment.x != paramInt1))
        throw new IllegalStateException("Can't change container ID of fragment " + paramFragment + ": was " + paramFragment.x + " now " + paramInt1);
      paramFragment.x = paramInt1;
      paramFragment.y = paramInt1;
    }
    i locali = new i();
    locali.c = paramInt2;
    locali.d = paramFragment;
    a(locali);
  }

  private void a(j paramj, int paramInt, Object paramObject)
  {
    if (this.a.g != null)
    {
      int i1 = 0;
      if (i1 < this.a.g.size())
      {
        Fragment localFragment = (Fragment)this.a.g.get(i1);
        if ((localFragment.J != null) && (localFragment.I != null) && (localFragment.y == paramInt))
        {
          if (!localFragment.A)
            break label122;
          if (!paramj.b.contains(localFragment.J))
          {
            af.a(paramObject, localFragment.J, true);
            paramj.b.add(localFragment.J);
          }
        }
        while (true)
        {
          i1++;
          break;
          label122: af.a(paramObject, localFragment.J, false);
          paramj.b.remove(localFragment.J);
        }
      }
    }
  }

  private void a(j paramj, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, a parama)
  {
    if (paramBoolean);
    for (aw localaw = paramFragment2.Y; ; localaw = paramFragment1.Y)
    {
      if (localaw != null)
        localaw.b(new ArrayList(parama.keySet()), new ArrayList(parama.values()), null);
      return;
    }
  }

  private void a(j paramj, a parama, boolean paramBoolean)
  {
    int i1;
    int i2;
    label13: String str1;
    String str2;
    if (this.u == null)
    {
      i1 = 0;
      i2 = 0;
      if (i2 >= i1)
        return;
      str1 = (String)this.t.get(i2);
      View localView = (View)parama.get((String)this.u.get(i2));
      if (localView != null)
      {
        str2 = af.a(localView);
        if (!paramBoolean)
          break label100;
        a(paramj.a, str1, str2);
      }
    }
    while (true)
    {
      i2++;
      break label13;
      i1 = this.u.size();
      break;
      label100: a(paramj.a, str2, str1);
    }
  }

  private void a(j paramj, View paramView, Object paramObject, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean, ArrayList paramArrayList)
  {
    paramView.getViewTreeObserver().addOnPreDrawListener(new g(this, paramView, paramObject, paramArrayList, paramj, paramBoolean, paramFragment1, paramFragment2));
  }

  private static void a(j paramj, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    if (paramArrayList1 != null)
      for (int i1 = 0; i1 < paramArrayList1.size(); i1++)
      {
        String str1 = (String)paramArrayList1.get(i1);
        String str2 = (String)paramArrayList2.get(i1);
        a(paramj.a, str1, str2);
      }
  }

  private void a(a parama, j paramj)
  {
    if ((this.u != null) && (!parama.isEmpty()))
    {
      View localView = (View)parama.get(this.u.get(0));
      if (localView != null)
        paramj.c.a = localView;
    }
  }

  private static void a(a parama, String paramString1, String paramString2)
  {
    if ((paramString1 != null) && (paramString2 != null) && (!paramString1.equals(paramString2)));
    for (int i1 = 0; i1 < parama.size(); i1++)
      if (paramString1.equals(parama.c(i1)))
      {
        parama.a(i1, paramString2);
        return;
      }
    parama.put(paramString1, paramString2);
  }

  private static void a(SparseArray paramSparseArray, Fragment paramFragment)
  {
    if (paramFragment != null)
    {
      int i1 = paramFragment.y;
      if ((i1 != 0) && (!paramFragment.g()) && (paramFragment.e()) && (paramFragment.h() != null) && (paramSparseArray.get(i1) == null))
        paramSparseArray.put(i1, paramFragment);
    }
  }

  private void a(View paramView, j paramj, int paramInt, Object paramObject)
  {
    paramView.getViewTreeObserver().addOnPreDrawListener(new h(this, paramView, paramj, paramInt, paramObject));
  }

  private boolean a(int paramInt, j paramj, boolean paramBoolean, SparseArray paramSparseArray1, SparseArray paramSparseArray2)
  {
    ViewGroup localViewGroup = (ViewGroup)this.a.p.a(paramInt);
    if (localViewGroup == null)
      return false;
    Fragment localFragment1 = (Fragment)paramSparseArray2.get(paramInt);
    Fragment localFragment2 = (Fragment)paramSparseArray1.get(paramInt);
    Object localObject1 = a(localFragment1, paramBoolean);
    Object localObject2 = a(localFragment1, localFragment2, paramBoolean);
    Object localObject3 = b(localFragment2, paramBoolean);
    if ((localObject1 == null) && (localObject2 == null) && (localObject3 == null))
      return false;
    ArrayList localArrayList1 = new ArrayList();
    a locala1 = null;
    aw localaw;
    if (localObject2 != null)
    {
      locala1 = a(paramj, localFragment2, paramBoolean);
      if (!locala1.isEmpty())
        break label442;
      localArrayList1.add(paramj.d);
      if (!paramBoolean)
        break label456;
      localaw = localFragment2.Y;
      label146: if (localaw != null)
        localaw.a(new ArrayList(locala1.keySet()), new ArrayList(locala1.values()), null);
    }
    ArrayList localArrayList2 = new ArrayList();
    Object localObject4 = a(localObject3, localFragment2, localArrayList2, locala1);
    if ((this.u != null) && (locala1 != null))
    {
      View localView = (View)locala1.get(this.u.get(0));
      if (localView != null)
      {
        if (localObject4 != null)
          af.a(localObject4, localView);
        if (localObject2 != null)
          af.a(localObject2, localView);
      }
    }
    f localf = new f(this, localFragment1);
    if (localObject2 != null)
      a(paramj, localViewGroup, localObject2, localFragment1, localFragment2, paramBoolean, localArrayList1);
    ArrayList localArrayList3 = new ArrayList();
    a locala2 = new a();
    if (paramBoolean);
    for (boolean bool = localFragment1.y(); ; bool = localFragment1.x())
    {
      Object localObject5 = af.a(localObject1, localObject4, localObject2, bool);
      if (localObject5 != null)
      {
        af.a(localObject1, localObject2, localViewGroup, localf, paramj.d, paramj.c, paramj.a, localArrayList3, locala2, localArrayList1);
        a(localViewGroup, paramj, paramInt, localObject5);
        af.a(localObject5, paramj.d, true);
        a(paramj, paramInt, localObject5);
        af.a(localViewGroup, localObject5);
        af.a(localViewGroup, paramj.d, localObject1, localArrayList3, localObject4, localArrayList2, localObject2, localArrayList1, localObject5, paramj.b, locala2);
      }
      if (localObject5 == null)
        break label476;
      return true;
      label442: localArrayList1.addAll(locala1.values());
      break;
      label456: localaw = localFragment1.Y;
      break label146;
    }
    label476: return false;
  }

  private a b(j paramj, Fragment paramFragment, boolean paramBoolean)
  {
    a locala = new a();
    View localView = paramFragment.h();
    if ((localView != null) && (this.t != null))
    {
      af.a(locala, localView);
      if (paramBoolean)
        locala = a(this.t, this.u, locala);
    }
    else
    {
      return locala;
    }
    locala.a(this.u);
    return locala;
  }

  private static Object b(Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null)
      return null;
    if (paramBoolean);
    for (Object localObject = paramFragment.s(); ; localObject = paramFragment.t())
      return af.a(localObject);
  }

  private void b(j paramj, a parama, boolean paramBoolean)
  {
    int i1 = parama.size();
    int i2 = 0;
    if (i2 < i1)
    {
      String str1 = (String)parama.b(i2);
      String str2 = af.a((View)parama.c(i2));
      if (paramBoolean)
        a(paramj.a, str1, str2);
      while (true)
      {
        i2++;
        break;
        a(paramj.a, str2, str1);
      }
    }
  }

  private void b(SparseArray paramSparseArray, Fragment paramFragment)
  {
    if (paramFragment != null)
    {
      int i1 = paramFragment.y;
      if (i1 != 0)
        paramSparseArray.put(i1, paramFragment);
    }
  }

  private void b(SparseArray paramSparseArray1, SparseArray paramSparseArray2)
  {
    if (!this.a.p.a());
    i locali;
    do
    {
      return;
      locali = this.b;
    }
    while (locali == null);
    switch (locali.c)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (true)
    {
      locali = locali.a;
      break;
      b(paramSparseArray2, locali.d);
      continue;
      Fragment localFragment1 = locali.d;
      Fragment localFragment2;
      if (this.a.g != null)
      {
        localFragment2 = localFragment1;
        int i1 = 0;
        if (i1 < this.a.g.size())
        {
          Fragment localFragment3 = (Fragment)this.a.g.get(i1);
          if ((localFragment2 == null) || (localFragment3.y == localFragment2.y))
          {
            if (localFragment3 != localFragment2)
              break label181;
            localFragment2 = null;
          }
          while (true)
          {
            i1++;
            break;
            label181: a(paramSparseArray1, localFragment3);
          }
        }
      }
      else
      {
        localFragment2 = localFragment1;
      }
      b(paramSparseArray2, localFragment2);
      continue;
      a(paramSparseArray1, locali.d);
      continue;
      a(paramSparseArray1, locali.d);
      continue;
      b(paramSparseArray2, locali.d);
      continue;
      a(paramSparseArray1, locali.d);
      continue;
      b(paramSparseArray2, locali.d);
    }
  }

  public int a()
  {
    return a(false);
  }

  int a(boolean paramBoolean)
  {
    if (this.n)
      throw new IllegalStateException("commit already called");
    if (v.a)
    {
      Log.v("FragmentManager", "Commit: " + this);
      a("  ", null, new PrintWriter(new android.support.v4.f.e("FragmentManager")), null);
    }
    this.n = true;
    if (this.k);
    for (this.o = this.a.a(this); ; this.o = -1)
    {
      this.a.a(this, paramBoolean);
      return this.o;
    }
  }

  public ae a(int paramInt, Fragment paramFragment, String paramString)
  {
    a(paramInt, paramFragment, paramString, 1);
    return this;
  }

  public ae a(Fragment paramFragment)
  {
    i locali = new i();
    locali.c = 6;
    locali.d = paramFragment;
    a(locali);
    return this;
  }

  public j a(boolean paramBoolean, j paramj, SparseArray paramSparseArray1, SparseArray paramSparseArray2)
  {
    if (v.a)
    {
      Log.v("FragmentManager", "popFromBackStack: " + this);
      a("  ", null, new PrintWriter(new android.support.v4.f.e("FragmentManager")), null);
    }
    label87: int i1;
    label99: int i2;
    label106: i locali;
    int i3;
    if (paramj == null)
    {
      if ((paramSparseArray1.size() != 0) || (paramSparseArray2.size() != 0))
        paramj = a(paramSparseArray1, paramSparseArray2, true);
      a(-1);
      if (paramj == null)
        break label231;
      i1 = 0;
      if (paramj == null)
        break label240;
      i2 = 0;
      locali = this.c;
      if (locali == null)
        break label565;
      if (paramj == null)
        break label249;
      i3 = 0;
      label124: if (paramj == null)
        break label259;
    }
    label259: for (int i4 = 0; ; i4 = locali.h)
      switch (locali.c)
      {
      default:
        throw new IllegalArgumentException("Unknown cmd: " + locali.c);
        if (paramBoolean)
          break label87;
        a(paramj, this.u, this.t);
        break label87;
        label231: i1 = this.j;
        break label99;
        label240: i2 = this.i;
        break label106;
        label249: i3 = locali.g;
        break label124;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      }
    Fragment localFragment8 = locali.d;
    localFragment8.H = i4;
    this.a.a(localFragment8, v.c(i2), i1);
    while (true)
    {
      locali = locali.b;
      break;
      Fragment localFragment6 = locali.d;
      if (localFragment6 != null)
      {
        localFragment6.H = i4;
        this.a.a(localFragment6, v.c(i2), i1);
      }
      if (locali.i != null)
      {
        for (int i5 = 0; i5 < locali.i.size(); i5++)
        {
          Fragment localFragment7 = (Fragment)locali.i.get(i5);
          localFragment7.H = i3;
          this.a.a(localFragment7, false);
        }
        Fragment localFragment5 = locali.d;
        localFragment5.H = i3;
        this.a.a(localFragment5, false);
        continue;
        Fragment localFragment4 = locali.d;
        localFragment4.H = i3;
        this.a.c(localFragment4, v.c(i2), i1);
        continue;
        Fragment localFragment3 = locali.d;
        localFragment3.H = i4;
        this.a.b(localFragment3, v.c(i2), i1);
        continue;
        Fragment localFragment2 = locali.d;
        localFragment2.H = i3;
        this.a.e(localFragment2, v.c(i2), i1);
        continue;
        Fragment localFragment1 = locali.d;
        localFragment1.H = i3;
        this.a.d(localFragment1, v.c(i2), i1);
      }
    }
    label565: if (paramBoolean)
    {
      this.a.a(this.a.n, v.c(i2), i1, true);
      paramj = null;
    }
    if (this.o >= 0)
    {
      this.a.b(this.o);
      this.o = -1;
    }
    return paramj;
  }

  void a(int paramInt)
  {
    if (!this.k);
    while (true)
    {
      return;
      if (v.a)
        Log.v("FragmentManager", "Bump nesting in " + this + " by " + paramInt);
      for (i locali = this.b; locali != null; locali = locali.a)
      {
        if (locali.d != null)
        {
          Fragment localFragment2 = locali.d;
          localFragment2.s = (paramInt + localFragment2.s);
          if (v.a)
            Log.v("FragmentManager", "Bump nesting of " + locali.d + " to " + locali.d.s);
        }
        if (locali.i != null)
          for (int i1 = -1 + locali.i.size(); i1 >= 0; i1--)
          {
            Fragment localFragment1 = (Fragment)locali.i.get(i1);
            localFragment1.s = (paramInt + localFragment1.s);
            if (v.a)
              Log.v("FragmentManager", "Bump nesting of " + localFragment1 + " to " + localFragment1.s);
          }
      }
    }
  }

  void a(i parami)
  {
    if (this.b == null)
    {
      this.c = parami;
      this.b = parami;
    }
    while (true)
    {
      parami.e = this.e;
      parami.f = this.f;
      parami.g = this.g;
      parami.h = this.h;
      this.d = (1 + this.d);
      return;
      parami.b = this.c;
      this.c.a = parami;
      this.c = parami;
    }
  }

  public void a(SparseArray paramSparseArray1, SparseArray paramSparseArray2)
  {
    if (!this.a.p.a());
    i locali;
    do
    {
      return;
      locali = this.b;
    }
    while (locali == null);
    switch (locali.c)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (true)
    {
      locali = locali.a;
      break;
      a(paramSparseArray1, locali.d);
      continue;
      if (locali.i != null)
        for (int i1 = -1 + locali.i.size(); i1 >= 0; i1--)
          b(paramSparseArray2, (Fragment)locali.i.get(i1));
      a(paramSparseArray1, locali.d);
      continue;
      b(paramSparseArray2, locali.d);
      continue;
      b(paramSparseArray2, locali.d);
      continue;
      a(paramSparseArray1, locali.d);
      continue;
      b(paramSparseArray2, locali.d);
      continue;
      a(paramSparseArray1, locali.d);
    }
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    a(paramString, paramPrintWriter, true);
  }

  public void a(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.m);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.o);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.n);
      if (this.i != 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.i));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.j));
      }
      if ((this.e != 0) || (this.f != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.e));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.f));
      }
      if ((this.g != 0) || (this.h != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.g));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.h));
      }
      if ((this.p != 0) || (this.q != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.p));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.q);
      }
      if ((this.r != 0) || (this.s != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.r));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.s);
      }
    }
    if (this.b != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      String str1 = paramString + "    ";
      i locali1 = this.b;
      int i1 = 0;
      i locali2 = locali1;
      while (locali2 != null)
      {
        String str2;
        int i2;
        switch (locali2.c)
        {
        default:
          str2 = "cmd=" + locali2.c;
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  Op #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.print(str2);
          paramPrintWriter.print(" ");
          paramPrintWriter.println(locali2.d);
          if (paramBoolean)
          {
            if ((locali2.e != 0) || (locali2.f != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("enterAnim=#");
              paramPrintWriter.print(Integer.toHexString(locali2.e));
              paramPrintWriter.print(" exitAnim=#");
              paramPrintWriter.println(Integer.toHexString(locali2.f));
            }
            if ((locali2.g != 0) || (locali2.h != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("popEnterAnim=#");
              paramPrintWriter.print(Integer.toHexString(locali2.g));
              paramPrintWriter.print(" popExitAnim=#");
              paramPrintWriter.println(Integer.toHexString(locali2.h));
            }
          }
          if ((locali2.i == null) || (locali2.i.size() <= 0))
            break label808;
          i2 = 0;
          label645: if (i2 >= locali2.i.size())
            break label808;
          paramPrintWriter.print(str1);
          if (locali2.i.size() == 1)
            paramPrintWriter.print("Removed: ");
          break;
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        }
        while (true)
        {
          paramPrintWriter.println(locali2.i.get(i2));
          i2++;
          break label645;
          str2 = "NULL";
          break;
          str2 = "ADD";
          break;
          str2 = "REPLACE";
          break;
          str2 = "REMOVE";
          break;
          str2 = "HIDE";
          break;
          str2 = "SHOW";
          break;
          str2 = "DETACH";
          break;
          str2 = "ATTACH";
          break;
          if (i2 == 0)
            paramPrintWriter.println("Removed:");
          paramPrintWriter.print(str1);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i2);
          paramPrintWriter.print(": ");
        }
        label808: locali2 = locali2.a;
        i1++;
      }
    }
  }

  public ae b(Fragment paramFragment)
  {
    i locali = new i();
    locali.c = 7;
    locali.d = paramFragment;
    a(locali);
    return this;
  }

  public String b()
  {
    return this.m;
  }

  public void run()
  {
    if (v.a)
      Log.v("FragmentManager", "Run: " + this);
    if ((this.k) && (this.o < 0))
      throw new IllegalStateException("addToBackStack() called after commit()");
    a(1);
    SparseArray localSparseArray1;
    SparseArray localSparseArray2;
    if (Build.VERSION.SDK_INT >= 21)
    {
      localSparseArray1 = new SparseArray();
      localSparseArray2 = new SparseArray();
      b(localSparseArray1, localSparseArray2);
    }
    for (j localj = a(localSparseArray1, localSparseArray2, false); ; localj = null)
    {
      int i1;
      label108: int i2;
      label115: i locali;
      int i3;
      if (localj != null)
      {
        i1 = 0;
        if (localj == null)
          break label229;
        i2 = 0;
        locali = this.b;
        if (locali == null)
          break label733;
        if (localj == null)
          break label238;
        i3 = 0;
        label133: if (localj == null)
          break label248;
      }
      label229: label238: label248: for (int i4 = 0; ; i4 = locali.f)
        switch (locali.c)
        {
        default:
          throw new IllegalArgumentException("Unknown cmd: " + locali.c);
          i1 = this.j;
          break label108;
          i2 = this.i;
          break label115;
          i3 = locali.e;
          break label133;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        }
      Fragment localFragment9 = locali.d;
      localFragment9.H = i3;
      this.a.a(localFragment9, false);
      while (true)
      {
        locali = locali.a;
        break;
        Fragment localFragment6 = locali.d;
        Fragment localFragment7;
        if (this.a.g != null)
        {
          int i5 = 0;
          localFragment7 = localFragment6;
          if (i5 < this.a.g.size())
          {
            Fragment localFragment8 = (Fragment)this.a.g.get(i5);
            if (v.a)
              Log.v("FragmentManager", "OP_REPLACE: adding=" + localFragment7 + " old=" + localFragment8);
            if ((localFragment7 == null) || (localFragment8.y == localFragment7.y))
            {
              if (localFragment8 != localFragment7)
                break label433;
              locali.d = null;
              localFragment7 = null;
            }
            while (true)
            {
              i5++;
              break;
              label433: if (locali.i == null)
                locali.i = new ArrayList();
              locali.i.add(localFragment8);
              localFragment8.H = i4;
              if (this.k)
              {
                localFragment8.s = (1 + localFragment8.s);
                if (v.a)
                  Log.v("FragmentManager", "Bump nesting of " + localFragment8 + " to " + localFragment8.s);
              }
              this.a.a(localFragment8, i2, i1);
            }
          }
        }
        else
        {
          localFragment7 = localFragment6;
        }
        if (localFragment7 != null)
        {
          localFragment7.H = i3;
          this.a.a(localFragment7, false);
          continue;
          Fragment localFragment5 = locali.d;
          localFragment5.H = i4;
          this.a.a(localFragment5, i2, i1);
          continue;
          Fragment localFragment4 = locali.d;
          localFragment4.H = i4;
          this.a.b(localFragment4, i2, i1);
          continue;
          Fragment localFragment3 = locali.d;
          localFragment3.H = i3;
          this.a.c(localFragment3, i2, i1);
          continue;
          Fragment localFragment2 = locali.d;
          localFragment2.H = i4;
          this.a.d(localFragment2, i2, i1);
          continue;
          Fragment localFragment1 = locali.d;
          localFragment1.H = i3;
          this.a.e(localFragment1, i2, i1);
        }
      }
      label733: this.a.a(this.a.n, i2, i1, true);
      if (this.k)
        this.a.b(this);
      return;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("BackStackEntry{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.o >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(this.o);
    }
    if (this.m != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(this.m);
    }
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.e
 * JD-Core Version:    0.6.2
 */