package android.support.v4.app;

class y
{
  public static final int[] a = { 16842755, 16842960, 16842961 };
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.y
 * JD-Core Version:    0.6.2
 */