package android.support.v4.app;

import android.content.Context;
import android.os.Parcelable;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import java.util.ArrayList;

public class FragmentTabHost extends TabHost
  implements TabHost.OnTabChangeListener
{
  private final ArrayList a;
  private Context b;
  private t c;
  private int d;
  private TabHost.OnTabChangeListener e;
  private ad f;
  private boolean g;

  private ae a(String paramString, ae paramae)
  {
    Object localObject1 = null;
    int i = 0;
    Object localObject2;
    if (i < this.a.size())
    {
      localObject2 = (ad)this.a.get(i);
      if (!ad.b((ad)localObject2).equals(paramString))
        break label202;
    }
    while (true)
    {
      i++;
      localObject1 = localObject2;
      break;
      if (localObject1 == null)
        throw new IllegalStateException("No tab known for tag " + paramString);
      if (this.f != localObject1)
      {
        if (paramae == null)
          paramae = this.c.a();
        if ((this.f != null) && (ad.a(this.f) != null))
          paramae.a(ad.a(this.f));
        if (localObject1 != null)
        {
          if (ad.a(localObject1) != null)
            break label190;
          ad.a(localObject1, Fragment.a(this.b, ad.c(localObject1).getName(), ad.d(localObject1)));
          paramae.a(this.d, ad.a(localObject1), ad.b(localObject1));
        }
      }
      while (true)
      {
        this.f = localObject1;
        return paramae;
        label190: paramae.b(ad.a(localObject1));
      }
      label202: localObject2 = localObject1;
    }
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = getCurrentTabTag();
    ae localae1 = null;
    int i = 0;
    if (i < this.a.size())
    {
      ad localad = (ad)this.a.get(i);
      ad.a(localad, this.c.a(ad.b(localad)));
      if ((ad.a(localad) != null) && (!ad.a(localad).f()))
      {
        if (!ad.b(localad).equals(str))
          break label98;
        this.f = localad;
      }
      while (true)
      {
        i++;
        break;
        label98: if (localae1 == null)
          localae1 = this.c.a();
        localae1.a(ad.a(localad));
      }
    }
    this.g = true;
    ae localae2 = a(str, localae1);
    if (localae2 != null)
    {
      localae2.a();
      this.c.b();
    }
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.g = false;
  }

  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    FragmentTabHost.SavedState localSavedState = (FragmentTabHost.SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    setCurrentTabByTag(localSavedState.a);
  }

  protected Parcelable onSaveInstanceState()
  {
    FragmentTabHost.SavedState localSavedState = new FragmentTabHost.SavedState(super.onSaveInstanceState());
    localSavedState.a = getCurrentTabTag();
    return localSavedState;
  }

  public void onTabChanged(String paramString)
  {
    if (this.g)
    {
      ae localae = a(paramString, null);
      if (localae != null)
        localae.a();
    }
    if (this.e != null)
      this.e.onTabChanged(paramString);
  }

  public void setOnTabChangedListener(TabHost.OnTabChangeListener paramOnTabChangeListener)
  {
    this.e = paramOnTabChangeListener;
  }

  @Deprecated
  public void setup()
  {
    throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.FragmentTabHost
 * JD-Core Version:    0.6.2
 */