package android.support.v4.app;

import android.view.View;

public abstract interface al
{
  public abstract View a();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.al
 * JD-Core Version:    0.6.2
 */