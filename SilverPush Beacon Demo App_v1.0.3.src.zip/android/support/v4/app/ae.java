package android.support.v4.app;

public abstract class ae
{
  public abstract int a();

  public abstract ae a(int paramInt, Fragment paramFragment, String paramString);

  public abstract ae a(Fragment paramFragment);

  public abstract ae b(Fragment paramFragment);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.ae
 * JD-Core Version:    0.6.2
 */