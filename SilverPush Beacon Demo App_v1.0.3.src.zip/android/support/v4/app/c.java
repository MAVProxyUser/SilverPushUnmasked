package android.support.v4.app;

import android.app.Activity;

class c
{
  static void a(Activity paramActivity)
  {
    paramActivity.invalidateOptionsMenu();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.c
 * JD-Core Version:    0.6.2
 */