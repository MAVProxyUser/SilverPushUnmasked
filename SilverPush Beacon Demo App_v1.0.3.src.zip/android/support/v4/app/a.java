package android.support.v4.app;

import android.app.Activity;
import android.os.Build.VERSION;

public class a extends android.support.v4.a.a
{
  public static void a(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      d.a(paramActivity);
      return;
    }
    paramActivity.finish();
  }

  public static void b(Activity paramActivity)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      b.a(paramActivity);
      return;
    }
    paramActivity.finish();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.a
 * JD-Core Version:    0.6.2
 */