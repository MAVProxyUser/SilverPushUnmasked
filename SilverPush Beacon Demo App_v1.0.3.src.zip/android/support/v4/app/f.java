package android.support.v4.app;

import android.view.View;

class f
  implements al
{
  f(e parame, Fragment paramFragment)
  {
  }

  public View a()
  {
    return this.a.h();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.f
 * JD-Core Version:    0.6.2
 */