package android.support.v4.app;

import android.support.v4.f.a;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;

class g
  implements ViewTreeObserver.OnPreDrawListener
{
  g(e parame, View paramView, Object paramObject, ArrayList paramArrayList, j paramj, boolean paramBoolean, Fragment paramFragment1, Fragment paramFragment2)
  {
  }

  public boolean onPreDraw()
  {
    this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    a locala;
    if (this.b != null)
    {
      af.a(this.b, this.c);
      this.c.clear();
      locala = e.a(this.h, this.d, this.e, this.f);
      if (!locala.isEmpty())
        break label127;
      this.c.add(this.d.d);
    }
    while (true)
    {
      af.b(this.b, this.c);
      e.a(this.h, locala, this.d);
      e.a(this.h, this.d, this.f, this.g, this.e, locala);
      return true;
      label127: this.c.addAll(locala.values());
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.g
 * JD-Core Version:    0.6.2
 */