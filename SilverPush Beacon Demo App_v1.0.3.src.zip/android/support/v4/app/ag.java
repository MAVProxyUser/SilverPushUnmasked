package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class ag extends Transition.EpicenterCallback
{
  ag(Rect paramRect)
  {
  }

  public Rect onGetEpicenter(Transition paramTransition)
  {
    return this.a;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.ag
 * JD-Core Version:    0.6.2
 */