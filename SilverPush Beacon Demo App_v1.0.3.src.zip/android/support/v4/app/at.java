package android.support.v4.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;

class at extends as
{
  public Intent a(Activity paramActivity)
  {
    Intent localIntent = au.a(paramActivity);
    if (localIntent == null)
      localIntent = b(paramActivity);
    return localIntent;
  }

  public String a(Context paramContext, ActivityInfo paramActivityInfo)
  {
    String str = au.a(paramActivityInfo);
    if (str == null)
      str = super.a(paramContext, paramActivityInfo);
    return str;
  }

  public boolean a(Activity paramActivity, Intent paramIntent)
  {
    return au.a(paramActivity, paramIntent);
  }

  Intent b(Activity paramActivity)
  {
    return super.a(paramActivity);
  }

  public void b(Activity paramActivity, Intent paramIntent)
  {
    au.b(paramActivity, paramIntent);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.at
 * JD-Core Version:    0.6.2
 */