package android.support.v4.app;

import android.app.Activity;

class b
{
  public static void a(Activity paramActivity)
  {
    paramActivity.finishAfterTransition();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.b
 * JD-Core Version:    0.6.2
 */