package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class ax extends AndroidRuntimeException
{
  public ax(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.ax
 * JD-Core Version:    0.6.2
 */