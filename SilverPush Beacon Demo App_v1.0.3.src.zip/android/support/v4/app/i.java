package android.support.v4.app;

import java.util.ArrayList;

final class i
{
  i a;
  i b;
  int c;
  Fragment d;
  int e;
  int f;
  int g;
  int h;
  ArrayList i;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.i
 * JD-Core Version:    0.6.2
 */