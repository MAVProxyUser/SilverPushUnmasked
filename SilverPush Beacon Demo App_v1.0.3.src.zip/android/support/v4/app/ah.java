package android.support.v4.app;

import android.transition.Transition;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class ah
  implements ViewTreeObserver.OnPreDrawListener
{
  ah(View paramView, al paramal, Map paramMap1, Map paramMap2, Transition paramTransition, ArrayList paramArrayList)
  {
  }

  public boolean onPreDraw()
  {
    this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    View localView1 = this.b.a();
    if (localView1 != null)
    {
      if (!this.c.isEmpty())
      {
        af.a(this.d, localView1);
        this.d.keySet().retainAll(this.c.values());
        Iterator localIterator = this.c.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          String str = (String)localEntry.getValue();
          View localView2 = (View)this.d.get(str);
          if (localView2 != null)
            localView2.setTransitionName((String)localEntry.getKey());
        }
      }
      if (this.e != null)
      {
        af.a(this.f, localView1);
        this.f.removeAll(this.d.values());
        af.b(this.e, this.f);
      }
    }
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.ah
 * JD-Core Version:    0.6.2
 */