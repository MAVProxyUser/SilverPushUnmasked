package android.support.v4.app;

import android.view.View;

class l
  implements s
{
  l(Fragment paramFragment)
  {
  }

  public View a(int paramInt)
  {
    if (this.a.J == null)
      throw new IllegalStateException("Fragment does not have a view");
    return this.a.J.findViewById(paramInt);
  }

  public boolean a()
  {
    return this.a.J != null;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.l
 * JD-Core Version:    0.6.2
 */