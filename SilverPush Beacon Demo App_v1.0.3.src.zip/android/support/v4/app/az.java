package android.support.v4.app;

import android.content.Intent;

public abstract interface az
{
  public abstract Intent a();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.az
 * JD-Core Version:    0.6.2
 */