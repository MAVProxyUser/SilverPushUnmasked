package android.support.v4.app;

import android.view.View;
import android.view.Window;

class q
  implements s
{
  q(o paramo)
  {
  }

  public View a(int paramInt)
  {
    return this.a.findViewById(paramInt);
  }

  public boolean a()
  {
    Window localWindow = this.a.getWindow();
    return (localWindow != null) && (localWindow.peekDecorView() != null);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.q
 * JD-Core Version:    0.6.2
 */