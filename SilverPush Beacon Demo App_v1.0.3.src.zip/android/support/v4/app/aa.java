package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class aa
  implements Parcelable.Creator
{
  public FragmentState a(Parcel paramParcel)
  {
    return new FragmentState(paramParcel);
  }

  public FragmentState[] a(int paramInt)
  {
    return new FragmentState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.aa
 * JD-Core Version:    0.6.2
 */