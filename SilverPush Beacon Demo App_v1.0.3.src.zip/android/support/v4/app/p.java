package android.support.v4.app;

import android.os.Handler;
import android.os.Message;

class p extends Handler
{
  p(o paramo)
  {
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 1:
      do
        return;
      while (!this.a.f);
      this.a.a(false);
      return;
    case 2:
    }
    this.a.b();
    this.a.b.e();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.p
 * JD-Core Version:    0.6.2
 */