package android.support.v4.app;

import android.support.v4.f.a;
import android.view.View;
import java.util.ArrayList;

public class j
{
  public a a = new a();
  public ArrayList b = new ArrayList();
  public ak c = new ak();
  public View d;

  public j(e parame)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.j
 * JD-Core Version:    0.6.2
 */