package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.a.k;

public abstract interface an
{
  public abstract k a(int paramInt, Bundle paramBundle);

  public abstract void a(k paramk);

  public abstract void a(k paramk, Object paramObject);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.an
 * JD-Core Version:    0.6.2
 */