package android.support.v4.app;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;

class h
  implements ViewTreeObserver.OnPreDrawListener
{
  h(e parame, View paramView, j paramj, int paramInt, Object paramObject)
  {
  }

  public boolean onPreDraw()
  {
    this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    e.a(this.e, this.b, this.c, this.d);
    return true;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.h
 * JD-Core Version:    0.6.2
 */