package android.support.v4.app;

import android.os.Bundle;

final class ad
{
  private final String a;
  private final Class b;
  private final Bundle c;
  private Fragment d;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.ad
 * JD-Core Version:    0.6.2
 */