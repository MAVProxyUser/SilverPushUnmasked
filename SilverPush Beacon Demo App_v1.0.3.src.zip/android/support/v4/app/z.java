package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class z
  implements Parcelable.Creator
{
  public FragmentManagerState a(Parcel paramParcel)
  {
    return new FragmentManagerState(paramParcel);
  }

  public FragmentManagerState[] a(int paramInt)
  {
    return new FragmentManagerState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.z
 * JD-Core Version:    0.6.2
 */