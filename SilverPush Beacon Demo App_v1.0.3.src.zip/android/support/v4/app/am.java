package android.support.v4.app;

public abstract class am
{
  public boolean a()
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.am
 * JD-Core Version:    0.6.2
 */