package android.support.v4.app;

import android.app.Activity;

class d
{
  public static void a(Activity paramActivity)
  {
    paramActivity.finishAffinity();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.app.d
 * JD-Core Version:    0.6.2
 */