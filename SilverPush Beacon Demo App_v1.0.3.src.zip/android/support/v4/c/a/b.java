package android.support.v4.c.a;

import android.support.v4.view.af;
import android.support.v4.view.g;
import android.view.MenuItem;
import android.view.View;

public abstract interface b extends MenuItem
{
  public abstract b a(af paramaf);

  public abstract b a(g paramg);

  public abstract g a();

  public abstract boolean collapseActionView();

  public abstract boolean expandActionView();

  public abstract View getActionView();

  public abstract boolean isActionViewExpanded();

  public abstract MenuItem setActionView(int paramInt);

  public abstract MenuItem setActionView(View paramView);

  public abstract void setShowAsAction(int paramInt);

  public abstract MenuItem setShowAsActionFlags(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.c.a.b
 * JD-Core Version:    0.6.2
 */