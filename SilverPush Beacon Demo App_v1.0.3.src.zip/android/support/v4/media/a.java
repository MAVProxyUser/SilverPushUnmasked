package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class a
  implements Parcelable.Creator
{
  public MediaMetadataCompat a(Parcel paramParcel)
  {
    return new MediaMetadataCompat(paramParcel, null);
  }

  public MediaMetadataCompat[] a(int paramInt)
  {
    return new MediaMetadataCompat[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.media.a
 * JD-Core Version:    0.6.2
 */