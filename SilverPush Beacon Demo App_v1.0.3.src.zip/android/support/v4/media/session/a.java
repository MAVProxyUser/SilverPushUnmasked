package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class a
  implements Parcelable.Creator
{
  public MediaSessionCompat.Token a(Parcel paramParcel)
  {
    return new MediaSessionCompat.Token(paramParcel.readParcelable(null));
  }

  public MediaSessionCompat.Token[] a(int paramInt)
  {
    return new MediaSessionCompat.Token[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.media.session.a
 * JD-Core Version:    0.6.2
 */