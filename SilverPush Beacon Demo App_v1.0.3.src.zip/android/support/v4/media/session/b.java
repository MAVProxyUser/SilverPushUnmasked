package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class b
  implements Parcelable.Creator
{
  public PlaybackStateCompat a(Parcel paramParcel)
  {
    return new PlaybackStateCompat(paramParcel, null);
  }

  public PlaybackStateCompat[] a(int paramInt)
  {
    return new PlaybackStateCompat[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.media.session.b
 * JD-Core Version:    0.6.2
 */