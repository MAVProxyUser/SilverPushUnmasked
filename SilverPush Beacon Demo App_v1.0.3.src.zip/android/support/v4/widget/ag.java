package android.support.v4.widget;

import android.content.Context;
import android.view.animation.Interpolator;

abstract interface ag
{
  public abstract int a(Object paramObject);

  public abstract Object a(Context paramContext, Interpolator paramInterpolator);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);

  public abstract int b(Object paramObject);

  public abstract boolean c(Object paramObject);

  public abstract void d(Object paramObject);

  public abstract int e(Object paramObject);

  public abstract int f(Object paramObject);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.ag
 * JD-Core Version:    0.6.2
 */