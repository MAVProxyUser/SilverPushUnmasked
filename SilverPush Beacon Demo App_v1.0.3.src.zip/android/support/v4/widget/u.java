package android.support.v4.widget;

import android.graphics.Canvas;

class u
  implements w
{
  public void a(Object paramObject, int paramInt1, int paramInt2)
  {
  }

  public boolean a(Object paramObject)
  {
    return true;
  }

  public boolean a(Object paramObject, float paramFloat)
  {
    return false;
  }

  public boolean a(Object paramObject, Canvas paramCanvas)
  {
    return false;
  }

  public void b(Object paramObject)
  {
  }

  public boolean c(Object paramObject)
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.u
 * JD-Core Version:    0.6.2
 */