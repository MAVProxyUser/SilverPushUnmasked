package android.support.v4.widget;

import android.database.ContentObserver;
import android.os.Handler;

class g extends ContentObserver
{
  public g(e parame)
  {
    super(new Handler());
  }

  public boolean deliverSelfNotifications()
  {
    return true;
  }

  public void onChange(boolean paramBoolean)
  {
    this.a.b();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.g
 * JD-Core Version:    0.6.2
 */