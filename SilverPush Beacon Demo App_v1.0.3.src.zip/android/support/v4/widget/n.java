package android.support.v4.widget;

import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;

class n
  implements l
{
  public int a(Object paramObject)
  {
    return 0;
  }

  public void a(View paramView, Object paramObject, int paramInt)
  {
  }

  public void a(ViewGroup.MarginLayoutParams paramMarginLayoutParams, Object paramObject, int paramInt)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.n
 * JD-Core Version:    0.6.2
 */