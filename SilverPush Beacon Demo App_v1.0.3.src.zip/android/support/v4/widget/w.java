package android.support.v4.widget;

import android.graphics.Canvas;

abstract interface w
{
  public abstract void a(Object paramObject, int paramInt1, int paramInt2);

  public abstract boolean a(Object paramObject);

  public abstract boolean a(Object paramObject, float paramFloat);

  public abstract boolean a(Object paramObject, Canvas paramCanvas);

  public abstract void b(Object paramObject);

  public abstract boolean c(Object paramObject);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.w
 * JD-Core Version:    0.6.2
 */