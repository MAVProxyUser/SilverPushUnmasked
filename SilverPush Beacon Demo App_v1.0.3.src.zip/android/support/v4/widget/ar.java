package android.support.v4.widget;

import android.support.v4.view.au;
import android.view.View;

class ar
  implements aq
{
  public void a(SlidingPaneLayout paramSlidingPaneLayout, View paramView)
  {
    au.a(paramSlidingPaneLayout, paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.ar
 * JD-Core Version:    0.6.2
 */