package android.support.v4.widget;

import android.support.v4.view.au;

class d
  implements Runnable
{
  private d(a parama)
  {
  }

  public void run()
  {
    if (!a.a(this.a))
      return;
    if (a.b(this.a))
    {
      a.a(this.a, false);
      a.c(this.a).a();
    }
    c localc = a.c(this.a);
    if ((localc.c()) || (!a.d(this.a)))
    {
      a.b(this.a, false);
      return;
    }
    if (a.e(this.a))
    {
      a.c(this.a, false);
      a.f(this.a);
    }
    localc.d();
    int i = localc.g();
    int j = localc.h();
    this.a.a(i, j);
    au.a(a.g(this.a), this);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.d
 * JD-Core Version:    0.6.2
 */