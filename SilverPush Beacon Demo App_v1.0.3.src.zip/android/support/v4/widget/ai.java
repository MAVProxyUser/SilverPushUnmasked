package android.support.v4.widget;

import android.content.Context;
import android.view.animation.Interpolator;

class ai
  implements ag
{
  public int a(Object paramObject)
  {
    return ak.a(paramObject);
  }

  public Object a(Context paramContext, Interpolator paramInterpolator)
  {
    return ak.a(paramContext, paramInterpolator);
  }

  public void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    ak.a(paramObject, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }

  public void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    ak.a(paramObject, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
  }

  public int b(Object paramObject)
  {
    return ak.b(paramObject);
  }

  public boolean c(Object paramObject)
  {
    return ak.c(paramObject);
  }

  public void d(Object paramObject)
  {
    ak.d(paramObject);
  }

  public int e(Object paramObject)
  {
    return ak.e(paramObject);
  }

  public int f(Object paramObject)
  {
    return ak.f(paramObject);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.ai
 * JD-Core Version:    0.6.2
 */