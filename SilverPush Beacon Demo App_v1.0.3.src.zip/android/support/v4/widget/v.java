package android.support.v4.widget;

import android.graphics.Canvas;

class v
  implements w
{
  public void a(Object paramObject, int paramInt1, int paramInt2)
  {
    x.a(paramObject, paramInt1, paramInt2);
  }

  public boolean a(Object paramObject)
  {
    return x.a(paramObject);
  }

  public boolean a(Object paramObject, float paramFloat)
  {
    return x.a(paramObject, paramFloat);
  }

  public boolean a(Object paramObject, Canvas paramCanvas)
  {
    return x.a(paramObject, paramCanvas);
  }

  public void b(Object paramObject)
  {
    x.b(paramObject);
  }

  public boolean c(Object paramObject)
  {
    return x.c(paramObject);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.v
 * JD-Core Version:    0.6.2
 */