package android.support.v4.widget;

import android.view.View;

public abstract interface o
{
  public abstract void a(int paramInt);

  public abstract void a(View paramView);

  public abstract void a(View paramView, float paramFloat);

  public abstract void b(View paramView);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.o
 * JD-Core Version:    0.6.2
 */