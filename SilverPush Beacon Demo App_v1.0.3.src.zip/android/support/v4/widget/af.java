package android.support.v4.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.animation.Interpolator;

public class af
{
  Object a;
  ag b;

  private af(int paramInt, Context paramContext, Interpolator paramInterpolator)
  {
    if (paramInt >= 14)
      this.b = new aj();
    while (true)
    {
      this.a = this.b.a(paramContext, paramInterpolator);
      return;
      if (paramInt >= 9)
        this.b = new ai();
      else
        this.b = new ah();
    }
  }

  af(Context paramContext, Interpolator paramInterpolator)
  {
    this(Build.VERSION.SDK_INT, paramContext, paramInterpolator);
  }

  public static af a(Context paramContext)
  {
    return a(paramContext, null);
  }

  public static af a(Context paramContext, Interpolator paramInterpolator)
  {
    return new af(paramContext, paramInterpolator);
  }

  public int a()
  {
    return this.b.a(this.a);
  }

  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    this.b.a(this.a, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }

  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    this.b.a(this.a, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
  }

  public int b()
  {
    return this.b.b(this.a);
  }

  public int c()
  {
    return this.b.e(this.a);
  }

  public int d()
  {
    return this.b.f(this.a);
  }

  public boolean e()
  {
    return this.b.c(this.a);
  }

  public void f()
  {
    this.b.d(this.a);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.af
 * JD-Core Version:    0.6.2
 */