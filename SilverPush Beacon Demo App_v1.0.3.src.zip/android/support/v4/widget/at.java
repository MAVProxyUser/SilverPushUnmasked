package android.support.v4.widget;

import android.support.v4.view.au;
import android.view.View;

class at extends ar
{
  public void a(SlidingPaneLayout paramSlidingPaneLayout, View paramView)
  {
    au.a(paramView, ((an)paramView.getLayoutParams()).d);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.at
 * JD-Core Version:    0.6.2
 */