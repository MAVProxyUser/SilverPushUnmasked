package android.support.v4.widget;

import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;

abstract interface l
{
  public abstract int a(Object paramObject);

  public abstract void a(View paramView, Object paramObject, int paramInt);

  public abstract void a(ViewGroup.MarginLayoutParams paramMarginLayoutParams, Object paramObject, int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.l
 * JD-Core Version:    0.6.2
 */