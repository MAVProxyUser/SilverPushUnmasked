package android.support.v4.widget;

import android.database.DataSetObserver;

class h extends DataSetObserver
{
  private h(e parame)
  {
  }

  public void onChanged()
  {
    this.a.a = true;
    this.a.notifyDataSetChanged();
  }

  public void onInvalidated()
  {
    this.a.a = false;
    this.a.notifyDataSetInvalidated();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.h
 * JD-Core Version:    0.6.2
 */