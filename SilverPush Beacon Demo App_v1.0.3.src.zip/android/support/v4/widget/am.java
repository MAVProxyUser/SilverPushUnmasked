package android.support.v4.widget;

import android.support.v4.view.au;
import android.view.View;
import java.util.ArrayList;

class am
  implements Runnable
{
  final View a;

  am(SlidingPaneLayout paramSlidingPaneLayout, View paramView)
  {
    this.a = paramView;
  }

  public void run()
  {
    if (this.a.getParent() == this.b)
    {
      au.a(this.a, 0, null);
      SlidingPaneLayout.a(this.b, this.a);
    }
    SlidingPaneLayout.a(this.b).remove(this);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.am
 * JD-Core Version:    0.6.2
 */