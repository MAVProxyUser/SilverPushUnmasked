package android.support.v4.widget;

class aj extends ai
{
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.aj
 * JD-Core Version:    0.6.2
 */