package android.support.v4.widget;

import android.database.Cursor;

abstract interface j
{
  public abstract Cursor a();

  public abstract Cursor a(CharSequence paramCharSequence);

  public abstract void a(Cursor paramCursor);

  public abstract CharSequence c(Cursor paramCursor);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.widget.j
 * JD-Core Version:    0.6.2
 */