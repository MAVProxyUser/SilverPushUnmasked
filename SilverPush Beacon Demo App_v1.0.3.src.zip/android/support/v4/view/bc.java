package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class bc extends bb
{
  public void a(View paramView, Paint paramPaint)
  {
    bm.a(paramView, paramPaint);
  }

  public int e(View paramView)
  {
    return bm.a(paramView);
  }

  public int k(View paramView)
  {
    return bm.b(paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bc
 * JD-Core Version:    0.6.2
 */