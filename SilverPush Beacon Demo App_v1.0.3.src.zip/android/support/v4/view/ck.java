package android.support.v4.view;

import android.view.View;

class ck
  implements cv
{
  cf a;

  ck(cf paramcf)
  {
    this.a = paramcf;
  }

  public void a(View paramView)
  {
    if (cf.c(this.a) >= 0)
      au.a(paramView, 2, null);
    if (cf.a(this.a) != null)
      cf.a(this.a).run();
    Object localObject = paramView.getTag(2113929216);
    if ((localObject instanceof cv));
    for (cv localcv = (cv)localObject; ; localcv = null)
    {
      if (localcv != null)
        localcv.a(paramView);
      return;
    }
  }

  public void b(View paramView)
  {
    if (cf.c(this.a) >= 0)
    {
      au.a(paramView, cf.c(this.a), null);
      cf.a(this.a, -1);
    }
    if (cf.b(this.a) != null)
      cf.b(this.a).run();
    Object localObject = paramView.getTag(2113929216);
    if ((localObject instanceof cv));
    for (cv localcv = (cv)localObject; ; localcv = null)
    {
      if (localcv != null)
        localcv.b(paramView);
      return;
    }
  }

  public void c(View paramView)
  {
    Object localObject = paramView.getTag(2113929216);
    if ((localObject instanceof cv));
    for (cv localcv = (cv)localObject; ; localcv = null)
    {
      if (localcv != null)
        localcv.c(paramView);
      return;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ck
 * JD-Core Version:    0.6.2
 */