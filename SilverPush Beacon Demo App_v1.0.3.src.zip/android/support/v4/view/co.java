package android.support.v4.view;

import android.view.View;
import android.view.animation.Interpolator;

abstract interface co
{
  public abstract void a(cf paramcf, View paramView);

  public abstract void a(cf paramcf, View paramView, float paramFloat);

  public abstract void a(cf paramcf, View paramView, long paramLong);

  public abstract void a(cf paramcf, View paramView, cv paramcv);

  public abstract void a(cf paramcf, View paramView, cx paramcx);

  public abstract void a(cf paramcf, View paramView, Interpolator paramInterpolator);

  public abstract void b(cf paramcf, View paramView);

  public abstract void b(cf paramcf, View paramView, float paramFloat);

  public abstract void c(cf paramcf, View paramView, float paramFloat);

  public abstract void d(cf paramcf, View paramView, float paramFloat);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.co
 * JD-Core Version:    0.6.2
 */