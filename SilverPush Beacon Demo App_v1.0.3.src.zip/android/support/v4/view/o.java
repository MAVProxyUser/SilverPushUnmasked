package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.KeyEvent;

public class o
{
  static final s a = new p();

  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new r();
      return;
    }
  }

  public static boolean a(KeyEvent paramKeyEvent)
  {
    return a.b(paramKeyEvent.getMetaState());
  }

  public static boolean a(KeyEvent paramKeyEvent, int paramInt)
  {
    return a.a(paramKeyEvent.getMetaState(), paramInt);
  }

  public static void b(KeyEvent paramKeyEvent)
  {
    a.a(paramKeyEvent);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.o
 * JD-Core Version:    0.6.2
 */