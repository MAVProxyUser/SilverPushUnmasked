package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class az extends ay
{
  public int a(int paramInt1, int paramInt2, int paramInt3)
  {
    return bj.a(paramInt1, paramInt2, paramInt3);
  }

  long a()
  {
    return bj.a();
  }

  public void a(View paramView, int paramInt, Paint paramPaint)
  {
    bj.a(paramView, paramInt, paramPaint);
  }

  public void a(View paramView, Paint paramPaint)
  {
    a(paramView, d(paramView), paramPaint);
    paramView.invalidate();
  }

  public void b(View paramView, float paramFloat)
  {
    bj.a(paramView, paramFloat);
  }

  public void c(View paramView, float paramFloat)
  {
    bj.b(paramView, paramFloat);
  }

  public int d(View paramView)
  {
    return bj.a(paramView);
  }

  public void d(View paramView, float paramFloat)
  {
    bj.c(paramView, paramFloat);
  }

  public void e(View paramView, float paramFloat)
  {
    bj.d(paramView, paramFloat);
  }

  public int g(View paramView)
  {
    return bj.b(paramView);
  }

  public float h(View paramView)
  {
    return bj.c(paramView);
  }

  public void m(View paramView)
  {
    bj.d(paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.az
 * JD-Core Version:    0.6.2
 */