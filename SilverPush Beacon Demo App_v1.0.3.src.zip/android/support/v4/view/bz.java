package android.support.v4.view;

abstract interface bz
{
  public abstract void a(ao paramao1, ao paramao2);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bz
 * JD-Core Version:    0.6.2
 */