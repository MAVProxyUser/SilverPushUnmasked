package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

class ab
  implements ae
{
  public MenuItem a(MenuItem paramMenuItem, View paramView)
  {
    return paramMenuItem;
  }

  public View a(MenuItem paramMenuItem)
  {
    return null;
  }

  public void a(MenuItem paramMenuItem, int paramInt)
  {
  }

  public MenuItem b(MenuItem paramMenuItem, int paramInt)
  {
    return paramMenuItem;
  }

  public boolean b(MenuItem paramMenuItem)
  {
    return false;
  }

  public boolean c(MenuItem paramMenuItem)
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ab
 * JD-Core Version:    0.6.2
 */