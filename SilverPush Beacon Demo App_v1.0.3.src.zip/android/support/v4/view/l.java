package android.support.v4.view;

class l
  implements k
{
  public int a(int paramInt1, int paramInt2)
  {
    return 0xFF7FFFFF & paramInt1;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.l
 * JD-Core Version:    0.6.2
 */