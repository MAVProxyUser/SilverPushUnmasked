package android.support.v4.view;

import android.os.Build.VERSION;

public class j
{
  static final k a = new l();

  static
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      a = new m();
      return;
    }
  }

  public static int a(int paramInt1, int paramInt2)
  {
    return a.a(paramInt1, paramInt2);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.j
 * JD-Core Version:    0.6.2
 */