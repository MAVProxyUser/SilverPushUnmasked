package android.support.v4.view;

import android.os.Build.VERSION;

public class a
{
  private static final c b;
  private static final Object c;
  final Object a;

  static
  {
    if (Build.VERSION.SDK_INT >= 16)
      b = new d();
    while (true)
    {
      c = b.a();
      return;
      if (Build.VERSION.SDK_INT >= 14)
        b = new b();
      else
        b = new e();
    }
  }

  Object a()
  {
    return this.a;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.a
 * JD-Core Version:    0.6.2
 */