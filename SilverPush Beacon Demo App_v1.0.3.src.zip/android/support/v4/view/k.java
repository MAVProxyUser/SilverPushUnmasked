package android.support.v4.view;

abstract interface k
{
  public abstract int a(int paramInt1, int paramInt2);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.k
 * JD-Core Version:    0.6.2
 */