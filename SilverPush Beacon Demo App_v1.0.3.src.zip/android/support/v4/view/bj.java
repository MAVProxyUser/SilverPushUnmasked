package android.support.v4.view;

import android.animation.ValueAnimator;
import android.graphics.Paint;
import android.view.View;

class bj
{
  public static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    return View.resolveSizeAndState(paramInt1, paramInt2, paramInt3);
  }

  public static int a(View paramView)
  {
    return paramView.getLayerType();
  }

  static long a()
  {
    return ValueAnimator.getFrameDelay();
  }

  public static void a(View paramView, float paramFloat)
  {
    paramView.setTranslationX(paramFloat);
  }

  public static void a(View paramView, int paramInt, Paint paramPaint)
  {
    paramView.setLayerType(paramInt, paramPaint);
  }

  public static int b(View paramView)
  {
    return paramView.getMeasuredState();
  }

  public static void b(View paramView, float paramFloat)
  {
    paramView.setTranslationY(paramFloat);
  }

  public static float c(View paramView)
  {
    return paramView.getTranslationY();
  }

  public static void c(View paramView, float paramFloat)
  {
    paramView.setAlpha(paramFloat);
  }

  public static void d(View paramView)
  {
    paramView.jumpDrawablesToCurrentState();
  }

  public static void d(View paramView, float paramFloat)
  {
    paramView.setScaleY(paramFloat);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bj
 * JD-Core Version:    0.6.2
 */