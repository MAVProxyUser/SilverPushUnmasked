package android.support.v4.view;

import android.graphics.Paint;
import android.os.Build.VERSION;
import android.view.View;

public class au
{
  static final be a = new aw();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      a = new av();
      return;
    }
    if (i >= 19)
    {
      a = new bd();
      return;
    }
    if (i >= 17)
    {
      a = new bc();
      return;
    }
    if (i >= 16)
    {
      a = new bb();
      return;
    }
    if (i >= 14)
    {
      a = new ba();
      return;
    }
    if (i >= 11)
    {
      a = new az();
      return;
    }
    if (i >= 9)
    {
      a = new ay();
      return;
    }
    if (i >= 7)
    {
      a = new ax();
      return;
    }
  }

  public static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    return a.a(paramInt1, paramInt2, paramInt3);
  }

  public static int a(View paramView)
  {
    return a.b(paramView);
  }

  public static void a(View paramView, float paramFloat)
  {
    a.b(paramView, paramFloat);
  }

  public static void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    a.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void a(View paramView, int paramInt, Paint paramPaint)
  {
    a.a(paramView, paramInt, paramPaint);
  }

  public static void a(View paramView, Paint paramPaint)
  {
    a.a(paramView, paramPaint);
  }

  public static void a(View paramView, a parama)
  {
    a.a(paramView, parama);
  }

  public static void a(View paramView, an paraman)
  {
    a.a(paramView, paraman);
  }

  public static void a(View paramView, Runnable paramRunnable)
  {
    a.a(paramView, paramRunnable);
  }

  public static void a(View paramView, Runnable paramRunnable, long paramLong)
  {
    a.a(paramView, paramRunnable, paramLong);
  }

  public static boolean a(View paramView, int paramInt)
  {
    return a.a(paramView, paramInt);
  }

  public static void b(View paramView)
  {
    a.c(paramView);
  }

  public static void b(View paramView, float paramFloat)
  {
    a.c(paramView, paramFloat);
  }

  public static void b(View paramView, int paramInt)
  {
    a.b(paramView, paramInt);
  }

  public static int c(View paramView)
  {
    return a.d(paramView);
  }

  public static void c(View paramView, float paramFloat)
  {
    a.d(paramView, paramFloat);
  }

  public static int d(View paramView)
  {
    return a.e(paramView);
  }

  public static void d(View paramView, float paramFloat)
  {
    a.e(paramView, paramFloat);
  }

  public static void e(View paramView, float paramFloat)
  {
    a.a(paramView, paramFloat);
  }

  public static boolean e(View paramView)
  {
    return a.f(paramView);
  }

  public static int f(View paramView)
  {
    return a.g(paramView);
  }

  public static float g(View paramView)
  {
    return a.h(paramView);
  }

  public static int h(View paramView)
  {
    return a.i(paramView);
  }

  public static cf i(View paramView)
  {
    return a.j(paramView);
  }

  public static int j(View paramView)
  {
    return a.k(paramView);
  }

  public static void k(View paramView)
  {
    a.a(paramView);
  }

  public static boolean l(View paramView)
  {
    return a.l(paramView);
  }

  public static void m(View paramView)
  {
    a.m(paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.au
 * JD-Core Version:    0.6.2
 */