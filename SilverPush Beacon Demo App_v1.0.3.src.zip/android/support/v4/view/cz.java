package android.support.v4.view;

import android.view.WindowInsets;

class cz extends cy
{
  private final WindowInsets a;

  cz(WindowInsets paramWindowInsets)
  {
    this.a = paramWindowInsets;
  }

  public int a()
  {
    return this.a.getSystemWindowInsetLeft();
  }

  public cy a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return new cz(this.a.replaceSystemWindowInsets(paramInt1, paramInt2, paramInt3, paramInt4));
  }

  public int b()
  {
    return this.a.getSystemWindowInsetTop();
  }

  public int c()
  {
    return this.a.getSystemWindowInsetRight();
  }

  public int d()
  {
    return this.a.getSystemWindowInsetBottom();
  }

  WindowInsets e()
  {
    return this.a;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cz
 * JD-Core Version:    0.6.2
 */