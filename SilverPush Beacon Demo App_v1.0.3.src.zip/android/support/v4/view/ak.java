package android.support.v4.view;

import android.view.MotionEvent;

class ak
  implements al
{
  public int a(MotionEvent paramMotionEvent)
  {
    return am.a(paramMotionEvent);
  }

  public int a(MotionEvent paramMotionEvent, int paramInt)
  {
    return am.a(paramMotionEvent, paramInt);
  }

  public int b(MotionEvent paramMotionEvent, int paramInt)
  {
    return am.b(paramMotionEvent, paramInt);
  }

  public float c(MotionEvent paramMotionEvent, int paramInt)
  {
    return am.c(paramMotionEvent, paramInt);
  }

  public float d(MotionEvent paramMotionEvent, int paramInt)
  {
    return am.d(paramMotionEvent, paramInt);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ak
 * JD-Core Version:    0.6.2
 */