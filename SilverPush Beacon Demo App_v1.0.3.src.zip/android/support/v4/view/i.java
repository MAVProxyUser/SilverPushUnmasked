package android.support.v4.view;

public abstract interface i
{
  public abstract void a(boolean paramBoolean);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.i
 * JD-Core Version:    0.6.2
 */