package android.support.v4.view;

class r extends q
{
  public int a(int paramInt)
  {
    return u.a(paramInt);
  }

  public boolean a(int paramInt1, int paramInt2)
  {
    return u.a(paramInt1, paramInt2);
  }

  public boolean b(int paramInt)
  {
    return u.b(paramInt);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.r
 * JD-Core Version:    0.6.2
 */