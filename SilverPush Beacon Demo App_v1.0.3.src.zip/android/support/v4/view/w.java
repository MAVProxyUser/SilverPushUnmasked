package android.support.v4.view;

import android.view.ViewGroup.MarginLayoutParams;

abstract interface w
{
  public abstract int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams);

  public abstract int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.w
 * JD-Core Version:    0.6.2
 */