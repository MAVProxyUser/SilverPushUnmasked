package android.support.v4.view;

import android.view.View;
import android.view.ViewPropertyAnimator;

class cr
{
  public static void a(View paramView, cv paramcv)
  {
    if (paramcv != null)
    {
      paramView.animate().setListener(new cs(paramcv, paramView));
      return;
    }
    paramView.animate().setListener(null);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cr
 * JD-Core Version:    0.6.2
 */