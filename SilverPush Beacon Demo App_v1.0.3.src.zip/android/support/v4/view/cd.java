package android.support.v4.view;

import android.os.Parcel;
import android.support.v4.d.c;

final class cd
  implements c
{
  public ViewPager.SavedState b(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return new ViewPager.SavedState(paramParcel, paramClassLoader);
  }

  public ViewPager.SavedState[] b(int paramInt)
  {
    return new ViewPager.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cd
 * JD-Core Version:    0.6.2
 */