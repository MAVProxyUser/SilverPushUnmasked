package android.support.v4.view;

import android.view.ViewConfiguration;

abstract interface bs
{
  public abstract boolean a(ViewConfiguration paramViewConfiguration);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bs
 * JD-Core Version:    0.6.2
 */