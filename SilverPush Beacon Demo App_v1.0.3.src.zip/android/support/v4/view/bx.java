package android.support.v4.view;

class bx
{
  Object a;
  int b;
  boolean c;
  float d;
  float e;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bx
 * JD-Core Version:    0.6.2
 */