package android.support.v4.view;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.view.View;

final class cu
  implements ValueAnimator.AnimatorUpdateListener
{
  cu(cx paramcx, View paramView)
  {
  }

  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    this.a.a(this.b);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cu
 * JD-Core Version:    0.6.2
 */