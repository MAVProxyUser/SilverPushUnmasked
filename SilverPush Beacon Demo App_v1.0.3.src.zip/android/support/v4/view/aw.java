package android.support.v4.view;

import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.view.View;
import java.util.WeakHashMap;

class aw
  implements be
{
  WeakHashMap a = null;

  public int a(int paramInt1, int paramInt2, int paramInt3)
  {
    return View.resolveSize(paramInt1, paramInt2);
  }

  long a()
  {
    return 10L;
  }

  public void a(View paramView)
  {
  }

  public void a(View paramView, float paramFloat)
  {
  }

  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.invalidate(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public void a(View paramView, int paramInt, Paint paramPaint)
  {
  }

  public void a(View paramView, Paint paramPaint)
  {
  }

  public void a(View paramView, a parama)
  {
  }

  public void a(View paramView, an paraman)
  {
  }

  public void a(View paramView, Runnable paramRunnable)
  {
    paramView.postDelayed(paramRunnable, a());
  }

  public void a(View paramView, Runnable paramRunnable, long paramLong)
  {
    paramView.postDelayed(paramRunnable, paramLong + a());
  }

  public boolean a(View paramView, int paramInt)
  {
    return false;
  }

  public int b(View paramView)
  {
    return 2;
  }

  public void b(View paramView, float paramFloat)
  {
  }

  public void b(View paramView, int paramInt)
  {
  }

  public void c(View paramView)
  {
    paramView.invalidate();
  }

  public void c(View paramView, float paramFloat)
  {
  }

  public int d(View paramView)
  {
    return 0;
  }

  public void d(View paramView, float paramFloat)
  {
  }

  public int e(View paramView)
  {
    return 0;
  }

  public void e(View paramView, float paramFloat)
  {
  }

  public boolean f(View paramView)
  {
    Drawable localDrawable = paramView.getBackground();
    boolean bool = false;
    if (localDrawable != null)
    {
      int i = localDrawable.getOpacity();
      bool = false;
      if (i == -1)
        bool = true;
    }
    return bool;
  }

  public int g(View paramView)
  {
    return 0;
  }

  public float h(View paramView)
  {
    return 0.0F;
  }

  public int i(View paramView)
  {
    return 0;
  }

  public cf j(View paramView)
  {
    return new cf(paramView);
  }

  public int k(View paramView)
  {
    return 0;
  }

  public boolean l(View paramView)
  {
    return false;
  }

  public void m(View paramView)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.aw
 * JD-Core Version:    0.6.2
 */