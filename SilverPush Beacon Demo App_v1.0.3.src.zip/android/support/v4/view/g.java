package android.support.v4.view;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public abstract class g
{
  private final Context a;
  private h b;
  private i c;

  public g(Context paramContext)
  {
    this.a = paramContext;
  }

  public abstract View a();

  public View a(MenuItem paramMenuItem)
  {
    return a();
  }

  public void a(h paramh)
  {
    this.b = paramh;
  }

  public void a(i parami)
  {
    if ((this.c != null) && (parami != null))
      Log.w("ActionProvider(support)", "setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this " + getClass().getSimpleName() + " instance while it is still in use somewhere else?");
    this.c = parami;
  }

  public void a(SubMenu paramSubMenu)
  {
  }

  public boolean b()
  {
    return false;
  }

  public boolean c()
  {
    return true;
  }

  public boolean d()
  {
    return false;
  }

  public boolean e()
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.g
 * JD-Core Version:    0.6.2
 */