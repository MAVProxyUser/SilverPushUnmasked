package android.support.v4.view;

import android.view.View;
import java.lang.ref.WeakReference;

class ci
  implements Runnable
{
  WeakReference a;
  cf b;

  private ci(ch paramch, cf paramcf, View paramView)
  {
    this.a = new WeakReference(paramView);
    this.b = paramcf;
  }

  public void run()
  {
    ch.a(this.c, this.b, (View)this.a.get());
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ci
 * JD-Core Version:    0.6.2
 */