package android.support.v4.view;

import android.view.ViewGroup.MarginLayoutParams;

class x
  implements w
{
  public int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return paramMarginLayoutParams.leftMargin;
  }

  public int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return paramMarginLayoutParams.rightMargin;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.x
 * JD-Core Version:    0.6.2
 */