package android.support.v4.view;

import android.view.KeyEvent;

abstract interface s
{
  public abstract void a(KeyEvent paramKeyEvent);

  public abstract boolean a(int paramInt1, int paramInt2);

  public abstract boolean b(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.s
 * JD-Core Version:    0.6.2
 */