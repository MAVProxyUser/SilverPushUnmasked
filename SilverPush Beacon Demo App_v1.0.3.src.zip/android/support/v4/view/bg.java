package android.support.v4.view;

import android.view.View;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.WindowInsets;

final class bg
  implements View.OnApplyWindowInsetsListener
{
  bg(an paraman)
  {
  }

  public WindowInsets onApplyWindowInsets(View paramView, WindowInsets paramWindowInsets)
  {
    cz localcz = new cz(paramWindowInsets);
    return ((cz)this.a.a(paramView, localcz)).e();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bg
 * JD-Core Version:    0.6.2
 */