package android.support.v4.view;

import android.view.MotionEvent;

abstract interface al
{
  public abstract int a(MotionEvent paramMotionEvent);

  public abstract int a(MotionEvent paramMotionEvent, int paramInt);

  public abstract int b(MotionEvent paramMotionEvent, int paramInt);

  public abstract float c(MotionEvent paramMotionEvent, int paramInt);

  public abstract float d(MotionEvent paramMotionEvent, int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.al
 * JD-Core Version:    0.6.2
 */