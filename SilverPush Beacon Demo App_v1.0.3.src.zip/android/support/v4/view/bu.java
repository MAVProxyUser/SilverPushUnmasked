package android.support.v4.view;

import java.util.Comparator;

final class bu
  implements Comparator
{
  public int a(bx parambx1, bx parambx2)
  {
    return parambx1.b - parambx2.b;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bu
 * JD-Core Version:    0.6.2
 */