package android.support.v4.view;

import android.view.Gravity;

class n
{
  public static int a(int paramInt1, int paramInt2)
  {
    return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.n
 * JD-Core Version:    0.6.2
 */