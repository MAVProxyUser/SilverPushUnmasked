package android.support.v4.view;

import android.view.View;

class ay extends ax
{
  public int b(View paramView)
  {
    return bi.a(paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ay
 * JD-Core Version:    0.6.2
 */