package android.support.v4.view;

import android.view.View;

class av extends bd
{
  public void a(View paramView)
  {
    bf.a(paramView);
  }

  public void a(View paramView, float paramFloat)
  {
    bf.a(paramView, paramFloat);
  }

  public void a(View paramView, an paraman)
  {
    bf.a(paramView, paraman);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.av
 * JD-Core Version:    0.6.2
 */