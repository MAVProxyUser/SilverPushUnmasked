package android.support.v4.view;

import android.view.View;
import java.util.WeakHashMap;

class ba extends az
{
  static boolean b = false;

  public void a(View paramView, a parama)
  {
    bk.a(paramView, parama.a());
  }

  public boolean a(View paramView, int paramInt)
  {
    return bk.a(paramView, paramInt);
  }

  public cf j(View paramView)
  {
    if (this.a == null)
      this.a = new WeakHashMap();
    cf localcf = (cf)this.a.get(paramView);
    if (localcf == null)
    {
      localcf = new cf(paramView);
      this.a.put(paramView, localcf);
    }
    return localcf;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ba
 * JD-Core Version:    0.6.2
 */