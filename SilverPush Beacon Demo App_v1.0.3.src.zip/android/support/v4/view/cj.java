package android.support.v4.view;

import android.view.View;
import android.view.animation.Interpolator;
import java.util.WeakHashMap;

class cj extends ch
{
  WeakHashMap b = null;

  public void a(cf paramcf, View paramView)
  {
    cp.a(paramView);
  }

  public void a(cf paramcf, View paramView, float paramFloat)
  {
    cp.a(paramView, paramFloat);
  }

  public void a(cf paramcf, View paramView, long paramLong)
  {
    cp.a(paramView, paramLong);
  }

  public void a(cf paramcf, View paramView, cv paramcv)
  {
    paramView.setTag(2113929216, paramcv);
    cp.a(paramView, new ck(paramcf));
  }

  public void a(cf paramcf, View paramView, Interpolator paramInterpolator)
  {
    cp.a(paramView, paramInterpolator);
  }

  public void b(cf paramcf, View paramView)
  {
    cp.b(paramView);
  }

  public void b(cf paramcf, View paramView, float paramFloat)
  {
    cp.b(paramView, paramFloat);
  }

  public void c(cf paramcf, View paramView, float paramFloat)
  {
    cp.c(paramView, paramFloat);
  }

  public void d(cf paramcf, View paramView, float paramFloat)
  {
    cp.d(paramView, paramFloat);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cj
 * JD-Core Version:    0.6.2
 */