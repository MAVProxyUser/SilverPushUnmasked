package android.support.v4.view;

import android.view.MenuItem;

public abstract interface af
{
  public abstract boolean a(MenuItem paramMenuItem);

  public abstract boolean b(MenuItem paramMenuItem);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.af
 * JD-Core Version:    0.6.2
 */