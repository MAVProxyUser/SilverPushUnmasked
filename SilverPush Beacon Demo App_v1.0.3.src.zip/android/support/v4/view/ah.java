package android.support.v4.view;

import android.view.MenuItem;

class ah
{
  public static boolean a(MenuItem paramMenuItem)
  {
    return paramMenuItem.expandActionView();
  }

  public static boolean b(MenuItem paramMenuItem)
  {
    return paramMenuItem.isActionViewExpanded();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ah
 * JD-Core Version:    0.6.2
 */