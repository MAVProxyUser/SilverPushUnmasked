package android.support.v4.view;

import android.view.KeyEvent;

class q extends p
{
  public void a(KeyEvent paramKeyEvent)
  {
    t.a(paramKeyEvent);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.q
 * JD-Core Version:    0.6.2
 */