package android.support.v4.view;

import android.database.DataSetObserver;

class cc extends DataSetObserver
{
  private cc(ViewPager paramViewPager)
  {
  }

  public void onChanged()
  {
    this.a.a();
  }

  public void onInvalidated()
  {
    this.a.a();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cc
 * JD-Core Version:    0.6.2
 */