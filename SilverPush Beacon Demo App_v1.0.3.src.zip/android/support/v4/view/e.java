package android.support.v4.view;

class e
  implements c
{
  public Object a()
  {
    return null;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.e
 * JD-Core Version:    0.6.2
 */