package android.support.v4.view;

import android.view.View;

public abstract interface cv
{
  public abstract void a(View paramView);

  public abstract void b(View paramView);

  public abstract void c(View paramView);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cv
 * JD-Core Version:    0.6.2
 */