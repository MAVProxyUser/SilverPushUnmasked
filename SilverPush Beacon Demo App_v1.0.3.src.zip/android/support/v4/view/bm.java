package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class bm
{
  public static int a(View paramView)
  {
    return paramView.getLayoutDirection();
  }

  public static void a(View paramView, Paint paramPaint)
  {
    paramView.setLayerPaint(paramPaint);
  }

  public static int b(View paramView)
  {
    return paramView.getWindowSystemUiVisibility();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bm
 * JD-Core Version:    0.6.2
 */