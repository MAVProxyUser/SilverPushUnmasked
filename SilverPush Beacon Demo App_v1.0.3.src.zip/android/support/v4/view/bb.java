package android.support.v4.view;

import android.view.View;

class bb extends ba
{
  public void a(View paramView)
  {
    bl.c(paramView);
  }

  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    bl.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public void a(View paramView, Runnable paramRunnable)
  {
    bl.a(paramView, paramRunnable);
  }

  public void a(View paramView, Runnable paramRunnable, long paramLong)
  {
    bl.a(paramView, paramRunnable, paramLong);
  }

  public void b(View paramView, int paramInt)
  {
    if (paramInt == 4)
      paramInt = 2;
    bl.a(paramView, paramInt);
  }

  public void c(View paramView)
  {
    bl.a(paramView);
  }

  public int i(View paramView)
  {
    return bl.b(paramView);
  }

  public boolean l(View paramView)
  {
    return bl.d(paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bb
 * JD-Core Version:    0.6.2
 */