package android.support.v4.view;

import android.view.View;
import android.view.ViewPropertyAnimator;

class ct
{
  public static void a(View paramView, cx paramcx)
  {
    paramView.animate().setUpdateListener(new cu(paramcx, paramView));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ct
 * JD-Core Version:    0.6.2
 */