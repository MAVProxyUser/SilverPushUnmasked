package android.support.v4.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

final class cq extends AnimatorListenerAdapter
{
  cq(cv paramcv, View paramView)
  {
  }

  public void onAnimationCancel(Animator paramAnimator)
  {
    this.a.c(this.b);
  }

  public void onAnimationEnd(Animator paramAnimator)
  {
    this.a.b(this.b);
  }

  public void onAnimationStart(Animator paramAnimator)
  {
    this.a.a(this.b);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cq
 * JD-Core Version:    0.6.2
 */