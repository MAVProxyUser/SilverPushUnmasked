package android.support.v4.view;

import android.view.View;

public abstract interface cb
{
  public abstract void a(View paramView, float paramFloat);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cb
 * JD-Core Version:    0.6.2
 */