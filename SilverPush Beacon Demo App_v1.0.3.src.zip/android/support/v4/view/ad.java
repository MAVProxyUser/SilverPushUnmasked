package android.support.v4.view;

import android.view.MenuItem;

class ad extends ac
{
  public boolean b(MenuItem paramMenuItem)
  {
    return ah.a(paramMenuItem);
  }

  public boolean c(MenuItem paramMenuItem)
  {
    return ah.b(paramMenuItem);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ad
 * JD-Core Version:    0.6.2
 */