package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

abstract interface be
{
  public abstract int a(int paramInt1, int paramInt2, int paramInt3);

  public abstract void a(View paramView);

  public abstract void a(View paramView, float paramFloat);

  public abstract void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract void a(View paramView, int paramInt, Paint paramPaint);

  public abstract void a(View paramView, Paint paramPaint);

  public abstract void a(View paramView, a parama);

  public abstract void a(View paramView, an paraman);

  public abstract void a(View paramView, Runnable paramRunnable);

  public abstract void a(View paramView, Runnable paramRunnable, long paramLong);

  public abstract boolean a(View paramView, int paramInt);

  public abstract int b(View paramView);

  public abstract void b(View paramView, float paramFloat);

  public abstract void b(View paramView, int paramInt);

  public abstract void c(View paramView);

  public abstract void c(View paramView, float paramFloat);

  public abstract int d(View paramView);

  public abstract void d(View paramView, float paramFloat);

  public abstract int e(View paramView);

  public abstract void e(View paramView, float paramFloat);

  public abstract boolean f(View paramView);

  public abstract int g(View paramView);

  public abstract float h(View paramView);

  public abstract int i(View paramView);

  public abstract cf j(View paramView);

  public abstract int k(View paramView);

  public abstract boolean l(View paramView);

  public abstract void m(View paramView);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.be
 * JD-Core Version:    0.6.2
 */