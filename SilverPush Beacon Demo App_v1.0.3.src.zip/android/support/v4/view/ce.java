package android.support.v4.view;

import android.view.View;
import java.util.Comparator;

class ce
  implements Comparator
{
  public int a(View paramView1, View paramView2)
  {
    by localby1 = (by)paramView1.getLayoutParams();
    by localby2 = (by)paramView2.getLayoutParams();
    if (localby1.a != localby2.a)
    {
      if (localby1.a)
        return 1;
      return -1;
    }
    return localby1.e - localby2.e;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ce
 * JD-Core Version:    0.6.2
 */