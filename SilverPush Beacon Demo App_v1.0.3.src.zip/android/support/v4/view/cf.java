package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public class cf
{
  static final co a = new ch();
  private WeakReference b;
  private Runnable c = null;
  private Runnable d = null;
  private int e = -1;

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
    {
      a = new cn();
      return;
    }
    if (i >= 18)
    {
      a = new cl();
      return;
    }
    if (i >= 16)
    {
      a = new cm();
      return;
    }
    if (i >= 14)
    {
      a = new cj();
      return;
    }
  }

  cf(View paramView)
  {
    this.b = new WeakReference(paramView);
  }

  public cf a(float paramFloat)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.a(this, localView, paramFloat);
    return this;
  }

  public cf a(long paramLong)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.a(this, localView, paramLong);
    return this;
  }

  public cf a(cv paramcv)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.a(this, localView, paramcv);
    return this;
  }

  public cf a(cx paramcx)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.a(this, localView, paramcx);
    return this;
  }

  public cf a(Interpolator paramInterpolator)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.a(this, localView, paramInterpolator);
    return this;
  }

  public void a()
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.a(this, localView);
  }

  public cf b(float paramFloat)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.b(this, localView, paramFloat);
    return this;
  }

  public void b()
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.b(this, localView);
  }

  public cf c(float paramFloat)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.c(this, localView, paramFloat);
    return this;
  }

  public cf d(float paramFloat)
  {
    View localView = (View)this.b.get();
    if (localView != null)
      a.d(this, localView, paramFloat);
    return this;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.cf
 * JD-Core Version:    0.6.2
 */