package android.support.v4.view;

import android.view.KeyEvent;

class t
{
  public static void a(KeyEvent paramKeyEvent)
  {
    paramKeyEvent.startTracking();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.t
 * JD-Core Version:    0.6.2
 */