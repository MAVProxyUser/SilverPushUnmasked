package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;

public class ap
{
  static final as a = new aq();

  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new ar();
      return;
    }
  }

  public static float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return a.a(paramVelocityTracker, paramInt);
  }

  public static float b(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return a.b(paramVelocityTracker, paramInt);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ap
 * JD-Core Version:    0.6.2
 */