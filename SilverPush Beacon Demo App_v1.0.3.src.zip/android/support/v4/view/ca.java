package android.support.v4.view;

public abstract interface ca
{
  public abstract void a(int paramInt);

  public abstract void a(int paramInt1, float paramFloat, int paramInt2);

  public abstract void b(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ca
 * JD-Core Version:    0.6.2
 */