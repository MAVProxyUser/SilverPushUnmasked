package android.support.v4.view;

import android.view.View.AccessibilityDelegate;

class f
{
  public static Object a()
  {
    return new View.AccessibilityDelegate();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.f
 * JD-Core Version:    0.6.2
 */