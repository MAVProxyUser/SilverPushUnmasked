package android.support.v4.view;

import android.view.View;
import android.view.animation.Interpolator;
import java.util.WeakHashMap;

class ch
  implements co
{
  WeakHashMap a = null;

  private void a(View paramView)
  {
    if (this.a != null)
    {
      Runnable localRunnable = (Runnable)this.a.get(paramView);
      if (localRunnable != null)
        paramView.removeCallbacks(localRunnable);
    }
  }

  private void c(cf paramcf, View paramView)
  {
    Object localObject = paramView.getTag(2113929216);
    if ((localObject instanceof cv));
    for (cv localcv = (cv)localObject; ; localcv = null)
    {
      Runnable localRunnable1 = cf.a(paramcf);
      Runnable localRunnable2 = cf.b(paramcf);
      if (localRunnable1 != null)
        localRunnable1.run();
      if (localcv != null)
      {
        localcv.a(paramView);
        localcv.b(paramView);
      }
      if (localRunnable2 != null)
        localRunnable2.run();
      if (this.a != null)
        this.a.remove(paramView);
      return;
    }
  }

  private void d(cf paramcf, View paramView)
  {
    if (this.a != null);
    for (Object localObject = (Runnable)this.a.get(paramView); ; localObject = null)
    {
      if (localObject == null)
      {
        localObject = new ci(this, paramcf, paramView, null);
        if (this.a == null)
          this.a = new WeakHashMap();
        this.a.put(paramView, localObject);
      }
      paramView.removeCallbacks((Runnable)localObject);
      paramView.post((Runnable)localObject);
      return;
    }
  }

  public void a(cf paramcf, View paramView)
  {
    d(paramcf, paramView);
  }

  public void a(cf paramcf, View paramView, float paramFloat)
  {
    d(paramcf, paramView);
  }

  public void a(cf paramcf, View paramView, long paramLong)
  {
  }

  public void a(cf paramcf, View paramView, cv paramcv)
  {
    paramView.setTag(2113929216, paramcv);
  }

  public void a(cf paramcf, View paramView, cx paramcx)
  {
  }

  public void a(cf paramcf, View paramView, Interpolator paramInterpolator)
  {
  }

  public void b(cf paramcf, View paramView)
  {
    a(paramView);
    c(paramcf, paramView);
  }

  public void b(cf paramcf, View paramView, float paramFloat)
  {
    d(paramcf, paramView);
  }

  public void c(cf paramcf, View paramView, float paramFloat)
  {
    d(paramcf, paramView);
  }

  public void d(cf paramcf, View paramView, float paramFloat)
  {
    d(paramcf, paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ch
 * JD-Core Version:    0.6.2
 */