package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewConfiguration;

public class bn
{
  static final bs a = new bo();

  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      a = new br();
      return;
    }
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new bq();
      return;
    }
    if (Build.VERSION.SDK_INT >= 8)
    {
      a = new bp();
      return;
    }
  }

  public static boolean a(ViewConfiguration paramViewConfiguration)
  {
    return a.a(paramViewConfiguration);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.bn
 * JD-Core Version:    0.6.2
 */