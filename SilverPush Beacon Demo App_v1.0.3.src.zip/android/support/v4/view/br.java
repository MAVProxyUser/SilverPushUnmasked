package android.support.v4.view;

import android.view.ViewConfiguration;

class br extends bq
{
  public boolean a(ViewConfiguration paramViewConfiguration)
  {
    return bt.a(paramViewConfiguration);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.br
 * JD-Core Version:    0.6.2
 */