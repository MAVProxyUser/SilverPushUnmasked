package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

abstract interface ae
{
  public abstract MenuItem a(MenuItem paramMenuItem, View paramView);

  public abstract View a(MenuItem paramMenuItem);

  public abstract void a(MenuItem paramMenuItem, int paramInt);

  public abstract MenuItem b(MenuItem paramMenuItem, int paramInt);

  public abstract boolean b(MenuItem paramMenuItem);

  public abstract boolean c(MenuItem paramMenuItem);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ae
 * JD-Core Version:    0.6.2
 */