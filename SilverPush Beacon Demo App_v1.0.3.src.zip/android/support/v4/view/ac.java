package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

class ac
  implements ae
{
  public MenuItem a(MenuItem paramMenuItem, View paramView)
  {
    return ag.a(paramMenuItem, paramView);
  }

  public View a(MenuItem paramMenuItem)
  {
    return ag.a(paramMenuItem);
  }

  public void a(MenuItem paramMenuItem, int paramInt)
  {
    ag.a(paramMenuItem, paramInt);
  }

  public MenuItem b(MenuItem paramMenuItem, int paramInt)
  {
    return ag.b(paramMenuItem, paramInt);
  }

  public boolean b(MenuItem paramMenuItem)
  {
    return false;
  }

  public boolean c(MenuItem paramMenuItem)
  {
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     android.support.v4.view.ac
 * JD-Core Version:    0.6.2
 */