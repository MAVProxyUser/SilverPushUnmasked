package a.a.a;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.List;
import java.util.Locale;

public class a
{
  private Context a;
  private TelephonyManager b;
  private String c;
  private final String d = "1.1.0";
  private final int e = 1;

  public a(Context paramContext)
  {
    this.a = paramContext;
    this.b = ((TelephonyManager)paramContext.getSystemService("phone"));
    this.c = "N/A";
  }

  public String a()
  {
    String str1 = this.c;
    try
    {
      String str2 = Settings.Secure.getString(this.a.getContentResolver(), "android_id");
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public double[] a(Context paramContext)
  {
    double[] arrayOfDouble = { 0.0D, 0.0D };
    while (true)
    {
      Location localLocation1;
      try
      {
        LocationManager localLocationManager = (LocationManager)paramContext.getSystemService("location");
        List localList = localLocationManager.getProviders(true);
        int i = -1 + localList.size();
        localLocation1 = null;
        int j = i;
        if (j >= 0)
        {
          localLocation1 = localLocationManager.getLastKnownLocation((String)localList.get(j));
          if (localLocation1 != null)
          {
            localLocation2 = localLocation1;
            if (localLocation2 != null)
            {
              arrayOfDouble[0] = localLocation2.getLatitude();
              arrayOfDouble[1] = localLocation2.getLongitude();
            }
            return arrayOfDouble;
          }
          j--;
          continue;
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return arrayOfDouble;
      }
      Location localLocation2 = localLocation1;
    }
  }

  public String b()
  {
    String str1 = this.c;
    try
    {
      String str2 = Build.MODEL;
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String b(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      ApplicationInfo localApplicationInfo2 = localPackageManager.getApplicationInfo(paramContext.getPackageName(), 0);
      localApplicationInfo1 = localApplicationInfo2;
      if (localApplicationInfo1 != null)
      {
        localObject = localPackageManager.getApplicationLabel(localApplicationInfo1);
        return (String)localObject;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
      {
        localNameNotFoundException.printStackTrace();
        ApplicationInfo localApplicationInfo1 = null;
        continue;
        Object localObject = this.c;
      }
    }
  }

  public String c()
  {
    String str1 = this.c;
    try
    {
      String str2 = Build.MANUFACTURER;
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String c(Context paramContext)
  {
    String str1 = this.c;
    try
    {
      String str2 = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionName;
      return str2;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      localNameNotFoundException.printStackTrace();
    }
    return str1;
  }

  public String d()
  {
    String str1 = this.c;
    try
    {
      Display localDisplay = ((WindowManager)this.a.getSystemService("window")).getDefaultDisplay();
      DisplayMetrics localDisplayMetrics = new DisplayMetrics();
      localDisplay.getMetrics(localDisplayMetrics);
      String str2 = localDisplayMetrics.heightPixels + "px" + " X " + localDisplayMetrics.widthPixels + "px";
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String d(Context paramContext)
  {
    String str1 = this.c;
    try
    {
      String str2 = String.valueOf(paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionCode);
      return str2;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      localNameNotFoundException.printStackTrace();
    }
    return str1;
  }

  public String e()
  {
    Object localObject = this.c;
    try
    {
      if (this.b.getPhoneType() != 2)
      {
        String str = this.b.getNetworkOperatorName().toLowerCase(Locale.getDefault());
        localObject = str;
      }
      return localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return localObject;
  }

  public String e(Context paramContext)
  {
    String str1 = this.c;
    try
    {
      String str2 = paramContext.getPackageName();
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String f()
  {
    String str1 = this.c;
    try
    {
      String str2 = Locale.getDefault().getLanguage();
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String[] f(Context paramContext)
  {
    String[] arrayOfString;
    try
    {
      Account[] arrayOfAccount = AccountManager.get(paramContext).getAccountsByType("com.google");
      arrayOfString = new String[arrayOfAccount.length];
      for (int i = 0; i < arrayOfAccount.length; i++)
        arrayOfString[i] = arrayOfAccount[i].name;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      arrayOfString = null;
    }
    return arrayOfString;
  }

  public String g()
  {
    String str1 = this.c;
    try
    {
      if (this.b.getSimState() == 5)
        return this.b.getSimCountryIso().toLowerCase(Locale.getDefault());
      Locale localLocale = Locale.getDefault();
      String str2 = localLocale.getCountry().toLowerCase(localLocale);
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String h()
  {
    int i = this.a.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE");
    Object localObject1 = this.c;
    Object localObject2;
    if (i == 0)
    {
      try
      {
        NetworkInfo localNetworkInfo = ((ConnectivityManager)this.a.getSystemService("connectivity")).getActiveNetworkInfo();
        if (localNetworkInfo == null)
        {
          localObject2 = "Unknown";
        }
        else
        {
          if ((localNetworkInfo.getType() == 1) || (localNetworkInfo.getType() == 6))
            break label206;
          if (localNetworkInfo.getType() == 0)
          {
            TelephonyManager localTelephonyManager = (TelephonyManager)this.a.getSystemService("phone");
            if (localTelephonyManager.getSimState() == 5)
              switch (localTelephonyManager.getNetworkType())
              {
              case 13:
                localObject2 = "Cellular - 4G";
              case 14:
              default:
              case 0:
              case 1:
              case 2:
              case 4:
              case 7:
              case 11:
              case 3:
              case 5:
              case 6:
              case 8:
              case 9:
              case 10:
              case 12:
              case 15:
              }
          }
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return localObject1;
      }
      localObject2 = localObject1;
    }
    while (true)
    {
      localObject1 = localObject2;
      return localObject1;
      label206: localObject2 = "Wifi/WifiMax";
      continue;
      localObject2 = "Cellular - Unknown Generation";
      continue;
      localObject2 = "Cellular - Unknown";
      continue;
      localObject2 = "Cellular - 2G";
      continue;
      localObject2 = "Cellular - 3G";
    }
  }

  public String i()
  {
    String str1 = this.c;
    try
    {
      String str2 = Build.VERSION.RELEASE;
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String j()
  {
    String str1 = this.c;
    try
    {
      String str2 = ((WifiManager)this.a.getSystemService("wifi")).getConnectionInfo().getMacAddress();
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String k()
  {
    String str1 = this.c;
    try
    {
      String str2 = this.b.getDeviceId();
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public String l()
  {
    String str = this.c;
    try
    {
      if (this.b.getLine1Number() != null)
      {
        str = this.b.getLine1Number();
        if (str.equals(""))
          str = this.c;
      }
      return str;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str;
  }

  public String m()
  {
    String str1 = this.c;
    try
    {
      String str2 = new WebView(this.a).getSettings().getUserAgentString() + "\n\n" + System.getProperty("http.agent");
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }

  public long n()
  {
    return System.currentTimeMillis();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     a.a.a.a
 * JD-Core Version:    0.6.2
 */