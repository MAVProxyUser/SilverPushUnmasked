package a.a.b.a;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.util.Log;
import java.util.HashMap;

public class c
{
  private String a = getClass().getSimpleName();
  private int b;
  private int c;
  private boolean d = false;

  public c()
  {
    b(2);
    a(0);
  }

  @TargetApi(11)
  private void a(a parama, b paramb, d paramd)
  {
    parama.a(paramd);
    if (Build.VERSION.SDK_INT >= 11)
    {
      parama.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new b[] { paramb });
      return;
    }
    parama.execute(new b[] { paramb });
  }

  private boolean a(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
    return (localNetworkInfo != null) && (localNetworkInfo.isConnected());
  }

  private void b(a parama, b paramb, d paramd)
  {
    parama.a(paramd);
    parama.execute(new b[] { paramb });
  }

  public void a()
  {
    this.d = true;
  }

  public void a(int paramInt)
  {
    this.b = paramInt;
  }

  public void a(Context paramContext, a parama, String paramString, HashMap paramHashMap, d paramd)
  {
    b localb = new b();
    if (this.b == 0)
    {
      localb.b("GET");
      if (!this.d);
    }
    label132: 
    do
    {
      do
      {
        Log.d(this.a, "*---------------------- GET Request ----------------------*");
        while (true)
        {
          localb.a(paramString);
          localb.a(paramHashMap);
          if (!a(paramContext))
            break label132;
          if (this.c != 2)
            break;
          b(parama, localb, paramd);
          return;
          if (this.b == 1)
          {
            localb.b("POST");
            if (this.d)
              Log.d(this.a, "*---------------------- POST Request ----------------------*");
          }
        }
      }
      while (this.c != 3);
      a(parama, localb, paramd);
      return;
    }
    while (!this.d);
    Log.d(this.a, "Not connected to Internet ! OptimusHTTP didn't make a request!");
  }

  public void b(int paramInt)
  {
    this.c = paramInt;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     a.a.b.a.c
 * JD-Core Version:    0.6.2
 */