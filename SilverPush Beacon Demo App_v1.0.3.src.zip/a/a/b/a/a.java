package a.a.b.a;

import android.os.AsyncTask;
import android.os.Build.VERSION;

public class a extends AsyncTask
{
  d a;
  private int b = 0;
  private String c = "na";

  private void a()
  {
    if (Build.VERSION.SDK_INT < 8)
      System.setProperty("http.keepAlive", "false");
  }

  // ERROR //
  protected String a(b[] paramArrayOfb)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: iconst_0
    //   4: aaload
    //   5: invokevirtual 45	a/a/b/a/b:b	()Ljava/lang/String;
    //   8: astore_3
    //   9: aload_1
    //   10: iconst_0
    //   11: aaload
    //   12: invokevirtual 47	a/a/b/a/b:c	()Ljava/lang/String;
    //   15: astore 4
    //   17: aload_3
    //   18: ifnull +510 -> 528
    //   21: aload 4
    //   23: ifnull +505 -> 528
    //   26: new 49	java/lang/String
    //   29: dup
    //   30: new 51	java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial 52	java/lang/StringBuilder:<init>	()V
    //   37: aload_3
    //   38: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: ldc 58
    //   43: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: aload 4
    //   48: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   54: invokevirtual 65	java/lang/String:getBytes	()[B
    //   57: iconst_0
    //   58: invokestatic 71	android/util/Base64:encode	([BI)[B
    //   61: invokespecial 74	java/lang/String:<init>	([B)V
    //   64: astore 5
    //   66: aload_1
    //   67: iconst_0
    //   68: aaload
    //   69: invokevirtual 76	a/a/b/a/b:a	()Ljava/lang/String;
    //   72: astore 6
    //   74: aload_1
    //   75: iconst_0
    //   76: aaload
    //   77: invokevirtual 79	a/a/b/a/b:d	()Ljava/lang/String;
    //   80: ldc 81
    //   82: invokevirtual 85	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   85: ifeq +34 -> 119
    //   88: new 51	java/lang/StringBuilder
    //   91: dup
    //   92: invokespecial 52	java/lang/StringBuilder:<init>	()V
    //   95: aload 6
    //   97: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: ldc 87
    //   102: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: aload_1
    //   106: iconst_0
    //   107: aaload
    //   108: invokevirtual 90	a/a/b/a/b:e	()Ljava/lang/String;
    //   111: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   117: astore 6
    //   119: new 92	java/net/URL
    //   122: dup
    //   123: aload 6
    //   125: invokespecial 95	java/net/URL:<init>	(Ljava/lang/String;)V
    //   128: invokevirtual 99	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   131: checkcast 101	java/net/HttpURLConnection
    //   134: astore 14
    //   136: aload 5
    //   138: ifnull +30 -> 168
    //   141: aload 14
    //   143: ldc 103
    //   145: new 51	java/lang/StringBuilder
    //   148: dup
    //   149: invokespecial 52	java/lang/StringBuilder:<init>	()V
    //   152: ldc 105
    //   154: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: aload 5
    //   159: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   165: invokevirtual 109	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   168: aload_1
    //   169: iconst_0
    //   170: aaload
    //   171: invokevirtual 79	a/a/b/a/b:d	()Ljava/lang/String;
    //   174: ldc 111
    //   176: invokevirtual 85	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   179: ifeq +16 -> 195
    //   182: aload 14
    //   184: ldc 111
    //   186: invokevirtual 114	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   189: aload 14
    //   191: iconst_1
    //   192: invokevirtual 118	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   195: aload 14
    //   197: sipush 10000
    //   200: invokevirtual 122	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   203: aload 14
    //   205: sipush 10000
    //   208: invokevirtual 125	java/net/HttpURLConnection:setReadTimeout	(I)V
    //   211: aload 14
    //   213: ldc 127
    //   215: ldc 129
    //   217: invokevirtual 109	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   220: aload 14
    //   222: invokevirtual 132	java/net/HttpURLConnection:connect	()V
    //   225: aload_1
    //   226: iconst_0
    //   227: aaload
    //   228: invokevirtual 79	a/a/b/a/b:d	()Ljava/lang/String;
    //   231: ldc 111
    //   233: invokevirtual 85	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   236: ifeq +38 -> 274
    //   239: new 134	java/io/OutputStreamWriter
    //   242: dup
    //   243: aload 14
    //   245: invokevirtual 138	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   248: invokespecial 141	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   251: astore 15
    //   253: aload 15
    //   255: aload_1
    //   256: iconst_0
    //   257: aaload
    //   258: invokevirtual 90	a/a/b/a/b:e	()Ljava/lang/String;
    //   261: invokevirtual 144	java/io/OutputStreamWriter:write	(Ljava/lang/String;)V
    //   264: aload 15
    //   266: invokevirtual 147	java/io/OutputStreamWriter:flush	()V
    //   269: aload 15
    //   271: invokevirtual 150	java/io/OutputStreamWriter:close	()V
    //   274: aload_0
    //   275: aload 14
    //   277: invokevirtual 154	java/net/HttpURLConnection:getResponseCode	()I
    //   280: putfield 16	a/a/b/a/a:b	I
    //   283: aload_0
    //   284: aload 14
    //   286: invokevirtual 157	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
    //   289: putfield 20	a/a/b/a/a:c	Ljava/lang/String;
    //   292: aload_0
    //   293: getfield 16	a/a/b/a/a:b	I
    //   296: sipush 400
    //   299: if_icmplt +111 -> 410
    //   302: aload 14
    //   304: invokevirtual 161	java/net/HttpURLConnection:getErrorStream	()Ljava/io/InputStream;
    //   307: astore 17
    //   309: new 163	java/io/BufferedReader
    //   312: dup
    //   313: new 165	java/io/InputStreamReader
    //   316: dup
    //   317: aload 17
    //   319: invokespecial 168	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   322: invokespecial 171	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   325: astore 8
    //   327: new 51	java/lang/StringBuilder
    //   330: dup
    //   331: invokespecial 52	java/lang/StringBuilder:<init>	()V
    //   334: astore 18
    //   336: aload 8
    //   338: invokevirtual 174	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   341: astore 19
    //   343: aload 19
    //   345: ifnull +79 -> 424
    //   348: aload 18
    //   350: new 51	java/lang/StringBuilder
    //   353: dup
    //   354: invokespecial 52	java/lang/StringBuilder:<init>	()V
    //   357: aload 19
    //   359: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: ldc 176
    //   364: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   370: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   373: pop
    //   374: goto -38 -> 336
    //   377: astore 7
    //   379: aload 7
    //   381: invokevirtual 179	java/lang/Exception:printStackTrace	()V
    //   384: aload 7
    //   386: athrow
    //   387: astore 11
    //   389: aload 11
    //   391: invokevirtual 180	java/io/IOException:printStackTrace	()V
    //   394: aconst_null
    //   395: astore 12
    //   397: aload 8
    //   399: ifnull +8 -> 407
    //   402: aload 8
    //   404: invokevirtual 181	java/io/BufferedReader:close	()V
    //   407: aload 12
    //   409: areturn
    //   410: aload 14
    //   412: invokevirtual 184	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   415: astore 16
    //   417: aload 16
    //   419: astore 17
    //   421: goto -112 -> 309
    //   424: aload 18
    //   426: aload_0
    //   427: getfield 16	a/a/b/a/a:b	I
    //   430: invokevirtual 187	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   433: ldc 189
    //   435: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   438: aload_0
    //   439: getfield 20	a/a/b/a/a:c	Ljava/lang/String;
    //   442: invokevirtual 56	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   445: pop
    //   446: aload 18
    //   448: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   451: astore 22
    //   453: aload 22
    //   455: astore 12
    //   457: aload 8
    //   459: ifnull -52 -> 407
    //   462: aload 8
    //   464: invokevirtual 181	java/io/BufferedReader:close	()V
    //   467: aload 12
    //   469: areturn
    //   470: astore 23
    //   472: aload 23
    //   474: invokevirtual 180	java/io/IOException:printStackTrace	()V
    //   477: aload 12
    //   479: areturn
    //   480: astore 13
    //   482: aload 13
    //   484: invokevirtual 180	java/io/IOException:printStackTrace	()V
    //   487: aconst_null
    //   488: areturn
    //   489: astore 9
    //   491: aload_2
    //   492: ifnull +7 -> 499
    //   495: aload_2
    //   496: invokevirtual 181	java/io/BufferedReader:close	()V
    //   499: aload 9
    //   501: athrow
    //   502: astore 10
    //   504: aload 10
    //   506: invokevirtual 180	java/io/IOException:printStackTrace	()V
    //   509: goto -10 -> 499
    //   512: astore 9
    //   514: aload 8
    //   516: astore_2
    //   517: goto -26 -> 491
    //   520: astore 7
    //   522: aconst_null
    //   523: astore 8
    //   525: goto -146 -> 379
    //   528: aconst_null
    //   529: astore 5
    //   531: goto -465 -> 66
    //
    // Exception table:
    //   from	to	target	type
    //   327	336	377	java/lang/Exception
    //   336	343	377	java/lang/Exception
    //   348	374	377	java/lang/Exception
    //   424	453	377	java/lang/Exception
    //   384	387	387	java/io/IOException
    //   462	467	470	java/io/IOException
    //   402	407	480	java/io/IOException
    //   119	136	489	finally
    //   141	168	489	finally
    //   168	195	489	finally
    //   195	274	489	finally
    //   274	309	489	finally
    //   309	327	489	finally
    //   410	417	489	finally
    //   495	499	502	java/io/IOException
    //   327	336	512	finally
    //   336	343	512	finally
    //   348	374	512	finally
    //   379	384	512	finally
    //   384	387	512	finally
    //   389	394	512	finally
    //   424	453	512	finally
    //   119	136	520	java/lang/Exception
    //   141	168	520	java/lang/Exception
    //   168	195	520	java/lang/Exception
    //   195	274	520	java/lang/Exception
    //   274	309	520	java/lang/Exception
    //   309	327	520	java/lang/Exception
    //   410	417	520	java/lang/Exception
  }

  public void a(d paramd)
  {
    this.a = paramd;
  }

  protected void a(String paramString)
  {
    if (this.a != null)
    {
      if (paramString != null)
        this.a.a(paramString);
    }
    else
      return;
    this.a.b(Integer.toString(this.b) + " : " + this.c);
  }

  protected void onPreExecute()
  {
    a();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     a.a.b.a.a
 * JD-Core Version:    0.6.2
 */