package a.a.b.a;

public abstract interface d
{
  public abstract void a(String paramString);

  public abstract void b(String paramString);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     a.a.b.a.d
 * JD-Core Version:    0.6.2
 */