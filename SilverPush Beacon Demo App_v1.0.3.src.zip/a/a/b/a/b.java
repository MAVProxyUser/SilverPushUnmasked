package a.a.b.a;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class b
{
  private String a;
  private String b = null;
  private String c = null;
  private String d = "GET";
  private Map e = new HashMap();

  public String a()
  {
    return this.a;
  }

  public void a(String paramString)
  {
    this.a = paramString;
  }

  public void a(Map paramMap)
  {
    this.e = paramMap;
  }

  public String b()
  {
    return this.b;
  }

  public void b(String paramString)
  {
    this.d = paramString;
  }

  String c()
  {
    return this.a;
  }

  public String d()
  {
    return this.d;
  }

  public String e()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Object localObject1 = null;
    Iterator localIterator = this.e.keySet().iterator();
    while (true)
      if (localIterator.hasNext())
      {
        String str1 = (String)localIterator.next();
        try
        {
          String str2 = URLEncoder.encode((String)this.e.get(str1), "UTF-8");
          localObject2 = str2;
          if (localStringBuilder.length() > 0)
            localStringBuilder.append("&");
          localStringBuilder.append(str1 + "=" + (String)localObject2);
          localObject1 = localObject2;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          while (true)
          {
            localUnsupportedEncodingException.printStackTrace();
            Object localObject2 = localObject1;
          }
        }
      }
    return localStringBuilder.toString();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPush Beacon Demo App_v1.0.3.jar
 * Qualified Name:     a.a.b.a.b
 * JD-Core Version:    0.6.2
 */