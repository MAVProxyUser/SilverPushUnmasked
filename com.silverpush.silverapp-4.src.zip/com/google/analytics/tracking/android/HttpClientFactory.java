package com.google.analytics.tracking.android;

import org.apache.http.client.HttpClient;

abstract interface HttpClientFactory
{
  public abstract HttpClient newInstance();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.HttpClientFactory
 * JD-Core Version:    0.6.2
 */