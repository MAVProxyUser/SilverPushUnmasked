package com.google.analytics.tracking.android;

import java.util.Map;
import java.util.Random;

class AdMobInfo
{
  private static final AdMobInfo INSTANCE = new AdMobInfo();
  private int adHitId;
  private Random random = new Random();

  static AdMobInfo getInstance()
  {
    return INSTANCE;
  }

  int generateAdHitId()
  {
    this.adHitId = (1 + this.random.nextInt(2147483646));
    return this.adHitId;
  }

  int getAdHitId()
  {
    return this.adHitId;
  }

  Map<String, String> getJoinIds()
  {
    return null;
  }

  void setAdHitId(int paramInt)
  {
    this.adHitId = paramInt;
  }

  static enum AdMobKey
  {
    private String bowParameter;

    static
    {
      AdMobKey[] arrayOfAdMobKey = new AdMobKey[4];
      arrayOfAdMobKey[0] = CLIENT_ID_KEY;
      arrayOfAdMobKey[1] = HIT_ID_KEY;
      arrayOfAdMobKey[2] = PROPERTY_ID_KEY;
      arrayOfAdMobKey[3] = VISITOR_ID_KEY;
    }

    private AdMobKey(String paramString)
    {
      this.bowParameter = paramString;
    }

    String getBowParameter()
    {
      return this.bowParameter;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.AdMobInfo
 * JD-Core Version:    0.6.2
 */