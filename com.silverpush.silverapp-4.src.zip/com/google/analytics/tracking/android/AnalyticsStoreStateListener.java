package com.google.analytics.tracking.android;

abstract interface AnalyticsStoreStateListener
{
  public abstract void reportStoreIsEmpty(boolean paramBoolean);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.AnalyticsStoreStateListener
 * JD-Core Version:    0.6.2
 */