package com.google.analytics.tracking.android;

public class ExceptionReporter
  implements Thread.UncaughtExceptionHandler
{
  private ExceptionParser exceptionParser;
  private final Thread.UncaughtExceptionHandler originalHandler;
  private final ServiceManager serviceManager;
  private final Tracker tracker;

  public ExceptionReporter(Tracker paramTracker, ServiceManager paramServiceManager, Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler)
  {
    if (paramTracker == null)
      throw new NullPointerException("tracker cannot be null");
    if (paramServiceManager == null)
      throw new NullPointerException("serviceManager cannot be null");
    this.originalHandler = paramUncaughtExceptionHandler;
    this.tracker = paramTracker;
    this.serviceManager = paramServiceManager;
    StringBuilder localStringBuilder = new StringBuilder().append("ExceptionReporter created, original handler is ");
    if (paramUncaughtExceptionHandler == null);
    for (String str = "null"; ; str = paramUncaughtExceptionHandler.getClass().getName())
    {
      Log.iDebug(str);
      return;
    }
  }

  public ExceptionParser getExceptionParser()
  {
    return this.exceptionParser;
  }

  public void setExceptionParser(ExceptionParser paramExceptionParser)
  {
    this.exceptionParser = paramExceptionParser;
  }

  public void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    String str2;
    if (this.exceptionParser == null)
    {
      str2 = paramThrowable.getMessage();
      Log.iDebug("Tracking Exception: " + str2);
      this.tracker.trackException(str2, true);
      this.serviceManager.dispatch();
      if (this.originalHandler != null)
      {
        Log.iDebug("Passing exception to original handler.");
        this.originalHandler.uncaughtException(paramThread, paramThrowable);
      }
      return;
    }
    if (paramThread != null);
    for (String str1 = paramThread.getName(); ; str1 = null)
    {
      str2 = this.exceptionParser.getDescription(str1, paramThrowable);
      break;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.ExceptionReporter
 * JD-Core Version:    0.6.2
 */