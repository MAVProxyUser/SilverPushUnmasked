package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;

class ParameterLoaderImpl
  implements ParameterLoader
{
  private final Context ctx;

  public ParameterLoaderImpl(Context paramContext)
  {
    if (paramContext == null)
      throw new NullPointerException("Context cannot be null");
    this.ctx = paramContext.getApplicationContext();
  }

  private int getResourceIdForType(String paramString1, String paramString2)
  {
    if (this.ctx == null)
      return 0;
    return this.ctx.getResources().getIdentifier(paramString1, paramString2, this.ctx.getPackageName());
  }

  public boolean getBoolean(String paramString)
  {
    int i = getResourceIdForType(paramString, "bool");
    if (i == 0)
      return false;
    return "true".equalsIgnoreCase(this.ctx.getString(i));
  }

  public Double getDoubleFromString(String paramString)
  {
    String str = getString(paramString);
    if (TextUtils.isEmpty(str))
      return null;
    try
    {
      Double localDouble = Double.valueOf(Double.parseDouble(str));
      return localDouble;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      Log.w("NumberFormatException parsing " + str);
    }
    return null;
  }

  public int getInt(String paramString, int paramInt)
  {
    int i = getResourceIdForType(paramString, "integer");
    if (i == 0)
      return paramInt;
    try
    {
      int j = Integer.parseInt(this.ctx.getString(i));
      return j;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      Log.w("NumberFormatException parsing " + this.ctx.getString(i));
    }
    return paramInt;
  }

  public String getString(String paramString)
  {
    int i = getResourceIdForType(paramString, "string");
    if (i == 0)
      return null;
    return this.ctx.getString(i);
  }

  public boolean isBooleanKeyPresent(String paramString)
  {
    return getResourceIdForType(paramString, "bool") != 0;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.ParameterLoaderImpl
 * JD-Core Version:    0.6.2
 */