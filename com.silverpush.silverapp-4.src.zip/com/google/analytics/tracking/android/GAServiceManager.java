package com.google.analytics.tracking.android;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;

public class GAServiceManager
  implements ServiceManager
{
  private static final int MSG_KEY = 1;
  private static final Object MSG_OBJECT = new Object();
  private static GAServiceManager instance;
  private Context ctx;
  private int dispatchPeriodInSeconds = 1800;
  private Handler handler;
  private AnalyticsStoreStateListener listener = new AnalyticsStoreStateListener()
  {
    public void reportStoreIsEmpty(boolean paramAnonymousBoolean)
    {
      GAServiceManager.this.updatePowerSaveMode(paramAnonymousBoolean);
    }
  };
  private boolean pendingDispatch = true;
  private boolean powerSaveMode = false;
  private AnalyticsStore store;
  private volatile AnalyticsThread thread;

  private GAServiceManager()
  {
  }

  GAServiceManager(Context paramContext, AnalyticsThread paramAnalyticsThread, AnalyticsStore paramAnalyticsStore)
  {
    this.store = paramAnalyticsStore;
    this.thread = paramAnalyticsThread;
    initialize(paramContext, paramAnalyticsThread);
  }

  public static GAServiceManager getInstance()
  {
    if (instance == null)
      instance = new GAServiceManager();
    return instance;
  }

  private void initializeHandler()
  {
    this.handler = new Handler(this.ctx.getMainLooper(), new Handler.Callback()
    {
      public boolean handleMessage(Message paramAnonymousMessage)
      {
        if ((1 == paramAnonymousMessage.what) && (GAServiceManager.MSG_OBJECT.equals(paramAnonymousMessage.obj)))
        {
          GAUsage.getInstance().setDisableUsage(true);
          GAServiceManager.this.dispatch();
          GAUsage.getInstance().setDisableUsage(false);
          if ((GAServiceManager.this.dispatchPeriodInSeconds > 0) && (!GAServiceManager.this.powerSaveMode))
            GAServiceManager.this.handler.sendMessageDelayed(GAServiceManager.this.handler.obtainMessage(1, GAServiceManager.MSG_OBJECT), 1000 * GAServiceManager.this.dispatchPeriodInSeconds);
        }
        return true;
      }
    });
    if (this.dispatchPeriodInSeconds > 0)
      this.handler.sendMessageDelayed(this.handler.obtainMessage(1, MSG_OBJECT), 1000 * this.dispatchPeriodInSeconds);
  }

  public void dispatch()
  {
    try
    {
      if (this.thread == null)
      {
        Log.w("dispatch call queued.  Need to call GAServiceManager.getInstance().initialize().");
        this.pendingDispatch = true;
      }
      while (true)
      {
        return;
        GAUsage.getInstance().setUsage(GAUsage.Field.DISPATCH);
        this.thread.dispatch();
      }
    }
    finally
    {
    }
  }

  AnalyticsStoreStateListener getListener()
  {
    return this.listener;
  }

  AnalyticsStore getStore()
  {
    try
    {
      if (this.store != null)
        break label50;
      if (this.ctx == null)
        throw new IllegalStateException("Cant get a store unless we have a context");
    }
    finally
    {
    }
    this.store = new PersistentAnalyticsStore(this.listener, this.ctx);
    label50: if (this.handler == null)
      initializeHandler();
    AnalyticsStore localAnalyticsStore = this.store;
    return localAnalyticsStore;
  }

  void initialize(Context paramContext, AnalyticsThread paramAnalyticsThread)
  {
    try
    {
      Context localContext = this.ctx;
      if (localContext != null);
      while (true)
      {
        return;
        this.ctx = paramContext.getApplicationContext();
        if (this.thread == null)
        {
          this.thread = paramAnalyticsThread;
          if (this.pendingDispatch)
            paramAnalyticsThread.dispatch();
        }
      }
    }
    finally
    {
    }
  }

  public void setDispatchPeriod(int paramInt)
  {
    try
    {
      if (this.handler == null)
      {
        Log.w("Need to call initialize() and be in fallback mode to start dispatch.");
        this.dispatchPeriodInSeconds = paramInt;
      }
      while (true)
      {
        return;
        GAUsage.getInstance().setUsage(GAUsage.Field.SET_DISPATCH_PERIOD);
        if ((!this.powerSaveMode) && (this.dispatchPeriodInSeconds > 0))
          this.handler.removeMessages(1, MSG_OBJECT);
        this.dispatchPeriodInSeconds = paramInt;
        if ((paramInt > 0) && (!this.powerSaveMode))
          this.handler.sendMessageDelayed(this.handler.obtainMessage(1, MSG_OBJECT), paramInt * 1000);
      }
    }
    finally
    {
    }
  }

  void setThrottlingEnabled(boolean paramBoolean)
  {
    this.store.setThrottlingEnabled(paramBoolean);
  }

  void updatePowerSaveMode(boolean paramBoolean)
  {
    while (true)
    {
      try
      {
        boolean bool = this.powerSaveMode;
        if (bool == paramBoolean)
          return;
        if ((paramBoolean) && (this.dispatchPeriodInSeconds > 0))
          this.handler.removeMessages(1, MSG_OBJECT);
        if ((!paramBoolean) && (this.dispatchPeriodInSeconds > 0))
          this.handler.sendMessageDelayed(this.handler.obtainMessage(1, MSG_OBJECT), 1000 * this.dispatchPeriodInSeconds);
        StringBuilder localStringBuilder = new StringBuilder().append("PowerSaveMode ");
        if (paramBoolean)
        {
          str = "initiated.";
          Log.iDebug(str);
          this.powerSaveMode = paramBoolean;
          continue;
        }
      }
      finally
      {
      }
      String str = "terminated.";
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.GAServiceManager
 * JD-Core Version:    0.6.2
 */