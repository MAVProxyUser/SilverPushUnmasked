package com.google.analytics.tracking.android;

public abstract interface ServiceManager
{
  public abstract void dispatch();

  public abstract void setDispatchPeriod(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.google.analytics.tracking.android.ServiceManager
 * JD-Core Version:    0.6.2
 */