package com.ibm.mqtt;

public class MqttConnect extends MqttPacket
{
  public boolean CleanStart;
  protected String ClientId;
  public short KeepAlive;
  public String ProtoName = "MQIsdp";
  public short ProtoVersion = 3;
  public boolean TopicNameCompression;
  public boolean Will;
  public String WillMessage;
  public int WillQoS;
  public boolean WillRetain;
  public String WillTopic;

  public MqttConnect()
  {
    setMsgType((short)1);
  }

  public MqttConnect(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
    setMsgType((short)1);
  }

  public String getClientId()
  {
    return this.ClientId;
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
  }

  public void setClientId(String paramString)
    throws MqttException
  {
    if (paramString.length() > 23)
      throw new MqttException("MQIsdp ClientId > 23 bytes");
    this.ClientId = paramString;
  }

  public byte[] toBytes()
  {
    int i = 1;
    this.message = new byte[42];
    this.message[0] = super.toBytes()[0];
    byte[] arrayOfByte1 = MqttUtils.StringToUTF(this.ProtoName);
    System.arraycopy(arrayOfByte1, 0, this.message, i, arrayOfByte1.length);
    int j = 1 + arrayOfByte1.length;
    byte[] arrayOfByte2 = this.message;
    int k = j + 1;
    arrayOfByte2[j] = ((byte)this.ProtoVersion);
    int m;
    label84: int i5;
    if (this.TopicNameCompression)
    {
      if (!this.CleanStart)
        break label318;
      m = 2;
      if (!this.Will)
        break label330;
      if (!this.WillRetain)
        break label324;
      i5 = 32;
    }
    label102: for (int n = (byte)(0x4 | (i5 | (byte)((0x3 & this.WillQoS) << 3))); ; n = 0)
    {
      byte[] arrayOfByte3 = this.message;
      int i1 = k + 1;
      arrayOfByte3[k] = ((byte)(n | (i | m)));
      byte[] arrayOfByte4 = this.message;
      int i2 = i1 + 1;
      arrayOfByte4[i1] = ((byte)(this.KeepAlive / 256));
      byte[] arrayOfByte5 = this.message;
      int i3 = i2 + 1;
      arrayOfByte5[i2] = ((byte)(this.KeepAlive % 256));
      byte[] arrayOfByte6 = MqttUtils.StringToUTF(this.ClientId);
      System.arraycopy(arrayOfByte6, 0, this.message, i3, arrayOfByte6.length);
      int i4 = i3 + arrayOfByte6.length;
      if (this.Will)
      {
        byte[] arrayOfByte7 = MqttUtils.StringToUTF(this.WillTopic);
        byte[] arrayOfByte8 = MqttUtils.StringToUTF(this.WillMessage);
        this.message = MqttUtils.concatArray(MqttUtils.concatArray(this.message, 0, i4, arrayOfByte7, 0, arrayOfByte7.length), arrayOfByte8);
        i4 += arrayOfByte7.length + arrayOfByte8.length;
      }
      this.message = MqttUtils.SliceByteArray(this.message, 0, i4);
      createMsgLength();
      return this.message;
      i = 0;
      break;
      m = 0;
      break label84;
      i5 = 0;
      break label102;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttConnect
 * JD-Core Version:    0.6.2
 */