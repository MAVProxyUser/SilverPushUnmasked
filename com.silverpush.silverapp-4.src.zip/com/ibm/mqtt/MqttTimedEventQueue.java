package com.ibm.mqtt;

import java.io.PrintStream;

public class MqttTimedEventQueue extends Thread
{
  private boolean canDeliverEvents = false;
  private MqttTimedEvent[] m_array;
  private int m_head = 0;
  private int m_tail = 0;
  private boolean running = false;
  private MqttBaseClient session = null;
  private boolean stopping = false;

  public MqttTimedEventQueue(int paramInt, MqttBaseClient paramMqttBaseClient)
  {
    if (paramInt < 1)
      paramInt = 4;
    this.m_array = new MqttTimedEvent[paramInt];
    this.session = paramMqttBaseClient;
  }

  private int adjust(int paramInt)
  {
    int i = this.m_array.length;
    if (paramInt < i)
      return paramInt;
    return paramInt - i;
  }

  private void expand_array()
  {
    int i = this.m_array.length;
    MqttTimedEvent[] arrayOfMqttTimedEvent = new MqttTimedEvent[i * 2];
    System.arraycopy(this.m_array, this.m_head, arrayOfMqttTimedEvent, this.m_head, i - this.m_head);
    System.arraycopy(this.m_array, 0, arrayOfMqttTimedEvent, i, this.m_tail);
    this.m_tail = (i + this.m_tail);
    this.m_array = arrayOfMqttTimedEvent;
  }

  public void canDeliverEvents(boolean paramBoolean)
  {
    try
    {
      this.canDeliverEvents = paramBoolean;
      notifyAll();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  // ERROR //
  public void close()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield 24	com/ibm/mqtt/MqttTimedEventQueue:running	Z
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield 26	com/ibm/mqtt/MqttTimedEventQueue:stopping	Z
    //   12: aload_0
    //   13: invokevirtual 51	java/lang/Object:notifyAll	()V
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_0
    //   19: invokevirtual 57	com/ibm/mqtt/MqttTimedEventQueue:join	()V
    //   22: return
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    //   28: astore_2
    //   29: return
    //
    // Exception table:
    //   from	to	target	type
    //   2	18	23	finally
    //   24	26	23	finally
    //   18	22	28	java/lang/InterruptedException
  }

  public void enqueue(MqttTimedEvent paramMqttTimedEvent)
    throws MqttException
  {
    while (true)
    {
      int j;
      try
      {
        long l = paramMqttTimedEvent.getTime();
        if ((this.m_head == this.m_tail) || (l < this.m_array[this.m_head].getTime()))
        {
          int i = -1 + this.m_head;
          this.m_head = i;
          if (i < 0)
            this.m_head = (-1 + this.m_array.length);
          this.m_array[this.m_head] = paramMqttTimedEvent;
          if (this.m_head == this.m_tail)
            expand_array();
          notifyAll();
          return;
        }
        if (this.m_tail < this.m_head)
        {
          j = this.m_tail + this.m_array.length;
          break label323;
          if (k < this.m_head)
            break label247;
          if (l < this.m_array[adjust(k)].getTime())
          {
            this.m_array[adjust(k + 1)] = this.m_array[adjust(k)];
            k--;
            continue;
          }
        }
        else
        {
          j = this.m_tail;
          break label323;
        }
        this.m_array[adjust(k + 1)] = paramMqttTimedEvent;
        this.m_tail = adjust(1 + this.m_tail);
        if (this.m_head != this.m_tail)
          continue;
        expand_array();
        continue;
      }
      finally
      {
      }
      label247: String str1 = "MqttTimedEventQueue enqueue out of bounds" + "\nAdding event:" + paramMqttTimedEvent.toString();
      String str2 = str1 + "\nEvent queue:" + toString();
      System.out.println(str2);
      throw new MqttException(str2);
      label323: int k = j - 1;
    }
  }

  public boolean isEmpty()
  {
    try
    {
      int i = this.m_head;
      int j = this.m_tail;
      if (i == j)
      {
        bool = true;
        return bool;
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  public void resetTimedEventQueue()
  {
    int i = 0;
    try
    {
      this.m_head = 0;
      this.m_tail = 0;
      while (i < this.m_array.length)
      {
        this.m_array[i] = null;
        i++;
      }
      return;
    }
    finally
    {
    }
  }

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 26	com/ibm/mqtt/MqttTimedEventQueue:stopping	Z
    //   4: ifne +8 -> 12
    //   7: aload_0
    //   8: iconst_1
    //   9: putfield 24	com/ibm/mqtt/MqttTimedEventQueue:running	Z
    //   12: aconst_null
    //   13: astore_1
    //   14: aload_0
    //   15: getfield 24	com/ibm/mqtt/MqttTimedEventQueue:running	Z
    //   18: ifeq +295 -> 313
    //   21: aload_0
    //   22: getfield 26	com/ibm/mqtt/MqttTimedEventQueue:stopping	Z
    //   25: ifne +288 -> 313
    //   28: aload_0
    //   29: monitorenter
    //   30: aload_0
    //   31: getfield 26	com/ibm/mqtt/MqttTimedEventQueue:stopping	Z
    //   34: ifeq +6 -> 40
    //   37: aload_0
    //   38: monitorexit
    //   39: return
    //   40: aload_0
    //   41: getfield 24	com/ibm/mqtt/MqttTimedEventQueue:running	Z
    //   44: ifeq +64 -> 108
    //   47: aload_0
    //   48: getfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   51: aload_0
    //   52: getfield 32	com/ibm/mqtt/MqttTimedEventQueue:m_tail	I
    //   55: if_icmpeq +10 -> 65
    //   58: aload_0
    //   59: getfield 28	com/ibm/mqtt/MqttTimedEventQueue:canDeliverEvents	Z
    //   62: ifne +46 -> 108
    //   65: aload_0
    //   66: invokevirtual 111	java/lang/Object:wait	()V
    //   69: goto -29 -> 40
    //   72: astore 9
    //   74: aload_0
    //   75: monitorexit
    //   76: aload 9
    //   78: athrow
    //   79: astore 5
    //   81: aload_1
    //   82: astore_3
    //   83: aload_3
    //   84: ifnull +19 -> 103
    //   87: aload_3
    //   88: invokeinterface 114 1 0
    //   93: ifeq +8 -> 101
    //   96: aload_0
    //   97: aload_3
    //   98: invokevirtual 116	com/ibm/mqtt/MqttTimedEventQueue:enqueue	(Lcom/ibm/mqtt/MqttTimedEvent;)V
    //   101: aconst_null
    //   102: astore_3
    //   103: aload_3
    //   104: astore_1
    //   105: goto -91 -> 14
    //   108: aload_0
    //   109: getfield 24	com/ibm/mqtt/MqttTimedEventQueue:running	Z
    //   112: ifeq +48 -> 160
    //   115: invokestatic 119	java/lang/System:currentTimeMillis	()J
    //   118: lstore 10
    //   120: aload_0
    //   121: getfield 36	com/ibm/mqtt/MqttTimedEventQueue:m_array	[Lcom/ibm/mqtt/MqttTimedEvent;
    //   124: aload_0
    //   125: getfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   128: aaload
    //   129: invokeinterface 65 1 0
    //   134: lstore 12
    //   136: lload 10
    //   138: lload 12
    //   140: lcmp
    //   141: ifge +26 -> 167
    //   144: aload_0
    //   145: getfield 24	com/ibm/mqtt/MqttTimedEventQueue:running	Z
    //   148: ifeq +19 -> 167
    //   151: aload_0
    //   152: lload 12
    //   154: lload 10
    //   156: lsub
    //   157: invokevirtual 122	java/lang/Object:wait	(J)V
    //   160: aload_0
    //   161: monitorexit
    //   162: aload_1
    //   163: astore_3
    //   164: goto -81 -> 83
    //   167: aload_0
    //   168: getfield 28	com/ibm/mqtt/MqttTimedEventQueue:canDeliverEvents	Z
    //   171: ifne +28 -> 199
    //   174: aload_0
    //   175: getfield 22	com/ibm/mqtt/MqttTimedEventQueue:session	Lcom/ibm/mqtt/MqttBaseClient;
    //   178: aload_0
    //   179: getfield 36	com/ibm/mqtt/MqttTimedEventQueue:m_array	[Lcom/ibm/mqtt/MqttTimedEvent;
    //   182: aload_0
    //   183: getfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   186: aaload
    //   187: checkcast 124	com/ibm/mqtt/MqttRetry
    //   190: invokevirtual 128	com/ibm/mqtt/MqttRetry:getMsgId	()I
    //   193: invokevirtual 134	com/ibm/mqtt/MqttBaseClient:outstanding	(I)Z
    //   196: ifne -36 -> 160
    //   199: aload_0
    //   200: getfield 36	com/ibm/mqtt/MqttTimedEventQueue:m_array	[Lcom/ibm/mqtt/MqttTimedEvent;
    //   203: aload_0
    //   204: getfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   207: aaload
    //   208: astore_1
    //   209: aload_0
    //   210: getfield 36	com/ibm/mqtt/MqttTimedEventQueue:m_array	[Lcom/ibm/mqtt/MqttTimedEvent;
    //   213: astore 14
    //   215: aload_0
    //   216: getfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   219: istore 15
    //   221: aload_0
    //   222: iload 15
    //   224: iconst_1
    //   225: iadd
    //   226: putfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   229: aload 14
    //   231: iload 15
    //   233: aconst_null
    //   234: aastore
    //   235: aload_0
    //   236: getfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   239: aload_0
    //   240: getfield 36	com/ibm/mqtt/MqttTimedEventQueue:m_array	[Lcom/ibm/mqtt/MqttTimedEvent;
    //   243: arraylength
    //   244: if_icmpne -84 -> 160
    //   247: aload_0
    //   248: iconst_0
    //   249: putfield 30	com/ibm/mqtt/MqttTimedEventQueue:m_head	I
    //   252: goto -92 -> 160
    //   255: astore 6
    //   257: iconst_0
    //   258: istore 7
    //   260: iload 7
    //   262: ifne -161 -> 101
    //   265: aload_0
    //   266: aload_3
    //   267: invokevirtual 116	com/ibm/mqtt/MqttTimedEventQueue:enqueue	(Lcom/ibm/mqtt/MqttTimedEvent;)V
    //   270: iconst_1
    //   271: istore 7
    //   273: goto -13 -> 260
    //   276: astore_2
    //   277: aload_1
    //   278: astore_3
    //   279: aload_2
    //   280: astore 4
    //   282: aload_0
    //   283: getfield 22	com/ibm/mqtt/MqttTimedEventQueue:session	Lcom/ibm/mqtt/MqttBaseClient;
    //   286: ifnull +12 -> 298
    //   289: aload_0
    //   290: getfield 22	com/ibm/mqtt/MqttTimedEventQueue:session	Lcom/ibm/mqtt/MqttBaseClient;
    //   293: aload 4
    //   295: invokevirtual 138	com/ibm/mqtt/MqttBaseClient:setRegisteredThrowable	(Ljava/lang/Throwable;)V
    //   298: aload_3
    //   299: astore_1
    //   300: goto -286 -> 14
    //   303: astore 8
    //   305: goto -45 -> 260
    //   308: astore 4
    //   310: goto -28 -> 282
    //   313: return
    //
    // Exception table:
    //   from	to	target	type
    //   30	39	72	finally
    //   40	65	72	finally
    //   65	69	72	finally
    //   74	76	72	finally
    //   108	136	72	finally
    //   144	160	72	finally
    //   160	162	72	finally
    //   167	199	72	finally
    //   199	252	72	finally
    //   28	30	79	java/lang/InterruptedException
    //   76	79	79	java/lang/InterruptedException
    //   87	101	255	java/lang/Exception
    //   28	30	276	java/lang/Throwable
    //   76	79	276	java/lang/Throwable
    //   265	270	303	com/ibm/mqtt/MqttException
    //   87	101	308	java/lang/Throwable
    //   265	270	308	java/lang/Throwable
  }

  public String toString()
  {
    while (true)
    {
      try
      {
        int i = this.m_head;
        int j;
        if (this.m_head <= this.m_tail)
        {
          j = this.m_tail;
          break label239;
          if (i < j)
          {
            StringBuffer localStringBuffer1 = new StringBuffer().append(str1).append(" ");
            MqttTimedEvent[] arrayOfMqttTimedEvent1 = this.m_array;
            int k = i + 1;
            str1 = arrayOfMqttTimedEvent1[i].toString();
            i = k;
            continue;
          }
        }
        else
        {
          j = this.m_array.length;
          break label239;
        }
        int m = this.m_array.length;
        int n = 0;
        if (j == m)
          if (n < this.m_tail)
          {
            StringBuffer localStringBuffer2 = new StringBuffer().append(str1).append(" ");
            MqttTimedEvent[] arrayOfMqttTimedEvent2 = this.m_array;
            int i1 = n + 1;
            str1 = arrayOfMqttTimedEvent2[n].toString();
            n = i1;
            continue;
          }
        if (this.m_head != this.m_tail)
          str1 = str1 + " ";
        String str2 = str1 + "]";
        return str2;
      }
      finally
      {
      }
      label239: String str1 = "[";
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttTimedEventQueue
 * JD-Core Version:    0.6.2
 */