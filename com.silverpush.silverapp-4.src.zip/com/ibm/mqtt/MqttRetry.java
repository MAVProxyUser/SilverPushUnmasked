package com.ibm.mqtt;

public class MqttRetry
  implements MqttTimedEvent
{
  protected long expires;
  private MqttPacket packet;
  private MqttBaseClient sessionRef;

  public MqttRetry(MqttBaseClient paramMqttBaseClient, MqttPacket paramMqttPacket, long paramLong)
  {
    this.packet = paramMqttPacket;
    this.sessionRef = paramMqttBaseClient;
    this.expires = (paramLong + System.currentTimeMillis());
  }

  public int getMsgId()
  {
    return this.packet.getMsgId();
  }

  public int getMsgType()
  {
    return this.packet.getMsgType();
  }

  public int getQoS()
  {
    return this.packet.getQos();
  }

  public long getTime()
  {
    return this.expires;
  }

  public boolean notifyEvent()
    throws Exception
  {
    if (outstanding())
    {
      if (this.sessionRef.isConnected())
      {
        this.sessionRef.writePacket(this.packet);
        MQeTrace.trace(this, (short)-30031, 2097152L, Mqtt.msgTypes[this.packet.getMsgType()], new Integer(this.packet.getMsgId()));
      }
      if (this.packet.getMsgType() == 12);
      for (this.expires = (System.currentTimeMillis() + 1000 * this.sessionRef.getKeepAlivePeriod()); ; this.expires = (System.currentTimeMillis() + 1000 * this.sessionRef.getRetry()))
        return true;
    }
    return false;
  }

  public boolean outstanding()
  {
    try
    {
      boolean bool = this.sessionRef.outstanding(this.packet.getMsgId());
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected void setMessage(MqttPacket paramMqttPacket)
  {
    this.packet = paramMqttPacket;
  }

  public String toString()
  {
    return "[" + Mqtt.msgTypes[this.packet.getMsgType()] + " MsgId:" + this.packet.getMsgId() + " Expires:" + getTime() + "]";
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttRetry
 * JD-Core Version:    0.6.2
 */