package com.ibm.mqtt.j2se;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class MqttJava14NetSocket extends Socket
{
  public MqttJava14NetSocket(String paramString, int paramInt1, int paramInt2)
    throws IOException
  {
    connect(new InetSocketAddress(paramString, paramInt1), paramInt2);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.j2se.MqttJava14NetSocket
 * JD-Core Version:    0.6.2
 */