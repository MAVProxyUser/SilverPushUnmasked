package com.ibm.mqtt.j2se;

import com.ibm.mqtt.MqttAdapter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;

public class MqttJavaNetSocket
  implements MqttAdapter
{
  static Class class$java$net$Socket;
  private Socket s = null;
  private boolean useShutdownMethods = false;

  public MqttJavaNetSocket()
  {
    try
    {
      Class localClass;
      if (class$java$net$Socket == null)
      {
        localClass = class$("java.net.Socket");
        class$java$net$Socket = localClass;
      }
      while (true)
      {
        localClass.getMethod("shutdownInput", null);
        this.useShutdownMethods = true;
        return;
        localClass = class$java$net$Socket;
      }
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
    }
  }

  static Class class$(String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      return localClass;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
    }
  }

  public void close()
    throws IOException
  {
    if (this.s != null)
      this.s.close();
  }

  public void closeInputStream()
    throws IOException
  {
    if (this.useShutdownMethods)
    {
      this.s.shutdownInput();
      return;
    }
    this.s.getInputStream().close();
  }

  public void closeOutputStream()
    throws IOException
  {
    try
    {
      this.s.setSoLinger(true, 10);
      label10: if (this.useShutdownMethods)
      {
        this.s.shutdownOutput();
        return;
      }
      this.s.getOutputStream().close();
      return;
    }
    catch (SocketException localSocketException)
    {
      break label10;
    }
  }

  public InputStream getInputStream()
    throws IOException
  {
    if (this.s == null)
      return null;
    return this.s.getInputStream();
  }

  public OutputStream getOutputStream()
    throws IOException
  {
    if (this.s == null)
      return null;
    return this.s.getOutputStream();
  }

  public void setConnection(String paramString, int paramInt)
    throws IOException
  {
    int i = paramString.lastIndexOf(':');
    if (i < 6)
      i = paramString.indexOf('@');
    try
    {
      this.s = new MqttJava14NetSocket(paramString.substring(6, i), Integer.parseInt(paramString.substring(i + 1)), paramInt * 1000);
      if (paramInt > 0)
      {
        int j = 1000 * (paramInt + 15);
        this.s.setSoTimeout(j);
      }
      return;
    }
    catch (NoClassDefFoundError localNoClassDefFoundError)
    {
      while (true)
        this.s = new Socket(paramString.substring(6, i), Integer.parseInt(paramString.substring(i + 1)));
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.j2se.MqttJavaNetSocket
 * JD-Core Version:    0.6.2
 */