package com.ibm.mqtt;

import java.util.Vector;

public class MqttUnsubscribe extends MqttPacket
{
  public String[] topics;

  public MqttUnsubscribe()
  {
    setMsgType((short)10);
  }

  public MqttUnsubscribe(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)10);
    setMsgId(MqttUtils.toShort(paramArrayOfByte, paramInt));
    Vector localVector = MqttUtils.UTFToStrings(paramArrayOfByte, paramInt + 2);
    int i = localVector.size();
    this.topics = new String[i];
    for (int j = 0; j < i; j++)
      this.topics[j] = localVector.elementAt(j).toString();
  }

  private void uncompressTopic()
  {
  }

  public void compressTopic()
  {
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    int i = 0;
    this.message = new byte[3];
    this.message[0] = super.toBytes()[0];
    int j = getMsgId();
    this.message[1] = ((byte)(j / 256));
    this.message[2] = ((byte)(j % 256));
    while (i < this.topics.length)
    {
      byte[] arrayOfByte = MqttUtils.StringToUTF(this.topics[i]);
      this.message = MqttUtils.concatArray(this.message, arrayOfByte);
      i++;
    }
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttUnsubscribe
 * JD-Core Version:    0.6.2
 */