package com.ibm.mqtt;

public abstract interface MqttTimedEvent
{
  public abstract long getTime();

  public abstract boolean notifyEvent()
    throws Exception;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttTimedEvent
 * JD-Core Version:    0.6.2
 */