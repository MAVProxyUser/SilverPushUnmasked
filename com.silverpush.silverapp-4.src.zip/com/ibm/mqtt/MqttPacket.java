package com.ibm.mqtt;

public abstract class MqttPacket
{
  public static final int MAX_CLIENT_ID_LEN = 23;
  public static final int MAX_MSGID = 65535;
  private boolean dup;
  protected byte[] message;
  private int msgId = 0;
  private int msgLength;
  private short msgType;
  private byte[] payload = null;
  private int qos;
  private boolean retain;

  public MqttPacket()
  {
  }

  public MqttPacket(byte[] paramArrayOfByte)
  {
    byte b = paramArrayOfByte[0];
    this.msgType = getMsgType(b);
    boolean bool2;
    if ((b & 0x1) != 0)
    {
      bool2 = bool1;
      this.retain = bool2;
      if ((0x1 & b >>> 3) == 0)
        break label72;
    }
    while (true)
    {
      this.dup = bool1;
      this.qos = (0x3 & b >>> 1);
      return;
      bool2 = false;
      break;
      label72: bool1 = false;
    }
  }

  protected static short getMsgType(byte paramByte)
  {
    return (short)(0xF & paramByte >>> 4);
  }

  protected void createMsgLength()
  {
    int i = -1 + this.message.length;
    if (this.payload != null)
      i += this.payload.length;
    this.msgLength = i;
    byte[] arrayOfByte1 = new byte[4];
    int j = i;
    int k = 0;
    while (true)
    {
      int m = j % 128;
      int n = j / 128;
      if (n > 0)
        m |= 128;
      int i1 = k + 1;
      arrayOfByte1[k] = ((byte)m);
      if (n <= 0)
      {
        byte[] arrayOfByte2 = new byte[i1 + this.message.length];
        arrayOfByte2[0] = this.message[0];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 1, i1);
        System.arraycopy(this.message, 1, arrayOfByte2, i1 + 1, -1 + this.message.length);
        this.message = arrayOfByte2;
        return;
      }
      k = i1;
      j = n;
    }
  }

  public byte[] getMessage()
  {
    return this.message;
  }

  public int getMsgId()
  {
    return this.msgId;
  }

  public int getMsgLength()
  {
    return this.msgLength;
  }

  public short getMsgType()
  {
    return this.msgType;
  }

  public byte[] getPayload()
  {
    return this.payload;
  }

  public int getQos()
  {
    return this.qos;
  }

  public boolean isDup()
  {
    return this.dup;
  }

  public boolean isRetain()
  {
    return this.retain;
  }

  public abstract void process(MqttProcessor paramMqttProcessor);

  public void setDup(boolean paramBoolean)
  {
    this.dup = paramBoolean;
  }

  public void setMessage(byte[] paramArrayOfByte)
  {
    this.message = paramArrayOfByte;
  }

  public void setMsgId(int paramInt)
  {
    this.msgId = paramInt;
  }

  public void setMsgLength(int paramInt)
  {
    this.msgLength = paramInt;
  }

  public void setMsgType(short paramShort)
  {
    this.msgType = paramShort;
  }

  public void setPayload(byte[] paramArrayOfByte)
  {
    this.payload = paramArrayOfByte;
  }

  public void setQos(int paramInt)
  {
    this.qos = paramInt;
  }

  public void setRetain(boolean paramBoolean)
  {
    this.retain = paramBoolean;
  }

  public byte[] toBytes()
  {
    int i = 1;
    byte[] arrayOfByte = new byte[i];
    arrayOfByte[0] = ((byte)(0xF0 & this.msgType << 4));
    int j;
    int k;
    label43: int n;
    label61: int i2;
    label80: int i3;
    int i4;
    label115: int i5;
    if (this.msgType == 8)
    {
      j = i;
      if (this.msgType != 9)
        break label149;
      k = i;
      int m = k | j;
      if (this.msgType != 10)
        break label155;
      n = i;
      int i1 = m | n;
      if (this.msgType != 11)
        break label161;
      i2 = i;
      if ((i2 | i1) != 0)
        this.qos = i;
      i3 = (byte)((0x3 & this.qos) << 1);
      if (!this.dup)
        break label167;
      i4 = 8;
      i5 = i4;
      if (!this.retain)
        break label173;
    }
    while (true)
    {
      arrayOfByte[0] = ((byte)(i5 | ((byte)i | (i3 | arrayOfByte[0]))));
      return arrayOfByte;
      j = 0;
      break;
      label149: k = 0;
      break label43;
      label155: n = 0;
      break label61;
      label161: i2 = 0;
      break label80;
      label167: i4 = 0;
      break label115;
      label173: i = 0;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPacket
 * JD-Core Version:    0.6.2
 */