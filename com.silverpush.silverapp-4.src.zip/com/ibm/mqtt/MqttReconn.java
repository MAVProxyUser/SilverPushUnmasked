package com.ibm.mqtt;

public class MqttReconn extends Thread
{
  private MqttBaseClient client = null;

  public MqttReconn(MqttBaseClient paramMqttBaseClient)
  {
    this.client = paramMqttBaseClient;
  }

  public void run()
  {
    try
    {
      this.client.connectionLost();
      this.client.setConnectionLost(false);
      return;
    }
    catch (Throwable localThrowable)
    {
      MqttException localMqttException = new MqttException("ConnectionLost exception caught");
      localMqttException.initCause(localThrowable);
      this.client.setRegisteredThrowable(localMqttException);
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttReconn
 * JD-Core Version:    0.6.2
 */