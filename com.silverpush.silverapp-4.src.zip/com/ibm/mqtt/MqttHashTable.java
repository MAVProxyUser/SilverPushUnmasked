package com.ibm.mqtt;

import java.io.PrintStream;
import java.util.Enumeration;

public class MqttHashTable
{
  private static final int INITIAL_CAPACITY = 101;
  private static final int LOAD_FACTOR_DENOMINATOR = 4;
  private static final int LOAD_FACTOR_NUMERATOR = 3;
  private static int m_init_capacity;
  public MqttListItem[] hashTable;
  public int m_capacity;
  private int m_ceiling;
  private MqttListItem recycle_bin;
  private int recycle_length = 0;
  private int size = 0;

  public MqttHashTable()
  {
    this(101);
  }

  public MqttHashTable(int paramInt)
  {
    int i = findPower(paramInt);
    this.m_capacity = i;
    m_init_capacity = i;
    this.m_ceiling = (3 * this.m_capacity / 4);
    this.hashTable = new MqttListItem[this.m_capacity];
  }

  private int findPower(int paramInt)
  {
    int i = 2;
    do
      i *= 2;
    while (i < paramInt);
    return i;
  }

  private MqttListItem recycleCreate(long paramLong, MqttListItem paramMqttListItem, Object paramObject)
  {
    if (this.recycle_bin != null)
    {
      MqttListItem localMqttListItem = this.recycle_bin;
      this.recycle_bin = this.recycle_bin.next;
      this.recycle_length = (-1 + this.recycle_length);
      localMqttListItem.key = paramLong;
      localMqttListItem.next = paramMqttListItem;
      localMqttListItem.data = paramObject;
      return localMqttListItem;
    }
    return new MqttListItem(paramLong, paramMqttListItem, paramObject);
  }

  private void rehash(int paramInt)
  {
    MqttListItem[] arrayOfMqttListItem1 = this.hashTable;
    MqttListItem[] arrayOfMqttListItem2 = new MqttListItem[this.m_capacity];
    this.hashTable = arrayOfMqttListItem2;
    for (int i = 0; i < paramInt; i++)
    {
      MqttListItem localMqttListItem;
      for (Object localObject = arrayOfMqttListItem1[i]; localObject != null; localObject = localMqttListItem)
      {
        localMqttListItem = ((MqttListItem)localObject).next;
        long l = ((MqttListItem)localObject).key;
        int j = (int)((l ^ l >>> 32) & -1 + this.m_capacity);
        ((MqttListItem)localObject).next = arrayOfMqttListItem2[j];
        arrayOfMqttListItem2[j] = localObject;
      }
    }
  }

  public void clear()
  {
    for (int i = 0; i < this.m_capacity; i++)
      this.hashTable[i] = null;
    this.size = 0;
  }

  public boolean contains(Object paramObject)
  {
    for (int i = 0; ; i++)
    {
      int j = this.m_capacity;
      boolean bool = false;
      if (i < j);
      for (MqttListItem localMqttListItem = this.hashTable[i]; localMqttListItem != null; localMqttListItem = localMqttListItem.next)
        if (localMqttListItem.data.equals(paramObject))
        {
          bool = true;
          return bool;
        }
    }
  }

  public boolean containsKey(long paramLong)
  {
    return get(paramLong) != null;
  }

  public Enumeration elements()
  {
    return new MqttEnumList(this, false);
  }

  public Object get(long paramLong)
  {
    int i = (int)((paramLong ^ paramLong >>> 32) & -1 + this.m_capacity);
    this.hashTable[i];
    for (MqttListItem localMqttListItem = this.hashTable[i]; localMqttListItem != null; localMqttListItem = localMqttListItem.next)
      if (localMqttListItem.keysMatch(paramLong))
        return localMqttListItem.data;
    return null;
  }

  public boolean isEmpty()
  {
    return this.size == 0;
  }

  public Enumeration keys()
  {
    return new MqttEnumList(this, true);
  }

  public Object put(long paramLong, Object paramObject)
  {
    if (this.size > this.m_ceiling)
    {
      int j = this.m_capacity;
      this.m_capacity <<= 1;
      this.m_ceiling = (3 * this.m_capacity / 4);
      rehash(j);
      return put(paramLong, paramObject);
    }
    int i = (int)((paramLong ^ paramLong >>> 32) & -1 + this.m_capacity);
    MqttListItem localMqttListItem1 = this.hashTable[i];
    if (localMqttListItem1 == null)
    {
      this.hashTable[i] = recycleCreate(paramLong, null, paramObject);
      this.size = (1 + this.size);
      return null;
    }
    for (MqttListItem localMqttListItem2 = localMqttListItem1; localMqttListItem2 != null; localMqttListItem2 = localMqttListItem2.next)
      if (localMqttListItem2.keysMatch(paramLong))
      {
        Object localObject = localMqttListItem2.data;
        localMqttListItem2.data = paramObject;
        return localObject;
      }
    this.hashTable[i] = recycleCreate(paramLong, localMqttListItem1, paramObject);
    this.size = (1 + this.size);
    return null;
  }

  public Object remove(long paramLong)
  {
    Object localObject3;
    if ((this.size < this.m_ceiling / 4) && (this.size >= m_init_capacity << 1))
    {
      int j = this.m_capacity;
      this.m_capacity >>= 1;
      this.m_ceiling = (3 * this.m_capacity / 4);
      rehash(j);
      localObject3 = remove(paramLong);
      return localObject3;
    }
    int i = (int)((paramLong ^ paramLong >>> 32) & -1 + this.m_capacity);
    Object localObject1 = this.hashTable[i];
    Object localObject2 = null;
    while (true)
    {
      localObject3 = null;
      if (localObject1 == null)
        break;
      if (((MqttListItem)localObject1).keysMatch(paramLong))
      {
        if (localObject2 == null)
          this.hashTable[i] = ((MqttListItem)localObject1).next;
        while (true)
        {
          this.size = (-1 + this.size);
          if (this.recycle_length < this.size / 8)
          {
            ((MqttListItem)localObject1).next = this.recycle_bin;
            this.recycle_bin = ((MqttListItem)localObject1);
            this.recycle_length = (1 + this.recycle_length);
          }
          return ((MqttListItem)localObject1).data;
          localObject2.next = ((MqttListItem)localObject1).next;
        }
      }
      MqttListItem localMqttListItem = ((MqttListItem)localObject1).next;
      localObject2 = localObject1;
      localObject1 = localMqttListItem;
    }
  }

  public int size()
  {
    return this.size;
  }

  public final void view()
  {
    for (int i = 0; i < this.m_capacity; i++)
    {
      System.out.print("\nBucket " + i + ":");
      for (MqttListItem localMqttListItem = this.hashTable[i]; localMqttListItem != null; localMqttListItem = localMqttListItem.next)
        System.out.print(" " + localMqttListItem.data.toString());
    }
    System.out.println("\nSize = " + this.size + "\n");
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttHashTable
 * JD-Core Version:    0.6.2
 */