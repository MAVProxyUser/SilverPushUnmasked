package com.ibm.mqtt;

public final class MqttListItem
{
  public Object data;
  public long key;
  public MqttListItem next;

  public MqttListItem(long paramLong, MqttListItem paramMqttListItem, Object paramObject)
  {
    this.data = paramObject;
    this.next = paramMqttListItem;
    this.key = paramLong;
  }

  public boolean isEnd()
  {
    return this.next == null;
  }

  public boolean keysMatch(long paramLong)
  {
    return this.key == paramLong;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttListItem
 * JD-Core Version:    0.6.2
 */