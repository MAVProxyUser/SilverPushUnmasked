package com.ibm.mqtt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Mqtt
  implements MqttProcessor
{
  public static final short CONNACK = 2;
  public static final short CONNECT = 1;
  public static final short DISCONNECT = 14;
  public static final short PINGREQ = 12;
  public static final short PINGRESP = 13;
  public static final short PUBACK = 4;
  public static final short PUBCOMP = 7;
  public static final short PUBLISH = 3;
  public static final short PUBREC = 5;
  public static final short PUBREL = 6;
  public static final short SUBACK = 9;
  public static final short SUBSCRIBE = 8;
  public static final short UNSUBACK = 11;
  public static final short UNSUBSCRIBE = 10;
  public static final String[] msgTypes = { null, "CONNECT", "CONNACK", "PUBLISH", "PUBACK", "PUBREC", "PUBREL", "PUBCOMP", "SUBSCRIBE", "SUBACK", "UNSUBSCRIBE", "UNSUBACK", "PINGREQ", "PINGRESP", "DISCONNECT" };
  private boolean connected = false;
  protected String connection;
  private boolean connectionLost = false;
  private int curMsgId = 0;
  private boolean haveWill = false;
  private boolean isSocketConnected = false;
  private int keepAlivePeriod;
  private Hashtable outMsgIdsAllocated = new Hashtable();
  protected MqttException registeredException = null;
  private MqttAdapter socket = null;
  private Class socketClass = null;
  private Object streamReadLock = new Object();
  private Object streamWriteLock = new Object();
  private DataInputStream stream_in = null;
  private DataOutputStream stream_out = null;
  private boolean topicNameCompression = false;

  private MqttPacket decodePacket(byte[] paramArrayOfByte, int paramInt, short paramShort)
    throws MqttException
  {
    boolean bool = isSocketConnected();
    MqttPingreq localMqttPingreq = null;
    if (bool)
      localMqttPingreq = null;
    switch (paramShort)
    {
    default:
      throw new MqttException("Mqtt: Unknown message type: " + paramShort);
    case 12:
      localMqttPingreq = new MqttPingreq(paramArrayOfByte, paramInt);
    case 1:
    case 14:
      return localMqttPingreq;
    case 13:
      return new MqttPingresp(paramArrayOfByte, paramInt);
    case 3:
      return new MqttPublish(paramArrayOfByte, paramInt);
    case 4:
      return new MqttPuback(paramArrayOfByte, paramInt);
    case 5:
      return new MqttPubrec(paramArrayOfByte, paramInt);
    case 6:
      return new MqttPubrel(paramArrayOfByte, paramInt);
    case 7:
      return new MqttPubcomp(paramArrayOfByte, paramInt);
    case 8:
      return new MqttSubscribe(paramArrayOfByte, paramInt);
    case 9:
      return new MqttSuback(paramArrayOfByte, paramInt);
    case 10:
      return new MqttUnsubscribe(paramArrayOfByte, paramInt);
    case 11:
      return new MqttUnsuback(paramArrayOfByte, paramInt);
    case 2:
    }
    return new MqttConnack(paramArrayOfByte, paramInt);
  }

  private void setSocketState(boolean paramBoolean)
  {
    synchronized (this.streamWriteLock)
    {
      this.isSocketConnected = paramBoolean;
      return;
    }
  }

  protected final MqttPublish genPublishPacket(int paramInt1, int paramInt2, String paramString, byte[] paramArrayOfByte, boolean paramBoolean1, boolean paramBoolean2)
  {
    MqttPublish localMqttPublish = new MqttPublish();
    localMqttPublish.setMsgId(paramInt1);
    localMqttPublish.setQos(paramInt2);
    localMqttPublish.topicName = paramString;
    localMqttPublish.setPayload(paramArrayOfByte);
    localMqttPublish.setDup(paramBoolean2);
    localMqttPublish.setRetain(paramBoolean1);
    if (this.topicNameCompression)
      localMqttPublish.compressTopic();
    return localMqttPublish;
  }

  protected int getKeepAlivePeriod()
  {
    return this.keepAlivePeriod;
  }

  protected boolean hasKeepAlive()
  {
    return this.keepAlivePeriod > 0;
  }

  protected boolean hasWill()
  {
    return this.haveWill;
  }

  protected void initialise(String paramString, Class paramClass)
  {
    this.connection = paramString;
    this.socketClass = paramClass;
  }

  protected void initialiseOutMsgIds(Vector paramVector)
  {
    this.outMsgIdsAllocated.clear();
    this.curMsgId = 1;
    if (paramVector != null)
    {
      Enumeration localEnumeration = paramVector.elements();
      while (localEnumeration.hasMoreElements())
      {
        Integer localInteger = (Integer)localEnumeration.nextElement();
        this.outMsgIdsAllocated.put(localInteger, localInteger);
      }
    }
  }

  public boolean isConnected()
  {
    try
    {
      boolean bool = this.connected;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected boolean isConnectionLost()
  {
    try
    {
      boolean bool = this.connectionLost;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected boolean isSocketConnected()
  {
    synchronized (this.streamWriteLock)
    {
      boolean bool = this.isSocketConnected;
      return bool;
    }
  }

  protected int nextMsgId()
    throws MqttException
  {
    if (this.outMsgIdsAllocated.size() == 65535)
      throw new MqttException("All available msgIds in use:65535");
    int i = 0;
    if (i == 0)
    {
      if (this.curMsgId < 65535);
      for (this.curMsgId = (1 + this.curMsgId); ; this.curMsgId = 1)
      {
        Integer localInteger = new Integer(this.curMsgId);
        if (this.outMsgIdsAllocated.contains(localInteger))
          break;
        this.outMsgIdsAllocated.put(localInteger, localInteger);
        i = 1;
        break;
      }
    }
    return this.curMsgId;
  }

  protected void pingOut()
    throws MqttException
  {
    writePacket(new MqttPingreq());
  }

  protected void process()
    throws Exception
  {
    MqttPacket localMqttPacket = readPacket();
    if (localMqttPacket != null)
    {
      localMqttPacket.process(this);
      return;
    }
    System.out.println("Mqtt: Read a null packet from the socket");
  }

  public void process(MqttConnack paramMqttConnack)
  {
    if (paramMqttConnack.returnCode == 0)
    {
      this.topicNameCompression = paramMqttConnack.topicNameCompression;
      setConnectionState(true);
    }
    while (true)
    {
      if (paramMqttConnack.returnCode != 0)
        tcpipDisconnect(false);
      return;
      if (paramMqttConnack.returnCode == 1)
        setConnectionState(false);
      else if (paramMqttConnack.returnCode == 2)
        setConnectionState(false);
      else if (paramMqttConnack.returnCode == 3)
        setConnectionState(false);
    }
  }

  public void process(MqttConnect paramMqttConnect)
  {
  }

  public void process(MqttDisconnect paramMqttDisconnect)
  {
  }

  public void process(MqttPingreq paramMqttPingreq)
  {
    try
    {
      writePacket(new MqttPingresp());
      return;
    }
    catch (Exception localException)
    {
    }
  }

  public void process(MqttPingresp paramMqttPingresp)
  {
  }

  public void process(MqttPuback paramMqttPuback)
  {
  }

  public void process(MqttPubcomp paramMqttPubcomp)
  {
  }

  public void process(MqttPublish paramMqttPublish)
  {
  }

  public void process(MqttPubrec paramMqttPubrec)
  {
  }

  public void process(MqttPubrel paramMqttPubrel)
  {
  }

  public void process(MqttSuback paramMqttSuback)
  {
  }

  public void process(MqttSubscribe paramMqttSubscribe)
  {
  }

  public void process(MqttUnsuback paramMqttUnsuback)
  {
  }

  public void process(MqttUnsubscribe paramMqttUnsubscribe)
  {
  }

  protected final MqttPacket readPacket()
    throws MqttException, InterruptedIOException, IOException
  {
    int i = 0;
    byte[] arrayOfByte1 = new byte[5];
    try
    {
      synchronized (this.streamReadLock)
      {
        int j = this.stream_in.read(arrayOfByte1, 0, 1);
        if (j < 0)
          throw new EOFException("DataInputStream.read returned -1");
      }
    }
    catch (IOException localIOException)
    {
      MQeTrace.trace(this, (short)-30033, 2097152L, localIOException.getMessage());
      throw localIOException;
    }
    while (true)
    {
      int i1 = (byte)this.stream_in.read();
      arrayOfByte1[k] = i1;
      int i2 = n + m * (i1 & 0x7F);
      int i3 = m * 128;
      int i4 = k + 1;
      if ((i1 & 0x80) == 0)
      {
        byte[] arrayOfByte2 = new byte[i2 + i4];
        while (i < i4)
        {
          arrayOfByte2[i] = arrayOfByte1[i];
          i++;
        }
        MQeTrace.trace(this, (short)-30035, 2097152L, Integer.toString(i4), Integer.toString(i2));
        if (i2 > 0)
          this.stream_in.readFully(arrayOfByte2, i4, i2);
        short s = (short)(0xF & arrayOfByte2[0] >>> 4);
        return decodePacket(arrayOfByte2, i4, s);
      }
      int k = i4;
      int m = i3;
      int n = i2;
      continue;
      k = 1;
      m = 1;
      n = 0;
    }
  }

  protected void releaseMsgId(int paramInt)
  {
    this.outMsgIdsAllocated.remove(new Integer(paramInt));
  }

  protected void setConnectionLost(boolean paramBoolean)
  {
    try
    {
      this.connectionLost = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected void setConnectionState(boolean paramBoolean)
  {
    try
    {
      this.connected = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected void setKeepAlive(int paramInt)
  {
    this.keepAlivePeriod = paramInt;
  }

  protected void setRegisteredThrowable(Throwable paramThrowable)
  {
    if ((paramThrowable == null) || ((paramThrowable instanceof MqttException)));
    for (this.registeredException = ((MqttException)paramThrowable); ; this.registeredException = new MqttException(paramThrowable))
    {
      setConnectionState(false);
      tcpipDisconnect(true);
      setConnectionLost(true);
      return;
    }
  }

  protected void subscribeOut(int paramInt, String[] paramArrayOfString, byte[] paramArrayOfByte, boolean paramBoolean)
    throws Exception
  {
  }

  public boolean supportTopicNameCompression()
  {
    return this.topicNameCompression;
  }

  protected void tcpipConnect(MqttConnect paramMqttConnect)
    throws IOException, Exception
  {
    synchronized (this.streamWriteLock)
    {
      tcpipDisconnect(true);
    }
    try
    {
      this.socket = ((MqttAdapter)this.socketClass.newInstance());
      this.socket.setConnection(this.connection, paramMqttConnect.KeepAlive);
      setSocketState(true);
      this.stream_in = new DataInputStream(this.socket.getInputStream());
      this.stream_out = new DataOutputStream(this.socket.getOutputStream());
      writePacket(paramMqttConnect);
      return;
    }
    catch (IOException localIOException)
    {
      tcpipDisconnect(true);
      throw localIOException;
      localObject2 = finally;
      throw localObject2;
    }
    catch (Exception localException)
    {
      tcpipDisconnect(true);
      throw localException;
    }
  }

  protected void tcpipDisconnect(boolean paramBoolean)
  {
    synchronized (this.streamWriteLock)
    {
      DataOutputStream localDataOutputStream = this.stream_out;
      if (localDataOutputStream == null);
    }
    try
    {
      this.socket.closeOutputStream();
      label27: this.stream_out = null;
      if (paramBoolean)
      {
        setSocketState(false);
        DataInputStream localDataInputStream = this.stream_in;
        if (localDataInputStream == null);
      }
      try
      {
        this.socket.closeInputStream();
        label61: this.stream_in = null;
        MqttAdapter localMqttAdapter = this.socket;
        if (localMqttAdapter != null);
        try
        {
          this.socket.close();
          label86: this.socket = null;
          return;
          localObject2 = finally;
          throw localObject2;
        }
        catch (IOException localIOException1)
        {
          break label86;
        }
      }
      catch (IOException localIOException2)
      {
        break label61;
      }
    }
    catch (IOException localIOException3)
    {
      break label27;
    }
  }

  protected void unsubscribeOut(int paramInt, String[] paramArrayOfString, boolean paramBoolean)
    throws Exception
  {
  }

  protected final void writePacket(MqttPacket paramMqttPacket)
    throws MqttException
  {
    synchronized (this.streamWriteLock)
    {
      DataOutputStream localDataOutputStream = this.stream_out;
      if (localDataOutputStream == null)
        break label127;
    }
    try
    {
      byte[] arrayOfByte1 = paramMqttPacket.getPayload();
      byte[] arrayOfByte2 = paramMqttPacket.toBytes();
      paramMqttPacket.setDup(true);
      this.stream_out.write(arrayOfByte2);
      if (arrayOfByte1 != null)
        this.stream_out.write(arrayOfByte1);
      this.stream_out.flush();
      return;
    }
    catch (IOException localIOException)
    {
      MQeTrace.trace(this, (short)-30034, 2097152L, localIOException.getMessage());
      tcpipDisconnect(true);
      throw new MqttException(localIOException);
      localObject2 = finally;
      throw localObject2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      tcpipDisconnect(true);
      throw new MqttException(localException);
    }
    label127: throw new MqttNotConnectedException();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.Mqtt
 * JD-Core Version:    0.6.2
 */