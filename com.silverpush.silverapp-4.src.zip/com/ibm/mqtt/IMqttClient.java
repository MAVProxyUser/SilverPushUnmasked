package com.ibm.mqtt;

public abstract interface IMqttClient
{
  public static final String LOCAL_ID = "local://";
  public static final String TCP_ID = "tcp://";

  public abstract void connect(String paramString, boolean paramBoolean, short paramShort)
    throws MqttException, MqttPersistenceException, MqttBrokerUnavailableException, MqttNotConnectedException;

  public abstract void connect(String paramString1, boolean paramBoolean1, short paramShort, String paramString2, int paramInt, String paramString3, boolean paramBoolean2)
    throws MqttException, MqttPersistenceException, MqttBrokerUnavailableException, MqttNotConnectedException;

  public abstract void disconnect()
    throws MqttPersistenceException;

  public abstract String getConnection();

  public abstract MqttPersistence getPersistence();

  public abstract int getRetry();

  public abstract boolean isConnected();

  public abstract boolean outstanding(int paramInt);

  public abstract void ping()
    throws MqttException;

  public abstract int publish(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
    throws MqttNotConnectedException, MqttPersistenceException, MqttException, IllegalArgumentException;

  public abstract void registerAdvancedHandler(MqttAdvancedCallback paramMqttAdvancedCallback);

  public abstract void registerSimpleHandler(MqttSimpleCallback paramMqttSimpleCallback);

  public abstract void setRetry(int paramInt);

  public abstract void startTrace()
    throws MqttException;

  public abstract void stopTrace();

  public abstract int subscribe(String[] paramArrayOfString, int[] paramArrayOfInt)
    throws MqttNotConnectedException, MqttException, IllegalArgumentException;

  public abstract void terminate();

  public abstract int unsubscribe(String[] paramArrayOfString)
    throws MqttNotConnectedException, MqttException, IllegalArgumentException;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.IMqttClient
 * JD-Core Version:    0.6.2
 */