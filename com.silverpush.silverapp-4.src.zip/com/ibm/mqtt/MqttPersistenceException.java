package com.ibm.mqtt;

public class MqttPersistenceException extends MqttException
{
  public MqttPersistenceException()
  {
  }

  public MqttPersistenceException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPersistenceException
 * JD-Core Version:    0.6.2
 */