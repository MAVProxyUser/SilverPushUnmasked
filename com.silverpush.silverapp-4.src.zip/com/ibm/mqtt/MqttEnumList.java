package com.ibm.mqtt;

import java.util.Enumeration;

public class MqttEnumList
  implements Enumeration
{
  private int count;
  private int index;
  private boolean keys;
  private MqttHashTable mqtt_enum;
  private MqttListItem ptr;
  private int size;

  public MqttEnumList(MqttHashTable paramMqttHashTable, boolean paramBoolean)
  {
    this.mqtt_enum = paramMqttHashTable;
    this.size = this.mqtt_enum.size();
    this.keys = paramBoolean;
    this.count = 0;
    this.index = 0;
    MqttListItem localMqttListItem = this.mqtt_enum.hashTable[this.index];
    this.ptr = localMqttListItem;
    if (localMqttListItem == null)
      this.ptr = advance(this.ptr);
  }

  private MqttListItem advance(MqttListItem paramMqttListItem)
  {
    while (1 + this.index < this.mqtt_enum.m_capacity)
    {
      this.index = (1 + this.index);
      MqttListItem localMqttListItem = this.mqtt_enum.hashTable[this.index];
      if (localMqttListItem != null)
        return localMqttListItem;
    }
    return null;
  }

  public boolean hasMoreElements()
  {
    return this.count < this.size;
  }

  public Object nextElement()
  {
    MqttListItem localMqttListItem1 = this.ptr;
    if (!this.ptr.isEnd());
    for (MqttListItem localMqttListItem2 = this.ptr.next; ; localMqttListItem2 = advance(this.ptr))
    {
      this.ptr = localMqttListItem2;
      this.count = (1 + this.count);
      if (!this.keys)
        break;
      return new Long(localMqttListItem1.key);
    }
    return localMqttListItem1.data;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttEnumList
 * JD-Core Version:    0.6.2
 */