package com.ibm.mqtt;

public abstract interface MqttProcessor
{
  public abstract void process(MqttConnack paramMqttConnack);

  public abstract void process(MqttConnect paramMqttConnect);

  public abstract void process(MqttDisconnect paramMqttDisconnect);

  public abstract void process(MqttPingreq paramMqttPingreq);

  public abstract void process(MqttPingresp paramMqttPingresp);

  public abstract void process(MqttPuback paramMqttPuback);

  public abstract void process(MqttPubcomp paramMqttPubcomp);

  public abstract void process(MqttPublish paramMqttPublish);

  public abstract void process(MqttPubrec paramMqttPubrec);

  public abstract void process(MqttPubrel paramMqttPubrel);

  public abstract void process(MqttSuback paramMqttSuback);

  public abstract void process(MqttSubscribe paramMqttSubscribe);

  public abstract void process(MqttUnsuback paramMqttUnsuback);

  public abstract void process(MqttUnsubscribe paramMqttUnsubscribe);

  public abstract boolean supportTopicNameCompression();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttProcessor
 * JD-Core Version:    0.6.2
 */