package com.ibm.mqtt;

public abstract interface MqttAdvancedCallback extends MqttSimpleCallback
{
  public abstract void published(int paramInt);

  public abstract void subscribed(int paramInt, byte[] paramArrayOfByte);

  public abstract void unsubscribed(int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttAdvancedCallback
 * JD-Core Version:    0.6.2
 */