package com.ibm.mqtt;

public class MqttPubcomp extends MqttPacket
{
  public MqttPubcomp()
  {
    setMsgType((short)7);
  }

  public MqttPubcomp(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)7);
    setMsgId(MqttUtils.toShort(paramArrayOfByte, paramInt));
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    this.message = new byte[3];
    this.message[0] = super.toBytes()[0];
    int i = getMsgId();
    this.message[1] = ((byte)(i / 256));
    this.message[2] = ((byte)(i % 256));
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPubcomp
 * JD-Core Version:    0.6.2
 */