package com.ibm.mqtt;

public class MqttPingresp extends MqttPacket
{
  public MqttPingresp()
  {
    setMsgType((short)13);
  }

  public MqttPingresp(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)13);
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    this.message = new byte[1];
    this.message[0] = super.toBytes()[0];
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPingresp
 * JD-Core Version:    0.6.2
 */