package com.ibm.mqtt;

public class MqttException extends Exception
{
  private Throwable le = null;

  public MqttException()
  {
  }

  public MqttException(String paramString)
  {
    super(paramString);
  }

  public MqttException(Throwable paramThrowable)
  {
  }

  public Throwable getCause()
  {
    return this.le;
  }

  public Throwable initCause(Throwable paramThrowable)
  {
    if (this.le != null)
      throw new IllegalStateException();
    if (paramThrowable == this)
      throw new IllegalArgumentException();
    this.le = paramThrowable;
    return this;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttException
 * JD-Core Version:    0.6.2
 */