package com.ibm.mqtt;

public class MQe
{
  public static final char[] Hex = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
  public static final String copyright = "Licensed Materials - Property of IBM\nProduct number: 5765-E63\nCopyright IBM Corp. 1999,2002 All Rights Reserved.\nUS Government Users Restriced Rights - use, duplication or\ndisclosure restriced by GSA ADP Schedule Contract with IBM Corp.";
  public static final String sccsid = "mqe_java/source/com/ibm/mqe/MQe.java, MQeBase, la000 1.111";
  public static short[] version = { 2, 0, 0, 2 };
  private MQeTrace traceService = new MQeTrace();

  public static byte[] asciiToByte(String paramString)
  {
    int i = 0;
    if (paramString == null)
      return null;
    byte[] arrayOfByte = new byte[paramString.length()];
    char[] arrayOfChar = new char[paramString.length()];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    while (i < arrayOfChar.length)
    {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
      i++;
    }
    return arrayOfByte;
  }

  public static String byteToAscii(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
      return null;
    char[] arrayOfChar = new char[paramArrayOfByte.length];
    for (int i = 0; i < paramArrayOfByte.length; i++)
      arrayOfChar[i] = ((char)(0xFF & paramArrayOfByte[i]));
    return new String(arrayOfChar);
  }

  public static String byteToHex(byte[] paramArrayOfByte)
  {
    return byteToHex(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public static String byteToHex(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    StringBuffer localStringBuffer = new StringBuffer(128);
    if (paramArrayOfByte != null)
      for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      {
        localStringBuffer.append(Hex[(0xF & paramArrayOfByte[i] >> 4)]);
        localStringBuffer.append(Hex[(0xF & paramArrayOfByte[i])]);
      }
    return localStringBuffer.toString();
  }

  public static int byteToInt(byte[] paramArrayOfByte, int paramInt)
  {
    int i = 0;
    int j = 0;
    while (i < 4)
    {
      j = (j << 8) + (0xFF & paramArrayOfByte[(paramInt + i)]);
      i++;
    }
    return j;
  }

  public static long byteToLong(byte[] paramArrayOfByte, int paramInt)
  {
    long l = 0L;
    for (int i = 0; i < 8; i++)
      l = (l << 8) + (0xFF & paramArrayOfByte[(paramInt + i)]);
    return l;
  }

  public static short byteToShort(byte[] paramArrayOfByte, int paramInt)
  {
    return (short)(((0xFF & (short)paramArrayOfByte[(paramInt + 0)]) << 8) + (0xFF & (short)paramArrayOfByte[(paramInt + 1)]));
  }

  public static String byteToUnicode(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
      return null;
    char[] arrayOfChar = new char[paramArrayOfByte.length / 2];
    for (int i = 0; i < arrayOfChar.length; i++)
      arrayOfChar[i] = ((char)((0xFF & paramArrayOfByte[(i * 2)]) << 8 | 0xFF & paramArrayOfByte[(1 + i * 2)]));
    return new String(arrayOfChar, 0, arrayOfChar.length);
  }

  public static byte[] intToByte(int paramInt)
  {
    byte[] arrayOfByte = new byte[4];
    for (int i = 0; i < 4; i++)
    {
      arrayOfByte[(3 - i)] = ((byte)(paramInt & 0xFF));
      paramInt >>= 8;
    }
    return arrayOfByte;
  }

  public static byte[] longToByte(long paramLong)
  {
    byte[] arrayOfByte = new byte[8];
    for (int i = 0; i < 8; i++)
    {
      arrayOfByte[(7 - i)] = ((byte)(int)(0xFF & paramLong));
      paramLong >>= 8;
    }
    return arrayOfByte;
  }

  public static byte[] shortToByte(short paramShort)
  {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = ((byte)(0xFF & paramShort >> 8));
    arrayOfByte[1] = ((byte)(paramShort & 0xFF));
    return arrayOfByte;
  }

  public static byte[] unicodeToByte(String paramString)
  {
    int i = 0;
    if (paramString == null)
      return null;
    char[] arrayOfChar = new char[paramString.length()];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    byte[] arrayOfByte = new byte[2 * arrayOfChar.length];
    while (i < arrayOfChar.length)
    {
      arrayOfByte[(i * 2)] = ((byte)(0xFF & arrayOfChar[i] >> '\b'));
      arrayOfByte[(1 + i * 2)] = ((byte)(0xFF & arrayOfChar[i]));
      i++;
    }
    return arrayOfByte;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MQe
 * JD-Core Version:    0.6.2
 */