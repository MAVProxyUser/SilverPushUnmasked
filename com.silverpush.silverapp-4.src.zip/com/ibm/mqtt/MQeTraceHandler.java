package com.ibm.mqtt;

public abstract interface MQeTraceHandler
{
  public static final short[] version = { 2, 0, 0, 2 };

  public abstract void setFilter(long paramLong);

  public abstract void traceMessage(Object paramObject, short paramShort, long paramLong);

  public abstract void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2);

  public abstract void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2, Object paramObject3);

  public abstract void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2, Object paramObject3, Object paramObject4);

  public abstract void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MQeTraceHandler
 * JD-Core Version:    0.6.2
 */