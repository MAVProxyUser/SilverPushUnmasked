package com.ibm.mqtt;

import java.util.Vector;

public class MqttSubscribe extends MqttPacket
{
  public String[] topics;
  public byte[] topicsQoS;

  public MqttSubscribe()
  {
    setMsgType((short)8);
  }

  public MqttSubscribe(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)8);
    setMsgId(MqttUtils.toShort(paramArrayOfByte, paramInt));
    Vector localVector = MqttUtils.getTopicsWithQoS(MqttUtils.SliceByteArray(paramArrayOfByte, paramInt + 2, paramArrayOfByte.length - (paramInt + 2)));
    int i = localVector.size();
    this.topicsQoS = new byte[i];
    this.topics = new String[i];
    for (int j = 0; j < i; j++)
    {
      String str = localVector.elementAt(j).toString();
      this.topics[j] = str.substring(0, -1 + str.length());
      char c = str.charAt(-1 + str.length());
      this.topicsQoS[j] = ((byte)Character.digit(c, 10));
    }
  }

  private void uncompressTopic()
  {
  }

  public void compressTopic()
  {
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    this.message = new byte[3];
    this.message[0] = super.toBytes()[0];
    int i = getMsgId();
    this.message[1] = ((byte)(i / 256));
    this.message[2] = ((byte)(i % 256));
    for (int j = 0; j < this.topics.length; j++)
    {
      byte[] arrayOfByte = MqttUtils.StringToUTF(this.topics[j]);
      this.message = MqttUtils.concatArray(MqttUtils.concatArray(this.message, arrayOfByte), 0, this.message.length + arrayOfByte.length, this.topicsQoS, j, 1);
    }
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttSubscribe
 * JD-Core Version:    0.6.2
 */