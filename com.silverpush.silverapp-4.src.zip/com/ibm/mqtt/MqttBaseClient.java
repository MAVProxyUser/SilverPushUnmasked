package com.ibm.mqtt;

import java.util.Hashtable;
import java.util.Vector;

public abstract class MqttBaseClient extends Mqtt
  implements Runnable
{
  protected static final int conNotify = 1;
  private static int maxOutstanding = 0;
  protected static final int subNotify = 4;
  protected static final int unsubNotify = 5;
  private boolean cleanSession = false;
  private Hashtable grantedQoS = new Hashtable();
  private Object outLock = new Object();
  private boolean outLockNotified = false;
  private MqttHashTable outstandingQueue = null;
  private MqttPersistence persistenceLayer = null;
  private Hashtable qos2PubsArrived = new Hashtable();
  private Object readerControl = new Object();
  private int retryPeriod;
  private MqttTimedEventQueue retryQueue = null;
  private boolean terminated = false;

  private void doConnect(MqttConnect paramMqttConnect, boolean paramBoolean, short paramShort)
    throws MqttException, MqttPersistenceException
  {
    this.retryQueue.resetTimedEventQueue();
    this.outstandingQueue.clear();
    this.qos2PubsArrived.clear();
    initialiseOutMsgIds(null);
    if ((this.persistenceLayer != null) && (!isConnectionLost()))
      this.persistenceLayer.open(paramMqttConnect.getClientId(), this.connection);
    if (paramBoolean)
    {
      this.cleanSession = true;
      if (this.persistenceLayer != null)
        this.persistenceLayer.reset();
    }
    MqttRetry localMqttRetry;
    if (paramShort > 0)
      localMqttRetry = new MqttRetry(this, new MqttPingreq(), paramShort * 1000);
    Vector localVector;
    while (true)
    {
      byte[][] arrayOfByte1;
      int i;
      synchronized (this.outstandingQueue)
      {
        this.outstandingQueue.put(0L, localMqttRetry);
        this.retryQueue.enqueue(localMqttRetry);
        if ((paramBoolean) || (this.persistenceLayer == null) || (isConnectionLost()))
          break label667;
        arrayOfByte1 = this.persistenceLayer.getAllSentMessages();
        if (arrayOfByte1 == null)
          break label499;
        localVector = new Vector();
        i = 0;
        if (i >= arrayOfByte1.length)
          break;
      }
      try
      {
        arrayOfByte4 = arrayOfByte1[i];
        int i2 = 1;
        i3 = 1;
        int i4 = 0;
        int i5;
        do
        {
          i5 = arrayOfByte4[i3];
          i4 += i2 * (i5 & 0x7F);
          i2 *= 128;
          i3++;
        }
        while ((i5 & 0x80) != 0);
        if (i4 + i3 != arrayOfByte4.length)
          invalidSentMessageRestored(i);
        do
        {
          i++;
          break;
          localObject1 = finally;
          throw localObject1;
          switch (MqttPacket.getMsgType(arrayOfByte4[0]))
          {
          case 4:
          case 5:
          default:
            invalidSentMessageRestored(i);
            localObject4 = null;
          case 3:
          case 6:
          }
        }
        while (localObject4 == null);
      }
      catch (IndexOutOfBoundsException localIndexOutOfBoundsException2)
      {
        synchronized (this.outstandingQueue)
        {
          byte[] arrayOfByte4;
          int i3;
          while (true)
          {
            this.outstandingQueue.put(((MqttRetry)localObject4).getMsgId(), localObject4);
            this.retryQueue.enqueue((MqttTimedEvent)localObject4);
            continue;
            localIndexOutOfBoundsException2 = localIndexOutOfBoundsException2;
            invalidSentMessageRestored(i);
            continue;
            MqttPublish localMqttPublish2 = new MqttPublish(arrayOfByte4, i3);
            localVector.addElement(new Integer(localMqttPublish2.getMsgId()));
            localObject4 = new MqttRetry(this, localMqttPublish2, this.retryPeriod);
          }
          MqttPubrel localMqttPubrel = new MqttPubrel(arrayOfByte4, i3);
          localVector.addElement(new Integer(localMqttPubrel.getMsgId()));
          Object localObject4 = new MqttRetry(this, localMqttPubrel, this.retryPeriod);
        }
      }
    }
    initialiseOutMsgIds(localVector);
    label499: byte[][] arrayOfByte2 = this.persistenceLayer.getAllReceivedMessages();
    if (arrayOfByte2 != null);
    for (int j = 0; ; j++)
      if (j < arrayOfByte2.length)
      {
        try
        {
          byte[] arrayOfByte3 = arrayOfByte2[j];
          int k = 1;
          int m = 1;
          int n = 0;
          int i1;
          do
          {
            i1 = arrayOfByte3[m];
            n += k * (i1 & 0x7F);
            k *= 128;
            m++;
          }
          while ((i1 & 0x80) != 0);
          if (n + m != arrayOfByte3.length)
          {
            invalidReceivedMessageRestored(j);
          }
          else if (MqttPacket.getMsgType(arrayOfByte3[0]) == 3)
          {
            MqttPublish localMqttPublish1 = new MqttPublish(arrayOfByte3, m);
            this.qos2PubsArrived.put(Integer.toString(localMqttPublish1.getMsgId()), localMqttPublish1);
          }
        }
        catch (IndexOutOfBoundsException localIndexOutOfBoundsException1)
        {
          invalidReceivedMessageRestored(j);
        }
        invalidReceivedMessageRestored(j);
      }
      else
      {
        label667: this.registeredException = null;
        setConnectionLost(false);
        try
        {
          synchronized (this.readerControl)
          {
            tcpipConnect(paramMqttConnect);
            this.readerControl.notify();
            return;
          }
        }
        catch (MqttException localMqttException2)
        {
          throw localMqttException2;
        }
        catch (Exception localException)
        {
          MqttException localMqttException1 = new MqttException();
          localMqttException1.initCause(localException);
          throw localMqttException1;
        }
      }
  }

  private void invalidReceivedMessageRestored(int paramInt)
  {
    MQeTrace.trace(this, (short)-30037, 1L, new Integer(paramInt));
  }

  private void invalidSentMessageRestored(int paramInt)
  {
    MQeTrace.trace(this, (short)-30036, 1L, new Integer(paramInt));
  }

  private MqttPacket messageAck(int paramInt)
  {
    MqttRetry localMqttRetry1 = (MqttRetry)this.outstandingQueue.get(paramInt);
    if (localMqttRetry1 == null)
      return null;
    if ((localMqttRetry1.getQoS() == 2) && (localMqttRetry1.getMsgType() == 3))
      return messageAckQoS2(paramInt);
    while (true)
    {
      int i;
      try
      {
        if (this.persistenceLayer != null)
          synchronized (this.persistenceLayer)
          {
            this.persistenceLayer.delSentMessage(paramInt);
          }
      }
      catch (MqttPersistenceException localMqttPersistenceException)
      {
        synchronized (this.outstandingQueue)
        {
          MqttRetry localMqttRetry2 = (MqttRetry)this.outstandingQueue.remove(paramInt);
          releaseMsgId(paramInt);
          if (localMqttRetry2 != null)
            i = localMqttRetry2.getMsgType();
          switch (i)
          {
          case 4:
          case 5:
          case 7:
          case 9:
          default:
            return null;
            localObject4 = finally;
            throw localObject4;
            localMqttPersistenceException = localMqttPersistenceException;
          case 3:
          case 6:
          case 8:
          case 10:
          }
        }
      }
      if (this.outstandingQueue.size() == -1 + maxOutstanding);
      synchronized (this.outLock)
      {
        this.outLockNotified = true;
        this.outLock.notifyAll();
        notifyAck(i, paramInt);
      }
    }
  }

  // ERROR //
  private MqttPacket messageAckQoS2(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: iconst_0
    //   3: invokevirtual 246	com/ibm/mqtt/MqttBaseClient:genPubRelPacket	(IZ)Lcom/ibm/mqtt/MqttPubrel;
    //   6: astore_2
    //   7: aload_0
    //   8: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   11: ifnull +29 -> 40
    //   14: aload_0
    //   15: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   18: astore 8
    //   20: aload 8
    //   22: monitorenter
    //   23: aload_0
    //   24: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   27: iload_1
    //   28: aload_2
    //   29: invokevirtual 250	com/ibm/mqtt/MqttPacket:toBytes	()[B
    //   32: invokeinterface 254 3 0
    //   37: aload 8
    //   39: monitorexit
    //   40: aload_0
    //   41: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   44: astore 4
    //   46: aload 4
    //   48: monitorenter
    //   49: aload_0
    //   50: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   53: iload_1
    //   54: i2l
    //   55: invokevirtual 229	com/ibm/mqtt/MqttHashTable:remove	(J)Ljava/lang/Object;
    //   58: checkcast 115	com/ibm/mqtt/MqttRetry
    //   61: astore 6
    //   63: aload 6
    //   65: ifnull +21 -> 86
    //   68: aload 6
    //   70: aload_2
    //   71: invokevirtual 258	com/ibm/mqtt/MqttRetry:setMessage	(Lcom/ibm/mqtt/MqttPacket;)V
    //   74: aload_0
    //   75: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   78: iload_1
    //   79: i2l
    //   80: aload 6
    //   82: invokevirtual 125	com/ibm/mqtt/MqttHashTable:put	(JLjava/lang/Object;)Ljava/lang/Object;
    //   85: pop
    //   86: aload 4
    //   88: monitorexit
    //   89: aload_2
    //   90: areturn
    //   91: astore 9
    //   93: aload 8
    //   95: monitorexit
    //   96: aload 9
    //   98: athrow
    //   99: astore_3
    //   100: aload_2
    //   101: areturn
    //   102: astore 5
    //   104: aload 4
    //   106: monitorexit
    //   107: aload 5
    //   109: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   23	40	91	finally
    //   93	96	91	finally
    //   7	23	99	com/ibm/mqtt/MqttPersistenceException
    //   40	49	99	com/ibm/mqtt/MqttPersistenceException
    //   96	99	99	com/ibm/mqtt/MqttPersistenceException
    //   107	110	99	com/ibm/mqtt/MqttPersistenceException
    //   49	63	102	finally
    //   68	86	102	finally
    //   86	89	102	finally
    //   104	107	102	finally
  }

  // ERROR //
  private void sendPacket(MqttPacket paramMqttPacket)
    throws MqttException, MqttNotConnectedException
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: sipush 1000
    //   5: aload_0
    //   6: invokevirtual 266	com/ibm/mqtt/MqttBaseClient:getRetry	()I
    //   9: imul
    //   10: i2l
    //   11: lstore_3
    //   12: aload_0
    //   13: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   16: ifne +11 -> 27
    //   19: new 261	com/ibm/mqtt/MqttNotConnectedException
    //   22: dup
    //   23: invokespecial 270	com/ibm/mqtt/MqttNotConnectedException:<init>	()V
    //   26: athrow
    //   27: aload_1
    //   28: invokevirtual 273	com/ibm/mqtt/MqttPacket:getQos	()I
    //   31: ifle +293 -> 324
    //   34: aload_0
    //   35: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   38: invokevirtual 235	com/ibm/mqtt/MqttHashTable:size	()I
    //   41: getstatic 36	com/ibm/mqtt/MqttBaseClient:maxOutstanding	I
    //   44: if_icmplt +64 -> 108
    //   47: aload_0
    //   48: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   51: astore 15
    //   53: aload 15
    //   55: monitorenter
    //   56: aload_0
    //   57: getfield 63	com/ibm/mqtt/MqttBaseClient:outLockNotified	Z
    //   60: ifne +10 -> 70
    //   63: aload_0
    //   64: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   67: invokevirtual 276	java/lang/Object:wait	()V
    //   70: aload_0
    //   71: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   74: ifeq +8 -> 82
    //   77: aload_0
    //   78: iconst_0
    //   79: putfield 63	com/ibm/mqtt/MqttBaseClient:outLockNotified	Z
    //   82: aload 15
    //   84: monitorexit
    //   85: aload_0
    //   86: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   89: ifne +19 -> 108
    //   92: new 261	com/ibm/mqtt/MqttNotConnectedException
    //   95: dup
    //   96: invokespecial 270	com/ibm/mqtt/MqttNotConnectedException:<init>	()V
    //   99: athrow
    //   100: astore 17
    //   102: aload 15
    //   104: monitorexit
    //   105: aload 17
    //   107: athrow
    //   108: aload_0
    //   109: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   112: ifnull +54 -> 166
    //   115: aload_0
    //   116: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   119: astore 12
    //   121: aload 12
    //   123: monitorenter
    //   124: aload_1
    //   125: invokevirtual 250	com/ibm/mqtt/MqttPacket:toBytes	()[B
    //   128: astore 14
    //   130: aload_1
    //   131: invokevirtual 279	com/ibm/mqtt/MqttPacket:getPayload	()[B
    //   134: ifnull +14 -> 148
    //   137: aload 14
    //   139: aload_1
    //   140: invokevirtual 279	com/ibm/mqtt/MqttPacket:getPayload	()[B
    //   143: invokestatic 285	com/ibm/mqtt/MqttUtils:concatArray	([B[B)[B
    //   146: astore 14
    //   148: aload_0
    //   149: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   152: aload_1
    //   153: invokevirtual 286	com/ibm/mqtt/MqttPacket:getMsgId	()I
    //   156: aload 14
    //   158: invokeinterface 289 3 0
    //   163: aload 12
    //   165: monitorexit
    //   166: aload_0
    //   167: invokevirtual 292	com/ibm/mqtt/MqttBaseClient:getKeepAlivePeriod	()I
    //   170: ifle +131 -> 301
    //   173: aload_0
    //   174: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   177: invokevirtual 235	com/ibm/mqtt/MqttHashTable:size	()I
    //   180: iload_2
    //   181: if_icmple +115 -> 296
    //   184: iload_2
    //   185: ifeq +5 -> 190
    //   188: lconst_0
    //   189: lstore_3
    //   190: new 115	com/ibm/mqtt/MqttRetry
    //   193: dup
    //   194: aload_0
    //   195: aload_1
    //   196: lload_3
    //   197: invokespecial 121	com/ibm/mqtt/MqttRetry:<init>	(Lcom/ibm/mqtt/MqttBaseClient;Lcom/ibm/mqtt/MqttPacket;J)V
    //   200: astore 5
    //   202: aload_0
    //   203: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   206: astore 6
    //   208: aload 6
    //   210: monitorenter
    //   211: aload_0
    //   212: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   215: aload_1
    //   216: invokevirtual 286	com/ibm/mqtt/MqttPacket:getMsgId	()I
    //   219: i2l
    //   220: aload 5
    //   222: invokevirtual 125	com/ibm/mqtt/MqttHashTable:put	(JLjava/lang/Object;)Ljava/lang/Object;
    //   225: pop
    //   226: aload 6
    //   228: monitorexit
    //   229: aload_0
    //   230: getfield 57	com/ibm/mqtt/MqttBaseClient:retryQueue	Lcom/ibm/mqtt/MqttTimedEventQueue;
    //   233: aload 5
    //   235: invokevirtual 129	com/ibm/mqtt/MqttTimedEventQueue:enqueue	(Lcom/ibm/mqtt/MqttTimedEvent;)V
    //   238: lload_3
    //   239: lconst_0
    //   240: lcmp
    //   241: ifle +8 -> 249
    //   244: aload_0
    //   245: aload_1
    //   246: invokevirtual 295	com/ibm/mqtt/MqttBaseClient:writePacket	(Lcom/ibm/mqtt/MqttPacket;)V
    //   249: return
    //   250: astore 13
    //   252: aload 12
    //   254: monitorexit
    //   255: aload 13
    //   257: athrow
    //   258: astore 11
    //   260: aload 11
    //   262: athrow
    //   263: astore 10
    //   265: new 71	com/ibm/mqtt/MqttPersistenceException
    //   268: dup
    //   269: new 297	java/lang/StringBuffer
    //   272: dup
    //   273: invokespecial 298	java/lang/StringBuffer:<init>	()V
    //   276: ldc_w 300
    //   279: invokevirtual 304	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   282: aload_1
    //   283: invokevirtual 286	com/ibm/mqtt/MqttPacket:getMsgId	()I
    //   286: invokevirtual 307	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   289: invokevirtual 309	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   292: invokespecial 312	com/ibm/mqtt/MqttPersistenceException:<init>	(Ljava/lang/String;)V
    //   295: athrow
    //   296: iconst_0
    //   297: istore_2
    //   298: goto -114 -> 184
    //   301: aload_0
    //   302: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   305: invokevirtual 235	com/ibm/mqtt/MqttHashTable:size	()I
    //   308: ifgt -124 -> 184
    //   311: iconst_0
    //   312: istore_2
    //   313: goto -129 -> 184
    //   316: astore 7
    //   318: aload 6
    //   320: monitorexit
    //   321: aload 7
    //   323: athrow
    //   324: aload_0
    //   325: aload_1
    //   326: invokevirtual 295	com/ibm/mqtt/MqttBaseClient:writePacket	(Lcom/ibm/mqtt/MqttPacket;)V
    //   329: return
    //   330: astore 9
    //   332: return
    //   333: astore 16
    //   335: goto -253 -> 82
    //
    // Exception table:
    //   from	to	target	type
    //   56	70	100	finally
    //   70	82	100	finally
    //   82	85	100	finally
    //   102	105	100	finally
    //   124	148	250	finally
    //   148	166	250	finally
    //   252	255	250	finally
    //   115	124	258	com/ibm/mqtt/MqttPersistenceException
    //   255	258	258	com/ibm/mqtt/MqttPersistenceException
    //   115	124	263	java/lang/Exception
    //   255	258	263	java/lang/Exception
    //   211	229	316	finally
    //   318	321	316	finally
    //   244	249	330	com/ibm/mqtt/MqttException
    //   56	70	333	java/lang/InterruptedException
    //   70	82	333	java/lang/InterruptedException
  }

  public static void setWindowSize(int paramInt)
  {
    maxOutstanding = paramInt;
  }

  public void anyErrors()
    throws MqttException
  {
    if (this.registeredException != null)
      throw this.registeredException;
  }

  protected void connect(String paramString1, boolean paramBoolean1, boolean paramBoolean2, short paramShort, String paramString2, int paramInt, String paramString3, boolean paramBoolean3)
    throws MqttException, MqttPersistenceException
  {
    while (true)
    {
      MqttConnect localMqttConnect;
      synchronized (this.outLock)
      {
        this.outLockNotified = false;
        localMqttConnect = new MqttConnect();
        localMqttConnect.setClientId(paramString1);
        localMqttConnect.CleanStart = paramBoolean1;
        localMqttConnect.TopicNameCompression = paramBoolean2;
        localMqttConnect.KeepAlive = paramShort;
        if (paramString2 != null)
        {
          localMqttConnect.Will = true;
          localMqttConnect.WillTopic = paramString2;
          localMqttConnect.WillQoS = paramInt;
          localMqttConnect.WillRetain = paramBoolean3;
          localMqttConnect.WillMessage = paramString3;
          setKeepAlive(paramShort);
          doConnect(localMqttConnect, paramBoolean1, paramShort);
          return;
        }
      }
      localMqttConnect.Will = false;
    }
  }

  protected void connectionLost()
    throws Exception
  {
    synchronized (this.outLock)
    {
      this.outLockNotified = true;
      this.outLock.notifyAll();
      return;
    }
  }

  // ERROR //
  protected void disconnect()
    throws MqttPersistenceException
  {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: invokevirtual 355	com/ibm/mqtt/MqttBaseClient:setConnectionState	(Z)V
    //   5: aload_0
    //   6: new 357	com/ibm/mqtt/MqttDisconnect
    //   9: dup
    //   10: invokespecial 358	com/ibm/mqtt/MqttDisconnect:<init>	()V
    //   13: invokevirtual 295	com/ibm/mqtt/MqttBaseClient:writePacket	(Lcom/ibm/mqtt/MqttPacket;)V
    //   16: aload_0
    //   17: iconst_0
    //   18: invokevirtual 361	com/ibm/mqtt/MqttBaseClient:tcpipDisconnect	(Z)V
    //   21: aload_0
    //   22: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   25: astore 16
    //   27: aload 16
    //   29: monitorenter
    //   30: aload_0
    //   31: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   34: istore 18
    //   36: iload 18
    //   38: ifeq +13 -> 51
    //   41: aload_0
    //   42: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   45: ldc2_w 362
    //   48: invokevirtual 366	java/lang/Object:wait	(J)V
    //   51: aload 16
    //   53: monitorexit
    //   54: aload_0
    //   55: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   58: astore 19
    //   60: aload 19
    //   62: monitorenter
    //   63: aload_0
    //   64: iconst_1
    //   65: putfield 63	com/ibm/mqtt/MqttBaseClient:outLockNotified	Z
    //   68: aload_0
    //   69: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   72: invokevirtual 238	java/lang/Object:notifyAll	()V
    //   75: aload 19
    //   77: monitorexit
    //   78: aload_0
    //   79: getfield 48	com/ibm/mqtt/MqttBaseClient:qos2PubsArrived	Ljava/util/Hashtable;
    //   82: invokevirtual 86	java/util/Hashtable:clear	()V
    //   85: aload_0
    //   86: getfield 57	com/ibm/mqtt/MqttBaseClient:retryQueue	Lcom/ibm/mqtt/MqttTimedEventQueue;
    //   89: invokevirtual 80	com/ibm/mqtt/MqttTimedEventQueue:resetTimedEventQueue	()V
    //   92: aload_0
    //   93: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   96: invokevirtual 85	com/ibm/mqtt/MqttHashTable:clear	()V
    //   99: aload_0
    //   100: getfield 43	com/ibm/mqtt/MqttBaseClient:cleanSession	Z
    //   103: ifeq +24 -> 127
    //   106: aload_0
    //   107: iconst_0
    //   108: putfield 43	com/ibm/mqtt/MqttBaseClient:cleanSession	Z
    //   111: aload_0
    //   112: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   115: ifnull +12 -> 127
    //   118: aload_0
    //   119: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   122: invokeinterface 113 1 0
    //   127: aload_0
    //   128: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   131: ifnull +16 -> 147
    //   134: aload_0
    //   135: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   138: astore 7
    //   140: aload 7
    //   142: invokeinterface 369 1 0
    //   147: return
    //   148: astore 9
    //   150: aload_0
    //   151: iconst_0
    //   152: invokevirtual 361	com/ibm/mqtt/MqttBaseClient:tcpipDisconnect	(Z)V
    //   155: aload_0
    //   156: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   159: astore 10
    //   161: aload 10
    //   163: monitorenter
    //   164: aload_0
    //   165: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   168: istore 12
    //   170: iload 12
    //   172: ifeq +13 -> 185
    //   175: aload_0
    //   176: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   179: ldc2_w 362
    //   182: invokevirtual 366	java/lang/Object:wait	(J)V
    //   185: aload 10
    //   187: monitorexit
    //   188: aload_0
    //   189: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   192: astore 13
    //   194: aload 13
    //   196: monitorenter
    //   197: aload_0
    //   198: iconst_1
    //   199: putfield 63	com/ibm/mqtt/MqttBaseClient:outLockNotified	Z
    //   202: aload_0
    //   203: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   206: invokevirtual 238	java/lang/Object:notifyAll	()V
    //   209: aload 13
    //   211: monitorexit
    //   212: aload_0
    //   213: getfield 48	com/ibm/mqtt/MqttBaseClient:qos2PubsArrived	Ljava/util/Hashtable;
    //   216: invokevirtual 86	java/util/Hashtable:clear	()V
    //   219: aload_0
    //   220: getfield 57	com/ibm/mqtt/MqttBaseClient:retryQueue	Lcom/ibm/mqtt/MqttTimedEventQueue;
    //   223: invokevirtual 80	com/ibm/mqtt/MqttTimedEventQueue:resetTimedEventQueue	()V
    //   226: aload_0
    //   227: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   230: invokevirtual 85	com/ibm/mqtt/MqttHashTable:clear	()V
    //   233: aload_0
    //   234: getfield 43	com/ibm/mqtt/MqttBaseClient:cleanSession	Z
    //   237: ifeq +24 -> 261
    //   240: aload_0
    //   241: iconst_0
    //   242: putfield 43	com/ibm/mqtt/MqttBaseClient:cleanSession	Z
    //   245: aload_0
    //   246: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   249: ifnull +12 -> 261
    //   252: aload_0
    //   253: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   256: invokeinterface 113 1 0
    //   261: aload_0
    //   262: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   265: ifnull +12 -> 277
    //   268: aload_0
    //   269: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   272: invokeinterface 369 1 0
    //   277: aload 9
    //   279: athrow
    //   280: astore_1
    //   281: aload_0
    //   282: iconst_0
    //   283: invokevirtual 361	com/ibm/mqtt/MqttBaseClient:tcpipDisconnect	(Z)V
    //   286: aload_0
    //   287: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   290: astore_2
    //   291: aload_2
    //   292: monitorenter
    //   293: aload_0
    //   294: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   297: istore 4
    //   299: iload 4
    //   301: ifeq +13 -> 314
    //   304: aload_0
    //   305: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   308: ldc2_w 362
    //   311: invokevirtual 366	java/lang/Object:wait	(J)V
    //   314: aload_2
    //   315: monitorexit
    //   316: aload_0
    //   317: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   320: astore 5
    //   322: aload 5
    //   324: monitorenter
    //   325: aload_0
    //   326: iconst_1
    //   327: putfield 63	com/ibm/mqtt/MqttBaseClient:outLockNotified	Z
    //   330: aload_0
    //   331: getfield 65	com/ibm/mqtt/MqttBaseClient:outLock	Ljava/lang/Object;
    //   334: invokevirtual 238	java/lang/Object:notifyAll	()V
    //   337: aload 5
    //   339: monitorexit
    //   340: aload_0
    //   341: getfield 48	com/ibm/mqtt/MqttBaseClient:qos2PubsArrived	Ljava/util/Hashtable;
    //   344: invokevirtual 86	java/util/Hashtable:clear	()V
    //   347: aload_0
    //   348: getfield 57	com/ibm/mqtt/MqttBaseClient:retryQueue	Lcom/ibm/mqtt/MqttTimedEventQueue;
    //   351: invokevirtual 80	com/ibm/mqtt/MqttTimedEventQueue:resetTimedEventQueue	()V
    //   354: aload_0
    //   355: getfield 41	com/ibm/mqtt/MqttBaseClient:outstandingQueue	Lcom/ibm/mqtt/MqttHashTable;
    //   358: invokevirtual 85	com/ibm/mqtt/MqttHashTable:clear	()V
    //   361: aload_0
    //   362: getfield 43	com/ibm/mqtt/MqttBaseClient:cleanSession	Z
    //   365: ifeq +24 -> 389
    //   368: aload_0
    //   369: iconst_0
    //   370: putfield 43	com/ibm/mqtt/MqttBaseClient:cleanSession	Z
    //   373: aload_0
    //   374: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   377: ifnull +12 -> 389
    //   380: aload_0
    //   381: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   384: invokeinterface 113 1 0
    //   389: aload_0
    //   390: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   393: ifnull -246 -> 147
    //   396: aload_0
    //   397: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   400: astore 7
    //   402: goto -262 -> 140
    //   405: astore_3
    //   406: aload_2
    //   407: monitorexit
    //   408: aload_3
    //   409: athrow
    //   410: astore 6
    //   412: aload 5
    //   414: monitorexit
    //   415: aload 6
    //   417: athrow
    //   418: astore 11
    //   420: aload 10
    //   422: monitorexit
    //   423: aload 11
    //   425: athrow
    //   426: astore 14
    //   428: aload 13
    //   430: monitorexit
    //   431: aload 14
    //   433: athrow
    //   434: astore 17
    //   436: aload 16
    //   438: monitorexit
    //   439: aload 17
    //   441: athrow
    //   442: astore 20
    //   444: aload 19
    //   446: monitorexit
    //   447: aload 20
    //   449: athrow
    //   450: astore 21
    //   452: goto -401 -> 51
    //   455: astore 15
    //   457: goto -272 -> 185
    //   460: astore 8
    //   462: goto -148 -> 314
    //
    // Exception table:
    //   from	to	target	type
    //   0	16	148	finally
    //   0	16	280	com/ibm/mqtt/MqttException
    //   293	299	405	finally
    //   304	314	405	finally
    //   314	316	405	finally
    //   406	408	405	finally
    //   325	340	410	finally
    //   412	415	410	finally
    //   164	170	418	finally
    //   175	185	418	finally
    //   185	188	418	finally
    //   420	423	418	finally
    //   197	212	426	finally
    //   428	431	426	finally
    //   30	36	434	finally
    //   41	51	434	finally
    //   51	54	434	finally
    //   436	439	434	finally
    //   63	78	442	finally
    //   444	447	442	finally
    //   41	51	450	java/lang/InterruptedException
    //   175	185	455	java/lang/InterruptedException
    //   304	314	460	java/lang/InterruptedException
  }

  protected MqttPubrel genPubRelPacket(int paramInt, boolean paramBoolean)
  {
    MqttPubrel localMqttPubrel = new MqttPubrel();
    localMqttPubrel.setMsgId(paramInt);
    localMqttPubrel.setDup(paramBoolean);
    return localMqttPubrel;
  }

  public int getRetry()
  {
    return this.retryPeriod / 1000;
  }

  protected byte[] getReturnedQoS(int paramInt)
  {
    MqttByteArray localMqttByteArray = (MqttByteArray)this.grantedQoS.remove(new Integer(paramInt));
    if (localMqttByteArray == null)
      return null;
    return localMqttByteArray.getByteArray();
  }

  protected void initialise(String paramString, MqttPersistence paramMqttPersistence, Class paramClass)
  {
    super.initialise(paramString, paramClass);
    this.retryPeriod = 10000;
    this.outstandingQueue = new MqttHashTable();
    this.retryQueue = new MqttTimedEventQueue(10, this);
    this.retryQueue.start();
    this.persistenceLayer = paramMqttPersistence;
  }

  protected abstract void notifyAck(int paramInt1, int paramInt2);

  public boolean outstanding(int paramInt)
  {
    synchronized (this.outstandingQueue)
    {
      boolean bool = this.outstandingQueue.containsKey(paramInt);
      return bool;
    }
  }

  public void process(MqttConnack paramMqttConnack)
  {
    MQeTrace.trace(this, (short)-30017, 2097152L, new Integer(paramMqttConnack.returnCode));
    super.process(paramMqttConnack);
    notifyAck(1, paramMqttConnack.returnCode);
  }

  public void process(MqttPuback paramMqttPuback)
  {
    MQeTrace.trace(this, (short)-30018, 2097152L, new Integer(paramMqttPuback.getMsgId()));
    messageAck(paramMqttPuback.getMsgId());
  }

  public void process(MqttPubcomp paramMqttPubcomp)
  {
    MQeTrace.trace(this, (short)-30019, 2097152L, new Integer(paramMqttPubcomp.getMsgId()));
    messageAck(paramMqttPubcomp.getMsgId());
  }

  // ERROR //
  public void process(MqttPublish paramMqttPublish)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual 427	com/ibm/mqtt/MqttPublish:getPayload	()[B
    //   4: ifnull +376 -> 380
    //   7: aload_1
    //   8: invokevirtual 427	com/ibm/mqtt/MqttPublish:getPayload	()[B
    //   11: arraylength
    //   12: istore_2
    //   13: aload_0
    //   14: sipush -30020
    //   17: ldc2_w 407
    //   20: aload_1
    //   21: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   24: invokestatic 180	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   27: aload_1
    //   28: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   31: invokestatic 180	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   34: new 430	java/lang/Boolean
    //   37: dup
    //   38: aload_1
    //   39: invokevirtual 433	com/ibm/mqtt/MqttPublish:isRetain	()Z
    //   42: invokespecial 435	java/lang/Boolean:<init>	(Z)V
    //   45: invokevirtual 436	java/lang/Boolean:toString	()Ljava/lang/String;
    //   48: iload_2
    //   49: invokestatic 180	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   52: invokestatic 439	com/ibm/mqtt/MQeTrace:trace	(Ljava/lang/Object;SJLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   55: aload_1
    //   56: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   59: istore_3
    //   60: iconst_0
    //   61: istore 4
    //   63: iload_3
    //   64: iconst_2
    //   65: if_icmpeq +23 -> 88
    //   68: aload_0
    //   69: aload_1
    //   70: getfield 442	com/ibm/mqtt/MqttPublish:topicName	Ljava/lang/String;
    //   73: aload_1
    //   74: invokevirtual 427	com/ibm/mqtt/MqttPublish:getPayload	()[B
    //   77: aload_1
    //   78: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   81: aload_1
    //   82: invokevirtual 433	com/ibm/mqtt/MqttPublish:isRetain	()Z
    //   85: invokevirtual 446	com/ibm/mqtt/MqttBaseClient:publishArrived	(Ljava/lang/String;[BIZ)V
    //   88: aload_1
    //   89: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   92: ifle +76 -> 168
    //   95: iload 4
    //   97: ifne +71 -> 168
    //   100: aload_1
    //   101: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   104: iconst_1
    //   105: if_icmpne +112 -> 217
    //   108: ldc_w 448
    //   111: astore 5
    //   113: aload_0
    //   114: sipush -30021
    //   117: ldc2_w 407
    //   120: aload 5
    //   122: new 157	java/lang/Integer
    //   125: dup
    //   126: aload_1
    //   127: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   130: invokespecial 160	java/lang/Integer:<init>	(I)V
    //   133: invokestatic 451	com/ibm/mqtt/MQeTrace:trace	(Ljava/lang/Object;SJLjava/lang/Object;Ljava/lang/Object;)V
    //   136: aload_1
    //   137: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   140: iconst_1
    //   141: if_icmpne +84 -> 225
    //   144: new 418	com/ibm/mqtt/MqttPuback
    //   147: dup
    //   148: invokespecial 452	com/ibm/mqtt/MqttPuback:<init>	()V
    //   151: astore 6
    //   153: aload 6
    //   155: aload_1
    //   156: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   159: invokevirtual 453	com/ibm/mqtt/MqttPuback:setMsgId	(I)V
    //   162: aload_0
    //   163: aload 6
    //   165: invokevirtual 295	com/ibm/mqtt/MqttBaseClient:writePacket	(Lcom/ibm/mqtt/MqttPacket;)V
    //   168: return
    //   169: astore 18
    //   171: getstatic 459	java/lang/System:out	Ljava/io/PrintStream;
    //   174: new 297	java/lang/StringBuffer
    //   177: dup
    //   178: invokespecial 298	java/lang/StringBuffer:<init>	()V
    //   181: ldc_w 461
    //   184: invokevirtual 304	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   187: aload_1
    //   188: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   191: invokevirtual 307	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   194: ldc_w 463
    //   197: invokevirtual 304	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   200: invokevirtual 309	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   203: invokevirtual 468	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   206: aload 18
    //   208: invokevirtual 471	java/lang/Exception:printStackTrace	()V
    //   211: iconst_1
    //   212: istore 4
    //   214: goto -126 -> 88
    //   217: ldc_w 473
    //   220: astore 5
    //   222: goto -109 -> 113
    //   225: aload_0
    //   226: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   229: astore 9
    //   231: aload 9
    //   233: ifnull +54 -> 287
    //   236: aload_0
    //   237: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   240: astore 15
    //   242: aload 15
    //   244: monitorenter
    //   245: aload_1
    //   246: invokevirtual 474	com/ibm/mqtt/MqttPublish:toBytes	()[B
    //   249: astore 17
    //   251: aload_1
    //   252: invokevirtual 427	com/ibm/mqtt/MqttPublish:getPayload	()[B
    //   255: ifnull +14 -> 269
    //   258: aload 17
    //   260: aload_1
    //   261: invokevirtual 427	com/ibm/mqtt/MqttPublish:getPayload	()[B
    //   264: invokestatic 285	com/ibm/mqtt/MqttUtils:concatArray	([B[B)[B
    //   267: astore 17
    //   269: aload_0
    //   270: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   273: aload_1
    //   274: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   277: aload 17
    //   279: invokeinterface 477 3 0
    //   284: aload 15
    //   286: monitorexit
    //   287: aload_0
    //   288: getfield 48	com/ibm/mqtt/MqttBaseClient:qos2PubsArrived	Ljava/util/Hashtable;
    //   291: aload_1
    //   292: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   295: invokestatic 180	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   298: aload_1
    //   299: invokevirtual 183	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   302: pop
    //   303: new 479	com/ibm/mqtt/MqttPubrec
    //   306: dup
    //   307: invokespecial 480	com/ibm/mqtt/MqttPubrec:<init>	()V
    //   310: astore 11
    //   312: aload 11
    //   314: aload_1
    //   315: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   318: invokevirtual 481	com/ibm/mqtt/MqttPubrec:setMsgId	(I)V
    //   321: aload_0
    //   322: aload 11
    //   324: invokevirtual 295	com/ibm/mqtt/MqttBaseClient:writePacket	(Lcom/ibm/mqtt/MqttPacket;)V
    //   327: return
    //   328: astore 12
    //   330: return
    //   331: astore 16
    //   333: aload 15
    //   335: monitorexit
    //   336: aload 16
    //   338: athrow
    //   339: astore 14
    //   341: aload 14
    //   343: athrow
    //   344: astore 13
    //   346: new 71	com/ibm/mqtt/MqttPersistenceException
    //   349: dup
    //   350: new 297	java/lang/StringBuffer
    //   353: dup
    //   354: invokespecial 298	java/lang/StringBuffer:<init>	()V
    //   357: ldc_w 483
    //   360: invokevirtual 304	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   363: aload_1
    //   364: invokevirtual 158	com/ibm/mqtt/MqttPublish:getMsgId	()I
    //   367: invokevirtual 307	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   370: invokevirtual 309	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   373: invokespecial 312	com/ibm/mqtt/MqttPersistenceException:<init>	(Ljava/lang/String;)V
    //   376: athrow
    //   377: astore 7
    //   379: return
    //   380: iconst_0
    //   381: istore_2
    //   382: goto -369 -> 13
    //   385: astore 8
    //   387: return
    //
    // Exception table:
    //   from	to	target	type
    //   68	88	169	java/lang/Exception
    //   321	327	328	java/lang/Exception
    //   245	269	331	finally
    //   269	287	331	finally
    //   333	336	331	finally
    //   236	245	339	com/ibm/mqtt/MqttPersistenceException
    //   336	339	339	com/ibm/mqtt/MqttPersistenceException
    //   236	245	344	java/lang/Exception
    //   336	339	344	java/lang/Exception
    //   162	168	377	java/lang/Exception
    //   225	231	385	com/ibm/mqtt/MqttPersistenceException
    //   287	321	385	com/ibm/mqtt/MqttPersistenceException
    //   321	327	385	com/ibm/mqtt/MqttPersistenceException
    //   341	344	385	com/ibm/mqtt/MqttPersistenceException
    //   346	377	385	com/ibm/mqtt/MqttPersistenceException
  }

  public void process(MqttPubrec paramMqttPubrec)
  {
    MQeTrace.trace(this, (short)-30022, 2097152L, new Integer(paramMqttPubrec.getMsgId()));
    MqttRetry localMqttRetry = (MqttRetry)this.outstandingQueue.get(paramMqttPubrec.getMsgId());
    if ((localMqttRetry != null) && (localMqttRetry.getMsgType() == 6));
    MqttPacket localMqttPacket;
    do
    {
      return;
      localMqttPacket = messageAck(paramMqttPubrec.getMsgId());
    }
    while (localMqttPacket == null);
    try
    {
      writePacket(localMqttPacket);
      return;
    }
    catch (Exception localException)
    {
    }
  }

  // ERROR //
  public void process(MqttPubrel paramMqttPubrel)
  {
    // Byte code:
    //   0: aload_0
    //   1: sipush -30023
    //   4: ldc2_w 407
    //   7: new 157	java/lang/Integer
    //   10: dup
    //   11: aload_1
    //   12: invokevirtual 170	com/ibm/mqtt/MqttPubrel:getMsgId	()I
    //   15: invokespecial 160	java/lang/Integer:<init>	(I)V
    //   18: invokestatic 209	com/ibm/mqtt/MQeTrace:trace	(Ljava/lang/Object;SJLjava/lang/Object;)V
    //   21: aload_0
    //   22: getfield 48	com/ibm/mqtt/MqttBaseClient:qos2PubsArrived	Ljava/util/Hashtable;
    //   25: aload_1
    //   26: invokevirtual 170	com/ibm/mqtt/MqttPubrel:getMsgId	()I
    //   29: invokestatic 180	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   32: invokevirtual 488	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   35: checkcast 152	com/ibm/mqtt/MqttPublish
    //   38: astore_2
    //   39: iconst_0
    //   40: istore_3
    //   41: aload_2
    //   42: ifnull +139 -> 181
    //   45: aload_0
    //   46: aload_2
    //   47: getfield 442	com/ibm/mqtt/MqttPublish:topicName	Ljava/lang/String;
    //   50: aload_2
    //   51: invokevirtual 427	com/ibm/mqtt/MqttPublish:getPayload	()[B
    //   54: aload_2
    //   55: invokevirtual 428	com/ibm/mqtt/MqttPublish:getQos	()I
    //   58: aload_2
    //   59: invokevirtual 433	com/ibm/mqtt/MqttPublish:isRetain	()Z
    //   62: invokevirtual 446	com/ibm/mqtt/MqttBaseClient:publishArrived	(Ljava/lang/String;[BIZ)V
    //   65: iconst_0
    //   66: istore 4
    //   68: iload 4
    //   70: ifne +92 -> 162
    //   73: aload_0
    //   74: getfield 48	com/ibm/mqtt/MqttBaseClient:qos2PubsArrived	Ljava/util/Hashtable;
    //   77: aload_1
    //   78: invokevirtual 170	com/ibm/mqtt/MqttPubrel:getMsgId	()I
    //   81: invokestatic 180	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   84: invokevirtual 381	java/util/Hashtable:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   87: pop
    //   88: aload_0
    //   89: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   92: astore 9
    //   94: aconst_null
    //   95: astore 6
    //   97: aload 9
    //   99: ifnull +28 -> 127
    //   102: aload_0
    //   103: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   106: astore 10
    //   108: aload 10
    //   110: monitorenter
    //   111: aload_0
    //   112: getfield 50	com/ibm/mqtt/MqttBaseClient:persistenceLayer	Lcom/ibm/mqtt/MqttPersistence;
    //   115: aload_1
    //   116: invokevirtual 170	com/ibm/mqtt/MqttPubrel:getMsgId	()I
    //   119: invokeinterface 491 2 0
    //   124: aload 10
    //   126: monitorexit
    //   127: new 424	com/ibm/mqtt/MqttPubcomp
    //   130: dup
    //   131: invokespecial 492	com/ibm/mqtt/MqttPubcomp:<init>	()V
    //   134: astore 7
    //   136: aload 7
    //   138: aload_1
    //   139: invokevirtual 170	com/ibm/mqtt/MqttPubrel:getMsgId	()I
    //   142: invokevirtual 493	com/ibm/mqtt/MqttPubcomp:setMsgId	(I)V
    //   145: aload_0
    //   146: aload 7
    //   148: invokevirtual 295	com/ibm/mqtt/MqttBaseClient:writePacket	(Lcom/ibm/mqtt/MqttPacket;)V
    //   151: aload 6
    //   153: ifnull +9 -> 162
    //   156: aload_0
    //   157: aload 6
    //   159: invokevirtual 497	com/ibm/mqtt/MqttBaseClient:setRegisteredThrowable	(Ljava/lang/Throwable;)V
    //   162: return
    //   163: astore 12
    //   165: iconst_1
    //   166: istore_3
    //   167: getstatic 459	java/lang/System:out	Ljava/io/PrintStream;
    //   170: ldc_w 499
    //   173: invokevirtual 468	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   176: aload 12
    //   178: invokevirtual 471	java/lang/Exception:printStackTrace	()V
    //   181: iload_3
    //   182: istore 4
    //   184: goto -116 -> 68
    //   187: astore 11
    //   189: aload 10
    //   191: monitorexit
    //   192: aload 11
    //   194: athrow
    //   195: astore 6
    //   197: goto -70 -> 127
    //   200: astore 8
    //   202: goto -51 -> 151
    //
    // Exception table:
    //   from	to	target	type
    //   45	65	163	java/lang/Exception
    //   111	127	187	finally
    //   189	192	187	finally
    //   88	94	195	com/ibm/mqtt/MqttPersistenceException
    //   102	111	195	com/ibm/mqtt/MqttPersistenceException
    //   192	195	195	com/ibm/mqtt/MqttPersistenceException
    //   145	151	200	java/lang/Exception
  }

  public void process(MqttSuback paramMqttSuback)
  {
    MQeTrace.trace(this, (short)-30024, 2097152L, new Integer(paramMqttSuback.getMsgId()));
    this.grantedQoS.put(new Integer(paramMqttSuback.getMsgId()), new MqttByteArray(paramMqttSuback.TopicsQoS));
    messageAck(paramMqttSuback.getMsgId());
  }

  public void process(MqttUnsuback paramMqttUnsuback)
  {
    MQeTrace.trace(this, (short)-30025, 2097152L, new Integer(paramMqttUnsuback.getMsgId()));
    messageAck(paramMqttUnsuback.getMsgId());
  }

  protected int publish(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
    throws MqttException, MqttPersistenceException
  {
    if (paramInt > 0);
    for (int i = nextMsgId(); ; i = 0)
    {
      sendPacket(genPublishPacket(i, paramInt, paramString, paramArrayOfByte, paramBoolean, false));
      MQeTrace.trace(this, (short)-30026, 2097152L, new Integer(i), new Integer(paramInt), new Boolean(paramBoolean));
      return i;
    }
  }

  protected abstract void publishArrived(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
    throws Exception;

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: sipush -30027
    //   4: ldc2_w 407
    //   7: invokestatic 534	com/ibm/mqtt/MQeTrace:trace	(Ljava/lang/Object;SJ)V
    //   10: aload_0
    //   11: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   14: astore_1
    //   15: aload_1
    //   16: monitorenter
    //   17: aload_0
    //   18: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   21: ifne +29 -> 50
    //   24: aload_0
    //   25: getfield 61	com/ibm/mqtt/MqttBaseClient:terminated	Z
    //   28: istore 16
    //   30: iload 16
    //   32: ifne +18 -> 50
    //   35: aload_0
    //   36: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   39: invokevirtual 276	java/lang/Object:wait	()V
    //   42: goto -25 -> 17
    //   45: astore 17
    //   47: goto -30 -> 17
    //   50: aload_1
    //   51: monitorexit
    //   52: aload_0
    //   53: getfield 61	com/ibm/mqtt/MqttBaseClient:terminated	Z
    //   56: ifne +199 -> 255
    //   59: aload_0
    //   60: getfield 166	com/ibm/mqtt/MqttBaseClient:retryPeriod	I
    //   63: i2l
    //   64: pop2
    //   65: aload_0
    //   66: getfield 61	com/ibm/mqtt/MqttBaseClient:terminated	Z
    //   69: ifne +186 -> 255
    //   72: aload_0
    //   73: invokevirtual 536	com/ibm/mqtt/MqttBaseClient:process	()V
    //   76: aload_0
    //   77: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   80: astore 8
    //   82: aload 8
    //   84: monitorenter
    //   85: aload_0
    //   86: invokevirtual 269	com/ibm/mqtt/MqttBaseClient:isSocketConnected	()Z
    //   89: ifne +152 -> 241
    //   92: aload_0
    //   93: getfield 61	com/ibm/mqtt/MqttBaseClient:terminated	Z
    //   96: istore 10
    //   98: iload 10
    //   100: ifne +141 -> 241
    //   103: aload_0
    //   104: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   107: invokevirtual 276	java/lang/Object:wait	()V
    //   110: goto -25 -> 85
    //   113: astore 11
    //   115: goto -30 -> 85
    //   118: astore_2
    //   119: aload_1
    //   120: monitorexit
    //   121: aload_2
    //   122: athrow
    //   123: astore 12
    //   125: aload_0
    //   126: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   129: astore 13
    //   131: aload 13
    //   133: monitorenter
    //   134: aload_0
    //   135: iconst_1
    //   136: invokevirtual 361	com/ibm/mqtt/MqttBaseClient:tcpipDisconnect	(Z)V
    //   139: aload_0
    //   140: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   143: invokevirtual 198	java/lang/Object:notify	()V
    //   146: aload 13
    //   148: monitorexit
    //   149: aload_0
    //   150: invokevirtual 539	com/ibm/mqtt/MqttBaseClient:isConnected	()Z
    //   153: ifeq -77 -> 76
    //   156: ldc2_w 540
    //   159: invokestatic 546	java/lang/Thread:sleep	(J)V
    //   162: aload_0
    //   163: aconst_null
    //   164: invokevirtual 497	com/ibm/mqtt/MqttBaseClient:setRegisteredThrowable	(Ljava/lang/Throwable;)V
    //   167: getstatic 459	java/lang/System:out	Ljava/io/PrintStream;
    //   170: ldc_w 548
    //   173: invokevirtual 468	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   176: new 550	com/ibm/mqtt/MqttReconn
    //   179: dup
    //   180: aload_0
    //   181: invokespecial 553	com/ibm/mqtt/MqttReconn:<init>	(Lcom/ibm/mqtt/MqttBaseClient;)V
    //   184: invokevirtual 554	com/ibm/mqtt/MqttReconn:start	()V
    //   187: goto -111 -> 76
    //   190: astore 14
    //   192: aload 13
    //   194: monitorexit
    //   195: aload 14
    //   197: athrow
    //   198: astore 5
    //   200: aload_0
    //   201: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   204: astore 6
    //   206: aload 6
    //   208: monitorenter
    //   209: aload_0
    //   210: iconst_1
    //   211: invokevirtual 361	com/ibm/mqtt/MqttBaseClient:tcpipDisconnect	(Z)V
    //   214: aload_0
    //   215: getfield 55	com/ibm/mqtt/MqttBaseClient:readerControl	Ljava/lang/Object;
    //   218: invokevirtual 198	java/lang/Object:notify	()V
    //   221: aload 6
    //   223: monitorexit
    //   224: aload_0
    //   225: aload 5
    //   227: invokevirtual 497	com/ibm/mqtt/MqttBaseClient:setRegisteredThrowable	(Ljava/lang/Throwable;)V
    //   230: goto -154 -> 76
    //   233: astore 7
    //   235: aload 6
    //   237: monitorexit
    //   238: aload 7
    //   240: athrow
    //   241: aload 8
    //   243: monitorexit
    //   244: goto -179 -> 65
    //   247: astore 9
    //   249: aload 8
    //   251: monitorexit
    //   252: aload 9
    //   254: athrow
    //   255: aload_0
    //   256: sipush -30028
    //   259: ldc2_w 407
    //   262: invokestatic 534	com/ibm/mqtt/MQeTrace:trace	(Ljava/lang/Object;SJ)V
    //   265: return
    //   266: astore 15
    //   268: goto -106 -> 162
    //
    // Exception table:
    //   from	to	target	type
    //   35	42	45	java/lang/InterruptedException
    //   103	110	113	java/lang/InterruptedException
    //   17	30	118	finally
    //   35	42	118	finally
    //   50	52	118	finally
    //   119	121	118	finally
    //   72	76	123	java/lang/Exception
    //   134	149	190	finally
    //   192	195	190	finally
    //   72	76	198	java/lang/Throwable
    //   209	224	233	finally
    //   235	238	233	finally
    //   85	98	247	finally
    //   103	110	247	finally
    //   241	244	247	finally
    //   249	252	247	finally
    //   156	162	266	java/lang/InterruptedException
  }

  protected void setConnectionState(boolean paramBoolean)
  {
    try
    {
      super.setConnectionState(paramBoolean);
      this.retryQueue.canDeliverEvents(paramBoolean);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setRetry(int paramInt)
  {
    if (paramInt < 10)
      paramInt = 10;
    this.retryPeriod = Math.abs(paramInt * 1000);
  }

  protected int subscribe(String[] paramArrayOfString, int[] paramArrayOfInt)
    throws MqttException
  {
    int i = nextMsgId();
    byte[] arrayOfByte = new byte[paramArrayOfInt.length];
    this.grantedQoS.remove(new Integer(i));
    for (int j = 0; j < paramArrayOfInt.length; j++)
      arrayOfByte[j] = ((byte)paramArrayOfInt[j]);
    MqttSubscribe localMqttSubscribe = new MqttSubscribe();
    localMqttSubscribe.setMsgId(i);
    localMqttSubscribe.setQos(1);
    localMqttSubscribe.topics = paramArrayOfString;
    localMqttSubscribe.topicsQoS = arrayOfByte;
    localMqttSubscribe.setDup(false);
    MQeTrace.trace(this, (short)-30029, 2097152L, new Integer(i));
    sendPacket(localMqttSubscribe);
    return i;
  }

  protected void terminate()
  {
    synchronized (this.readerControl)
    {
      this.terminated = true;
      this.readerControl.notify();
      if (this.retryQueue != null)
        this.retryQueue.close();
      return;
    }
  }

  protected int unsubscribe(String[] paramArrayOfString)
    throws MqttException
  {
    int i = nextMsgId();
    MqttUnsubscribe localMqttUnsubscribe = new MqttUnsubscribe();
    localMqttUnsubscribe.setMsgId(i);
    localMqttUnsubscribe.setQos(1);
    localMqttUnsubscribe.topics = paramArrayOfString;
    localMqttUnsubscribe.setDup(false);
    MQeTrace.trace(this, (short)-30030, 2097152L, new Integer(i));
    sendPacket(localMqttUnsubscribe);
    return i;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttBaseClient
 * JD-Core Version:    0.6.2
 */