package com.ibm.mqtt;

public class MqttSuback extends MqttPacket
{
  public byte[] TopicsQoS;

  public MqttSuback()
  {
    setMsgType((short)9);
  }

  public MqttSuback(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)9);
    setMsgId(MqttUtils.toShort(paramArrayOfByte, paramInt));
    this.TopicsQoS = MqttUtils.SliceByteArray(paramArrayOfByte, paramInt + 2, paramArrayOfByte.length - (paramInt + 2));
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    int i = 0;
    this.message = new byte[3 + this.TopicsQoS.length];
    this.message[0] = super.toBytes()[0];
    int j = getMsgId();
    this.message[1] = ((byte)(j / 256));
    this.message[2] = ((byte)(j % 256));
    while (i < this.TopicsQoS.length)
    {
      this.message[(i + 3)] = this.TopicsQoS[i];
      i++;
    }
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttSuback
 * JD-Core Version:    0.6.2
 */