package com.ibm.mqtt;

public class MqttClient extends MqttBaseClient
  implements IMqttClient
{
  private MqttAdvancedCallback advCallbackHandler = null;
  private int conRetCode;
  private Object connAckLock = new Object();
  private String connection;
  private boolean isAppConnected = false;
  private MqttPersistence persistenceLayer = null;
  private Thread reader = null;
  private MqttSimpleCallback simpleCallbackHandler = null;
  private Class traceClass = null;

  protected MqttClient()
  {
  }

  public MqttClient(String paramString)
    throws MqttException
  {
    this(paramString, null);
  }

  public MqttClient(String paramString, MqttPersistence paramMqttPersistence)
    throws MqttException
  {
    initialise(paramString, paramMqttPersistence);
  }

  public static final IMqttClient createMqttClient(String paramString, MqttPersistence paramMqttPersistence)
    throws MqttException
  {
    return new MqttClient(paramString, paramMqttPersistence);
  }

  private void invalidApiInvocation()
    throws MqttException
  {
    throw new MqttException("MqttClient API called in a callback method! Use a different thread.");
  }

  private Class loadLocalBindings()
    throws MqttException
  {
    try
    {
      Class localClass2 = Class.forName("com.ibm.mqtt.local.MqttLocalBindingV2");
      localObject = localClass2;
      i = 1;
      if (i == 0);
      try
      {
        Class localClass1 = Class.forName("com.ibm.mqtt.local.MqttLocalBindingV1");
        localObject = localClass1;
        return localObject;
      }
      catch (ClassNotFoundException localClassNotFoundException2)
      {
        MqttException localMqttException = new MqttException("LocalBinding unavailable: Microbroker classes not found");
        localMqttException.initCause(localClassNotFoundException2);
        throw localMqttException;
      }
    }
    catch (ClassNotFoundException localClassNotFoundException1)
    {
      while (true)
      {
        Object localObject = null;
        int i = 0;
      }
    }
  }

  private Class loadTcpBindings()
    throws MqttException
  {
    try
    {
      Class localClass2 = Class.forName("com.ibm.mqtt.j2se.MqttJavaNetSocket");
      localObject = localClass2;
      i = 1;
      if (i == 0);
      try
      {
        Class localClass1 = Class.forName("com.ibm.mqtt.midp.MqttMidpSocket");
        localObject = localClass1;
        return localObject;
      }
      catch (ClassNotFoundException localClassNotFoundException2)
      {
        MqttException localMqttException = new MqttException("Cannot locate a J2SE Socket or J2ME StreamConnection class");
        localMqttException.initCause(localClassNotFoundException2);
        throw localMqttException;
      }
    }
    catch (ClassNotFoundException localClassNotFoundException1)
    {
      while (true)
      {
        Object localObject = null;
        int i = 0;
      }
    }
  }

  private void start(Class paramClass)
    throws MqttException
  {
    try
    {
      this.reader = new Thread(this);
      this.reader.start();
      super.setRetry(120);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      throw new MqttException(localException);
    }
  }

  public void connect(String paramString, boolean paramBoolean, short paramShort)
    throws MqttException, MqttPersistenceException, MqttBrokerUnavailableException, MqttNotConnectedException
  {
    connect(paramString, paramBoolean, paramShort, null, 0, null, false);
  }

  public void connect(String paramString1, boolean paramBoolean1, short paramShort, String paramString2, int paramInt, String paramString3, boolean paramBoolean2)
    throws MqttException, MqttPersistenceException, MqttBrokerUnavailableException, MqttNotConnectedException
  {
    MQeTrace.trace(this, (short)-30002, 1048580L);
    if ((!this.isAppConnected) || (!isSocketConnected()))
      synchronized (this.connAckLock)
      {
        this.conRetCode = -1;
        super.connect(paramString1, paramBoolean1, false, paramShort, paramString2, paramInt, paramString3, paramBoolean2);
      }
    try
    {
      this.connAckLock.wait(1000 * getRetry());
      label70: int i = this.conRetCode;
      MQeTrace.trace(this, (short)-30003, 1048584L);
      switch (i)
      {
      default:
        tcpipDisconnect(true);
        throw new MqttNotConnectedException("WMQTT " + msgTypes[2] + " not received");
        localObject2 = finally;
        throw localObject2;
      case 0:
        this.isAppConnected = true;
        return;
      case 1:
        MqttConnect localMqttConnect = new MqttConnect();
        throw new MqttException("WMQTT protocol name or version not supported:" + localMqttConnect.ProtoName + " Version:" + localMqttConnect.ProtoVersion);
      case 2:
        throw new MqttException("WMQTT ClientId is invalid");
      case 3:
      }
      throw new MqttBrokerUnavailableException("WMQTT Broker is unavailable");
    }
    catch (InterruptedException localInterruptedException)
    {
      break label70;
    }
  }

  protected void connectionLost()
    throws Exception
  {
    MQeTrace.trace(this, (short)-30004, 2097152L);
    super.connectionLost();
    if (this.simpleCallbackHandler != null)
    {
      this.simpleCallbackHandler.connectionLost();
      return;
    }
    throw new MqttNotConnectedException("WMQtt Connection Lost");
  }

  public void disconnect()
    throws MqttPersistenceException
  {
    MQeTrace.trace(this, (short)-30005, 1048580L);
    if (this.isAppConnected)
    {
      super.disconnect();
      this.isAppConnected = false;
    }
    MQeTrace.trace(this, (short)-30006, 1048584L);
  }

  public String getConnection()
  {
    return this.connection;
  }

  public MqttPersistence getPersistence()
  {
    return this.persistenceLayer;
  }

  protected void initialise(String paramString, MqttPersistence paramMqttPersistence)
    throws MqttException
  {
    this.connection = paramString;
    this.persistenceLayer = paramMqttPersistence;
    Class localClass;
    if (paramString.startsWith("local://"))
      localClass = loadLocalBindings();
    while (true)
    {
      super.initialise(this.connection, this.persistenceLayer, localClass);
      try
      {
        this.traceClass = Class.forName("com.ibm.mqtt.trace.MQeTraceToBinaryFile");
        start(localClass);
        return;
        if (paramString.startsWith("tcp://"))
        {
          localClass = loadTcpBindings();
          this.connection = paramString.replace('@', ':');
          continue;
        }
        throw new MqttException("Unrecognised connection method:" + paramString);
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        while (true)
          this.traceClass = null;
      }
    }
  }

  protected void notifyAck(int paramInt1, int paramInt2)
  {
    switch (paramInt1)
    {
    case 2:
    case 4:
    case 5:
    case 7:
    case 9:
    default:
    case 1:
    case 8:
    case 10:
    case 3:
    case 6:
    }
    do
    {
      do
      {
        do
        {
          return;
          synchronized (this.connAckLock)
          {
            this.conRetCode = paramInt2;
            this.connAckLock.notifyAll();
            return;
          }
        }
        while (this.advCallbackHandler == null);
        this.advCallbackHandler.subscribed(paramInt2, getReturnedQoS(paramInt2));
        return;
      }
      while (this.advCallbackHandler == null);
      this.advCallbackHandler.unsubscribed(paramInt2);
      return;
    }
    while (this.advCallbackHandler == null);
    this.advCallbackHandler.published(paramInt2);
  }

  public void ping()
    throws MqttException
  {
    if (Thread.currentThread().equals(this.reader))
      invalidApiInvocation();
    pingOut();
  }

  public int publish(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
    throws MqttNotConnectedException, MqttPersistenceException, MqttException, IllegalArgumentException
  {
    MQeTrace.trace(this, (short)-30007, 1048580L);
    if (paramString == null)
      throw new IllegalArgumentException("NULL topic");
    if (paramArrayOfByte == null)
      throw new IllegalArgumentException("NULL message");
    if ((paramString.indexOf('#') > -1) || (paramString.indexOf('+') > -1))
      throw new IllegalArgumentException("Topic contains '#' or '+'");
    if (Thread.currentThread().equals(this.reader))
      invalidApiInvocation();
    anyErrors();
    int i = super.publish(paramString, paramArrayOfByte, paramInt, paramBoolean);
    MQeTrace.trace(this, (short)-30008, 1048584L);
    return i;
  }

  protected void publishArrived(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
    throws Exception
  {
    String str1 = MqttUtils.toHexString(paramArrayOfByte, 0, 30);
    if (paramString.length() > 30);
    for (String str2 = paramString.substring(0, 31); ; str2 = paramString)
    {
      MQeTrace.trace(this, (short)-30009, 1048580L, Integer.toString(paramString.length()), str2, Integer.toString(paramArrayOfByte.length), str1);
      if (this.simpleCallbackHandler != null)
        this.simpleCallbackHandler.publishArrived(paramString, paramArrayOfByte, paramInt, paramBoolean);
      MQeTrace.trace(this, (short)-30010, 1048584L);
      return;
    }
  }

  public void registerAdvancedHandler(MqttAdvancedCallback paramMqttAdvancedCallback)
  {
    this.advCallbackHandler = paramMqttAdvancedCallback;
    this.simpleCallbackHandler = paramMqttAdvancedCallback;
  }

  public void registerSimpleHandler(MqttSimpleCallback paramMqttSimpleCallback)
  {
    this.simpleCallbackHandler = paramMqttSimpleCallback;
  }

  public void startTrace()
    throws MqttException
  {
    if (this.traceClass != null)
    {
      MQeTrace.setFilter(-1L);
      try
      {
        MQeTrace.setHandler((MQeTraceHandler)this.traceClass.newInstance());
        return;
      }
      catch (Exception localException)
      {
        throw new MqttException(localException);
      }
    }
    throw new MqttException("Trace classes (com.ibm.mqtt.trace.*) not found.\nCheck they are in wmqtt.jar.");
  }

  public void stopTrace()
  {
    MQeTrace.setFilter(0L);
    MQeTrace.setHandler(null);
  }

  public int subscribe(String[] paramArrayOfString, int[] paramArrayOfInt)
    throws MqttNotConnectedException, MqttException, IllegalArgumentException
  {
    MQeTrace.trace(this, (short)-30011, 1048580L);
    if (paramArrayOfString == null)
      throw new IllegalArgumentException("NULL topic array");
    if (paramArrayOfInt == null)
      throw new IllegalArgumentException("NULL requested QoS array");
    if (paramArrayOfString.length != paramArrayOfInt.length)
      throw new IllegalArgumentException("Array lengths unequal. Topics:" + paramArrayOfString.length + ", QoS:" + paramArrayOfInt.length);
    for (int i = 0; i < paramArrayOfString.length; i++)
      if (paramArrayOfString[i] == null)
        throw new IllegalArgumentException("NULL topic in topic array at index " + i);
    if (Thread.currentThread().equals(this.reader))
      invalidApiInvocation();
    int j = 0;
    if (j < paramArrayOfInt.length)
    {
      if (paramArrayOfInt[j] > 2)
        paramArrayOfInt[j] = 2;
      while (true)
      {
        j++;
        break;
        if (paramArrayOfInt[j] < 0)
          paramArrayOfInt[j] = 0;
      }
    }
    anyErrors();
    int k = super.subscribe(paramArrayOfString, paramArrayOfInt);
    MQeTrace.trace(this, (short)-30012, 1048584L);
    return k;
  }

  public void terminate()
  {
    terminate(true);
  }

  public void terminate(boolean paramBoolean)
  {
    if ((this.isAppConnected) && (paramBoolean));
    try
    {
      disconnect();
      super.terminate();
    }
    catch (Exception localException)
    {
      try
      {
        this.reader.join();
        return;
        localException = localException;
      }
      catch (InterruptedException localInterruptedException)
      {
      }
    }
  }

  public int unsubscribe(String[] paramArrayOfString)
    throws MqttNotConnectedException, MqttException, IllegalArgumentException
  {
    MQeTrace.trace(this, (short)-30013, 1048580L);
    if (paramArrayOfString == null)
      throw new IllegalArgumentException("NULL topic array");
    for (int i = 0; i < paramArrayOfString.length; i++)
      if (paramArrayOfString[i] == null)
        throw new IllegalArgumentException("NULL topic in topic array at index " + i);
    if (Thread.currentThread().equals(this.reader))
      invalidApiInvocation();
    anyErrors();
    int j = super.unsubscribe(paramArrayOfString);
    MQeTrace.trace(this, (short)-30014, 1048584L);
    return j;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttClient
 * JD-Core Version:    0.6.2
 */