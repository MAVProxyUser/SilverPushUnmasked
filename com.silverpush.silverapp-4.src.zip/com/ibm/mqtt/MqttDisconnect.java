package com.ibm.mqtt;

public class MqttDisconnect extends MqttPacket
{
  public MqttDisconnect()
  {
    setMsgType((short)14);
  }

  public MqttDisconnect(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
    setMsgType((short)14);
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
  }

  public byte[] toBytes()
  {
    this.message = new byte[1];
    this.message[0] = super.toBytes()[0];
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttDisconnect
 * JD-Core Version:    0.6.2
 */