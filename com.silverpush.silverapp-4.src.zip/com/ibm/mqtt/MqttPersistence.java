package com.ibm.mqtt;

public abstract interface MqttPersistence
{
  public abstract void addReceivedMessage(int paramInt, byte[] paramArrayOfByte)
    throws MqttPersistenceException;

  public abstract void addSentMessage(int paramInt, byte[] paramArrayOfByte)
    throws MqttPersistenceException;

  public abstract void close();

  public abstract void delReceivedMessage(int paramInt)
    throws MqttPersistenceException;

  public abstract void delSentMessage(int paramInt)
    throws MqttPersistenceException;

  public abstract byte[][] getAllReceivedMessages()
    throws MqttPersistenceException;

  public abstract byte[][] getAllSentMessages()
    throws MqttPersistenceException;

  public abstract void open(String paramString1, String paramString2)
    throws MqttPersistenceException;

  public abstract void reset()
    throws MqttPersistenceException;

  public abstract void updSentMessage(int paramInt, byte[] paramArrayOfByte)
    throws MqttPersistenceException;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPersistence
 * JD-Core Version:    0.6.2
 */