package com.ibm.mqtt.trace;

import com.ibm.mqtt.MQe;
import com.ibm.mqtt.MQeTraceHandler;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public abstract class MQeTraceToBinary
  implements MQeTraceHandler
{
  private static final int ASCII_CHARS_IN_MAX_LENGTH_STRING = 20480;
  static final short DATA_FORMAT_VERSION = 1;
  private static final boolean DEBUG = false;
  public static final int UNICODE_CHARS_IN_MAX_LENGTH_STRING = 10240;
  static final int V1_MAGIC = -17978438;
  static String[] prefixes = { "com.ibm.mqe.adapters.MQe", "a:", "com.ibm.mqe.administration.MQe", "b:", "com.ibm.mqe.attributes.MQe", "c:", "com.ibm.mqe.bindings.MQe", "d:", "com.ibm.mqe.communications.MQe", "e:", "com.ibm.mqe.messagestore.MQe", "f:", "com.ibm.mqe.mqbridge.MQe", "g:", "com.ibm.mqe.registry.MQe", "h:", "com.ibm.mqe.server.MQe", "i:", "com.ibm.mqe.mqemqmessage.MQe", "j:", "com.ibm.mqe.trace.MQe", "k:", "com.ibm.mqe.validation.MQe", "l:", "com.ibm.mqe.MQe", "m:", "com.ibm.mqe.adapters.", "n:", "com.ibm.mqe.administration.", "o:", "com.ibm.mqe.attributes.", "p:", "com.ibm.mqe.bindings.", "q:", "com.ibm.mqe.communications.", "r:", "com.ibm.mqe.messagestore.", "s:", "com.ibm.mqe.mqbridge.", "t:", "com.ibm.mqe.registry.", "u:", "com.ibm.mqe.server.", "v:", "com.ibm.mqe.mqemqmessage.", "w:", "com.ibm.mqe.trace.", "x:", "com.ibm.mqe.validation.", "y:", "com.ibm.mqe.", "z:" };
  public static short[] version = { 2, 0, 0, 2 };
  private long currentFilter = 0L;
  private boolean isOn = false;
  private int recordsOutput = 0;

  private static void encodeAsciiString(ByteArrayOutputStream paramByteArrayOutputStream, String paramString)
    throws IOException
  {
    if (paramString.length() > 20480)
      paramString = paramString.substring(0, 20479);
    paramByteArrayOutputStream.write(MQe.shortToByte((short)paramString.length()));
    paramByteArrayOutputStream.write(MQe.asciiToByte(paramString));
  }

  private static void encodeUnicodeString(ByteArrayOutputStream paramByteArrayOutputStream, String paramString)
    throws IOException
  {
    if (paramString.length() > 10240)
      paramString = paramString.substring(0, 10239);
    paramByteArrayOutputStream.write(MQe.shortToByte((short)paramString.length()));
    paramByteArrayOutputStream.write(MQe.unicodeToByte(paramString));
  }

  private String shortenClassName(String paramString)
  {
    int i = 0;
    int j;
    String str;
    if ((paramString != null) && (paramString.startsWith("com.ibm.mqe.")))
    {
      j = 0;
      str = paramString;
    }
    while ((i == 0) && (j < prefixes.length))
    {
      if (paramString.startsWith(prefixes[j]))
      {
        str = prefixes[(j + 1)] + paramString.substring(prefixes[j].length());
        i = 1;
      }
      j += 2;
      continue;
      str = paramString;
    }
    return str;
  }

  private void traceFilteredMessage(Object paramObject, short paramShort, long paramLong, Object[] paramArrayOfObject)
  {
    try
    {
      long l;
      String str1;
      int i;
      String str2;
      if (this.isOn)
      {
        l = System.currentTimeMillis();
        str1 = Thread.currentThread().toString();
        i = Thread.currentThread().hashCode();
        if (paramObject != null)
          break label71;
        str2 = "";
      }
      label71: int j;
      for (int k = 0; ; k = j)
      {
        writeRecord(constructRecord(l, paramShort, str1, i, str2, k, paramLong, convertInsertsToStrings(paramArrayOfObject)));
        return;
        str2 = shortenClassName(paramObject.getClass().toString());
        j = paramObject.hashCode();
      }
    }
    finally
    {
    }
  }

  byte[] constructRecord(long paramLong1, short paramShort, String paramString1, int paramInt1, String paramString2, int paramInt2, long paramLong2, String[] paramArrayOfString)
  {
    this.recordsOutput = (1 + this.recordsOutput);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    try
    {
      localByteArrayOutputStream.write(MQe.longToByte(paramLong1));
      localByteArrayOutputStream.write(MQe.shortToByte(paramShort));
      encodeAsciiString(localByteArrayOutputStream, paramString1);
      localByteArrayOutputStream.write(MQe.intToByte(paramInt1));
      encodeAsciiString(localByteArrayOutputStream, paramString2);
      localByteArrayOutputStream.write(MQe.intToByte(paramInt2));
      localByteArrayOutputStream.write(MQe.shortToByte((short)paramArrayOfString.length));
      for (int i = 0; i < paramArrayOfString.length; i++)
        encodeUnicodeString(localByteArrayOutputStream, paramArrayOfString[i]);
    }
    catch (IOException localIOException)
    {
    }
    return localByteArrayOutputStream.toByteArray();
  }

  String[] convertInsertsToStrings(Object[] paramArrayOfObject)
  {
    int i = 0;
    int j;
    String[] arrayOfString;
    if (paramArrayOfObject == null)
    {
      j = 0;
      arrayOfString = new String[j];
      label14: if (i >= j)
        break label56;
      if (paramArrayOfObject[i] != null)
        break label43;
      arrayOfString[i] = "";
    }
    while (true)
    {
      i++;
      break label14;
      j = paramArrayOfObject.length;
      break;
      label43: arrayOfString[i] = paramArrayOfObject[i].toString();
    }
    label56: if (j > 0)
    {
      Object localObject = paramArrayOfObject[(j - 1)];
      if ((localObject != null) && ((localObject instanceof Throwable)))
      {
        StringBuffer localStringBuffer = new StringBuffer();
        int k = j - 1;
        arrayOfString[k] = (arrayOfString[k] + "\n" + throwableStackTrace((Throwable)localObject));
      }
    }
    return arrayOfString;
  }

  byte[] getFooter(short paramShort)
  {
    return constructRecord(System.currentTimeMillis(), paramShort, Thread.currentThread().toString(), Thread.currentThread().hashCode(), getClass().toString(), hashCode(), 0L, new String[0]);
  }

  byte[] getHeader()
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      localByteArrayOutputStream.write(MQe.intToByte(-17978438));
      localByteArrayOutputStream.write(MQe.shortToByte((short)1));
      short[] arrayOfShort = MQe.version;
      localByteArrayOutputStream.write(MQe.shortToByte(arrayOfShort[0]));
      localByteArrayOutputStream.write(MQe.shortToByte(arrayOfShort[1]));
      localByteArrayOutputStream.write(MQe.shortToByte(arrayOfShort[2]));
      localByteArrayOutputStream.write(MQe.shortToByte((short)0));
      encodeAsciiString(localByteArrayOutputStream, "mqe_java/source/com/ibm/mqe/MQe.java, MQeBase, la000 1.111");
      localByteArrayOutputStream.write(MQe.longToByte(System.currentTimeMillis()));
      byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
      return arrayOfByte;
    }
    catch (IOException localIOException)
    {
    }
    return null;
  }

  boolean off()
  {
    return true;
  }

  boolean on()
  {
    try
    {
      this.recordsOutput = 0;
      return true;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setFilter(long paramLong)
  {
    if (this.currentFilter == 0L)
      if (paramLong == 0L);
    for (this.isOn = on(); ; this.isOn = false)
      do
      {
        this.currentFilter = paramLong;
        return;
      }
      while ((paramLong != 0L) || (!off()));
  }

  abstract String throwableStackTrace(Throwable paramThrowable);

  public void traceMessage(Object paramObject, short paramShort, long paramLong)
  {
    traceFilteredMessage(paramObject, paramShort, paramLong, new Object[0]);
  }

  public void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2)
  {
    traceFilteredMessage(paramObject1, paramShort, paramLong, new Object[] { paramObject2 });
  }

  public void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2, Object paramObject3)
  {
    traceFilteredMessage(paramObject1, paramShort, paramLong, new Object[] { paramObject2, paramObject3 });
  }

  public void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    traceFilteredMessage(paramObject1, paramShort, paramLong, new Object[] { paramObject2, paramObject3, paramObject4 });
  }

  public void traceMessage(Object paramObject1, short paramShort, long paramLong, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5)
  {
    traceFilteredMessage(paramObject1, paramShort, paramLong, new Object[] { paramObject2, paramObject3, paramObject4, paramObject5 });
  }

  abstract boolean writeRecord(byte[] paramArrayOfByte);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.trace.MQeTraceToBinary
 * JD-Core Version:    0.6.2
 */