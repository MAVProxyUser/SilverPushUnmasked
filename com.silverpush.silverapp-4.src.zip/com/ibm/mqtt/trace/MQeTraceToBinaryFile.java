package com.ibm.mqtt.trace;

import com.ibm.mqtt.MQeTraceHandler;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

public class MQeTraceToBinaryFile extends MQeTraceToBinary
  implements MQeTraceHandler
{
  private static final String CURRENT_DIRECTORY = ".";
  private static final boolean DEBUG = false;
  private static final String DEFAULT_DIRECTORY = ".";
  private static final int DEFAULT_FILES_EXISTING_AT_ONCE = 1;
  public static final String DEFAULT_FILE_NAME_PREFIX = "mqe";
  public static final String DEFAULT_FILE_NAME_SUFFIX = ".trc";
  static final short FOOTER_BECAUSE_OF_CLOSE = -24001;
  static final short FOOTER_BECAUSE_OF_FINALISE = -24002;
  static final short FOOTER_BECAUSE_OF_WRAP = -24000;
  public static final long MIN_TRACE_FILE_SIZE = 2096L;
  private static final int NEVER_WRAP = -1;
  public static short[] version = { 2, 0, 0, 2 };
  private long bytesWritten = 0L;
  File currentFile;
  private FileOutputStream currentFileOut;
  private String directoryName = ".";
  private int fileNameIndex = 0;
  private String fileNamePrefix = "mqe";
  private String fileNameSuffix = ".trc";
  private int filesExistingAtOnce = 1;
  private byte[] footer;
  private long maxFileSizeBeforeWrap = -1L;

  public MQeTraceToBinaryFile()
  {
    this(".", "mqe", ".trc", 1, -1L);
  }

  public MQeTraceToBinaryFile(String paramString1, String paramString2, String paramString3, int paramInt, long paramLong)
  {
    if (paramString1 == null)
      paramString1 = ".";
    this.directoryName = paramString1;
    if (paramString2 == null)
      paramString2 = "mqe";
    this.fileNamePrefix = paramString2;
    if (paramString3 == null)
      paramString3 = ".trc";
    this.fileNameSuffix = paramString3;
    if (paramInt < 1)
      paramInt = 1;
    this.filesExistingAtOnce = paramInt;
    if (paramInt == 1)
      paramLong = -1L;
    while (true)
    {
      this.maxFileSizeBeforeWrap = paramLong;
      this.fileNameIndex = 0;
      this.footer = super.getFooter((short)-24001);
      return;
      if (paramLong < 2096L)
        paramLong = 2096L;
    }
  }

  private final void closeFile()
  {
    try
    {
      this.currentFileOut.close();
      this.currentFileOut = null;
      return;
    }
    catch (IOException localIOException)
    {
    }
  }

  void advanceFileNameIndex()
  {
    this.fileNameIndex = (1 + this.fileNameIndex);
    if (this.fileNameIndex >= this.filesExistingAtOnce)
      this.fileNameIndex = 0;
  }

  void finalise()
  {
    if (this.currentFileOut != null)
    {
      writeFooter((short)-24002);
      closeFile();
    }
  }

  String getPaddedIndex()
  {
    String str1 = "";
    int i = Integer.toString(this.filesExistingAtOnce).length();
    String str2 = Integer.toString(this.fileNameIndex);
    for (int j = str2.length(); j < i; j++)
      str1 = str1 + "0";
    return str1 + str2;
  }

  boolean off()
  {
    boolean bool = writeFooter((short)-24001);
    advanceFileNameIndex();
    closeFile();
    return bool;
  }

  boolean on()
  {
    return openFile();
  }

  boolean openFile()
  {
    this.currentFile = new File(this.directoryName + System.getProperty("file.separator") + this.fileNamePrefix + getPaddedIndex() + this.fileNameSuffix);
    if (this.currentFile.exists())
      this.currentFile.delete();
    try
    {
      this.bytesWritten = 0L;
      this.currentFileOut = new FileOutputStream(this.currentFile);
      writeHeader();
      return true;
    }
    catch (IOException localIOException)
    {
    }
    return false;
  }

  String throwableStackTrace(Throwable paramThrowable)
  {
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
    return localStringWriter.toString();
  }

  boolean writeFooter(short paramShort)
  {
    try
    {
      this.currentFileOut.write(getFooter(paramShort));
      this.currentFileOut.flush();
      return true;
    }
    catch (IOException localIOException)
    {
    }
    return false;
  }

  boolean writeHeader()
  {
    byte[] arrayOfByte = getHeader();
    try
    {
      this.currentFileOut.write(arrayOfByte);
      this.currentFileOut.flush();
      this.bytesWritten += arrayOfByte.length;
      return true;
    }
    catch (IOException localIOException)
    {
    }
    return false;
  }

  boolean writeRecord(byte[] paramArrayOfByte)
  {
    boolean bool = true;
    if ((this.maxFileSizeBeforeWrap != -1L) && (paramArrayOfByte.length + this.bytesWritten + this.footer.length > this.maxFileSizeBeforeWrap))
    {
      bool = writeFooter((short)-24000);
      if (bool)
      {
        advanceFileNameIndex();
        bool = openFile();
      }
    }
    if (bool);
    try
    {
      this.currentFileOut.write(paramArrayOfByte);
      this.bytesWritten += paramArrayOfByte.length;
      this.currentFileOut.flush();
      return bool;
    }
    catch (IOException localIOException)
    {
    }
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.trace.MQeTraceToBinaryFile
 * JD-Core Version:    0.6.2
 */