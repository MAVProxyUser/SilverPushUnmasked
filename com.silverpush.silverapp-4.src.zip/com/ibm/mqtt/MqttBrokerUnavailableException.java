package com.ibm.mqtt;

public class MqttBrokerUnavailableException extends MqttException
{
  public MqttBrokerUnavailableException()
  {
  }

  public MqttBrokerUnavailableException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttBrokerUnavailableException
 * JD-Core Version:    0.6.2
 */