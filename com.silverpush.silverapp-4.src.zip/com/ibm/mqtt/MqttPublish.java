package com.ibm.mqtt;

public class MqttPublish extends MqttPacket
{
  public String topicName;

  public MqttPublish()
  {
    setMsgType((short)3);
  }

  public MqttPublish(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)3);
    this.topicName = MqttUtils.UTFToString(paramArrayOfByte, paramInt);
    if (getQos() > 0)
    {
      setMsgId(MqttUtils.toShort(paramArrayOfByte, 2 + (paramInt + this.topicName.length())));
      setPayload(MqttUtils.SliceByteArray(paramArrayOfByte, 4 + (paramInt + this.topicName.length()), paramArrayOfByte.length - (4 + (paramInt + this.topicName.length()))));
      return;
    }
    setPayload(MqttUtils.SliceByteArray(paramArrayOfByte, 2 + (paramInt + this.topicName.length()), paramArrayOfByte.length - (2 + (paramInt + this.topicName.length()))));
  }

  private void uncompressTopic()
  {
  }

  public void compressTopic()
  {
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    if (paramMqttProcessor.supportTopicNameCompression())
      uncompressTopic();
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    byte[] arrayOfByte1 = MqttUtils.StringToUTF(this.topicName);
    if (getQos() > 0);
    for (this.message = new byte[3 + arrayOfByte1.length]; ; this.message = new byte[1 + arrayOfByte1.length])
    {
      this.message[0] = super.toBytes()[0];
      System.arraycopy(arrayOfByte1, 0, this.message, 1, arrayOfByte1.length);
      int i = 1 + arrayOfByte1.length;
      if (getQos() > 0)
      {
        int j = getMsgId();
        byte[] arrayOfByte2 = this.message;
        int k = i + 1;
        arrayOfByte2[i] = ((byte)(j / 256));
        byte[] arrayOfByte3 = this.message;
        (k + 1);
        arrayOfByte3[k] = ((byte)(j % 256));
      }
      createMsgLength();
      return this.message;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPublish
 * JD-Core Version:    0.6.2
 */