package com.ibm.mqtt;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

public final class MqttUtils
{
  public static final String STRING_ENCODING = "UTF-8";

  public static final byte[] SliceByteArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[paramInt2];
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
    return arrayOfByte;
  }

  public static final byte[] StringToUTF(String paramString)
  {
    if (paramString == null)
      return null;
    try
    {
      byte[] arrayOfByte1 = paramString.getBytes("UTF-8");
      byte[] arrayOfByte2 = new byte[2 + arrayOfByte1.length];
      arrayOfByte2[0] = new Integer(arrayOfByte1.length / 256).byteValue();
      arrayOfByte2[1] = new Integer(arrayOfByte1.length % 256).byteValue();
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 2, arrayOfByte1.length);
      return arrayOfByte2;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      System.out.println("MQTT Client: Unsupported string encoding - UTF-8");
    }
    return null;
  }

  public static final String UTFToString(byte[] paramArrayOfByte)
  {
    return UTFToString(paramArrayOfByte, 0);
  }

  public static final String UTFToString(byte[] paramArrayOfByte, int paramInt)
  {
    if (paramArrayOfByte == null);
    int i;
    do
    {
      return null;
      i = ((0xFF & paramArrayOfByte[(paramInt + 0)]) << 8) + ((0xFF & paramArrayOfByte[(paramInt + 1)]) << 0);
    }
    while (i + 2 > paramArrayOfByte.length);
    if (i > 0);
    while (true)
    {
      try
      {
        str = new String(paramArrayOfByte, paramInt + 2, i, "UTF-8");
        return str;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        System.out.println("MQTT Client: Unsupported string encoding - UTF-8");
        str = null;
        continue;
      }
      String str = "";
    }
  }

  public static final Vector UTFToStrings(byte[] paramArrayOfByte, int paramInt)
  {
    Vector localVector;
    if (paramArrayOfByte == null)
      localVector = null;
    while (true)
    {
      return localVector;
      localVector = new Vector();
      while (paramInt <= -3 + paramArrayOfByte.length)
      {
        int i = ((0xFF & paramArrayOfByte[paramInt]) << 8) + ((0xFF & paramArrayOfByte[(paramInt + 1)]) << 0);
        String str = UTFToString(paramArrayOfByte, paramInt);
        if (str != null)
          localVector.addElement(str);
        paramInt += i + 2;
      }
    }
  }

  public static final byte[] concatArray(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, int paramInt4)
  {
    byte[] arrayOfByte = new byte[paramInt2 + paramInt4];
    System.arraycopy(paramArrayOfByte1, paramInt1, arrayOfByte, 0, paramInt2);
    System.arraycopy(paramArrayOfByte2, paramInt3, arrayOfByte, paramInt2, paramInt4);
    return arrayOfByte;
  }

  public static final byte[] concatArray(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    byte[] arrayOfByte = new byte[paramArrayOfByte1.length + paramArrayOfByte2.length];
    System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, paramArrayOfByte1.length);
    System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, paramArrayOfByte1.length, paramArrayOfByte2.length);
    return arrayOfByte;
  }

  public static final long getExpiry(long paramLong)
  {
    return System.currentTimeMillis() / 1000L + 3L * paramLong / 2L;
  }

  public static final Vector getTopicsWithQoS(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
      return null;
    Vector localVector = new Vector();
    int i = 0;
    while (true)
    {
      int k;
      if (i <= -4 + paramArrayOfByte.length)
      {
        int j = ((0xFF & paramArrayOfByte[i]) << 8) + ((0xFF & paramArrayOfByte[(i + 1)]) << 0);
        StringBuffer localStringBuffer = new StringBuffer(paramArrayOfByte.length);
        k = i + 2;
        int m = j + k;
        while ((k < m) && (m < paramArrayOfByte.length))
        {
          int n = k + 1;
          localStringBuffer.append((char)(0xFF & paramArrayOfByte[k]));
          k = n;
        }
        if (localStringBuffer.toString().length() > 0)
        {
          i = k + 1;
          localStringBuffer.append(paramArrayOfByte[k]);
          localVector.addElement(localStringBuffer.toString());
        }
      }
      else
      {
        return localVector;
        i = k;
      }
    }
  }

  public static final String toHexString(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    if (paramInt1 < 0)
      paramInt1 = 0;
    int i = paramInt1;
    if ((i >= paramInt1 + paramInt2) || (i > -1 + paramArrayOfByte.length))
      return localStringBuffer.toString();
    int j = paramArrayOfByte[i];
    if (j < 0)
      j += 256;
    if (j < 16)
      localStringBuffer.append("0" + Integer.toHexString(j));
    while (true)
    {
      i++;
      break;
      localStringBuffer.append(Integer.toHexString(j));
    }
  }

  public static final int toShort(byte[] paramArrayOfByte, int paramInt)
  {
    return ((0xFF & (short)paramArrayOfByte[(paramInt + 0)]) << 8) + (0xFF & (short)paramArrayOfByte[(paramInt + 1)]);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttUtils
 * JD-Core Version:    0.6.2
 */