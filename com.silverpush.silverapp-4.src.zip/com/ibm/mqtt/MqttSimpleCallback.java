package com.ibm.mqtt;

public abstract interface MqttSimpleCallback
{
  public abstract void connectionLost()
    throws Exception;

  public abstract void publishArrived(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
    throws Exception;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttSimpleCallback
 * JD-Core Version:    0.6.2
 */