package com.ibm.mqtt;

public class MqttPingreq extends MqttPacket
{
  public MqttPingreq()
  {
    setMsgType((short)12);
  }

  public MqttPingreq(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)12);
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    this.message = new byte[1];
    this.message[0] = super.toBytes()[0];
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttPingreq
 * JD-Core Version:    0.6.2
 */