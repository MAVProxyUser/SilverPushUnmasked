package com.ibm.mqtt;

public class MqttConnack extends MqttPacket
{
  public short returnCode;
  public boolean topicNameCompression;

  public MqttConnack()
  {
    setMsgType((short)2);
  }

  public MqttConnack(byte[] paramArrayOfByte, int paramInt)
  {
    super(paramArrayOfByte);
    setMsgType((short)2);
    if ((0x1 & paramArrayOfByte[paramInt]) != 0);
    for (boolean bool = true; ; bool = false)
    {
      this.topicNameCompression = bool;
      this.returnCode = ((short)paramArrayOfByte[(paramInt + 1)]);
      return;
    }
  }

  public void process(MqttProcessor paramMqttProcessor)
  {
    paramMqttProcessor.process(this);
  }

  public byte[] toBytes()
  {
    this.message = new byte[3];
    this.message[0] = super.toBytes()[0];
    byte[] arrayOfByte = this.message;
    boolean bool = this.topicNameCompression;
    int i = 0;
    if (bool)
      i = 1;
    arrayOfByte[1] = i;
    this.message[2] = ((byte)this.returnCode);
    createMsgLength();
    return this.message;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttConnack
 * JD-Core Version:    0.6.2
 */