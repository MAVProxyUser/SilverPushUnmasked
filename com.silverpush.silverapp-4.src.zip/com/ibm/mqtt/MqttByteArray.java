package com.ibm.mqtt;

public class MqttByteArray
{
  private byte[] byteArray = null;

  public MqttByteArray(byte[] paramArrayOfByte)
  {
    this.byteArray = paramArrayOfByte;
  }

  public byte[] getByteArray()
  {
    return this.byteArray;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttByteArray
 * JD-Core Version:    0.6.2
 */