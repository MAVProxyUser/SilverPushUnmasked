package com.ibm.mqtt;

public class MqttNotConnectedException extends MqttException
{
  public MqttNotConnectedException()
  {
  }

  public MqttNotConnectedException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.ibm.mqtt.MqttNotConnectedException
 * JD-Core Version:    0.6.2
 */