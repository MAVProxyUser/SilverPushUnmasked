package com.silverpush;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

public class Registarion extends AsyncTask<Context, Void, String>
{
  private Context ctx;
  private String devId;
  private SharedPreferences devicePrefes;
  private Header header = null;
  private HttpResponse httpResponse = null;
  private HttpClient httpclient = null;
  private HttpPost httppost = null;
  private Device pf;

  public Registarion(Context paramContext, String paramString1, String paramString2)
  {
    this.devId = paramString2;
    this.ctx = paramContext;
    if (paramContext.getPackageManager().checkPermission("android.permission.READ_PHONE_STATE", paramContext.getPackageName()) == 0)
    {
      this.pf = new Device(paramContext);
      return;
    }
    PushUtility.Logger("Unable to get DeviceId", "Application does not have permission READ_PHONE_STATE; determining device id is not possible.  Please consider requesting READ_PHONE_STATE in the AndroidManifest");
  }

  protected String doInBackground(Context[] paramArrayOfContext)
  {
    String str1 = this.pf.getImei();
    String str2 = this.pf.getAndroidId();
    String str3 = this.pf.getOsVersion();
    String str4 = this.pf.getManufacturerName();
    String str5 = this.pf.getTimeZone();
    String str6 = this.pf.getMacId();
    String str7 = this.pf.getPhone();
    String str8 = this.pf.getAppId();
    String str9 = this.pf.getModelName();
    String str10 = this.pf.getopratorName();
    String str11 = this.pf.getnetworkType();
    String str12 = PushUtility.buildUrl("DeviceRegistrationServlet", null);
    this.httpclient = new DefaultHttpClient();
    HttpPost localHttpPost = new HttpPost(str12);
    this.httppost = localHttpPost;
    this.httppost.setHeader("Content-Type", "text/html");
    this.httppost.setHeader("DEVICE_ID", this.devId);
    this.httppost.setHeader("ANDROID_ID", str2);
    this.httppost.setHeader("IMEI", str1);
    this.httppost.setHeader("MAC", str6);
    this.httppost.setHeader("MANUFACTURE", str4);
    this.httppost.setHeader("OS_VERSION", str3);
    this.httppost.setHeader("TIMEZONE", str5);
    this.httppost.addHeader("PHONENO", str7);
    this.httppost.setHeader("APP_ID", str8);
    this.httppost.setHeader("MODELNAME", str9);
    this.httppost.setHeader("OPRATOR_NAME", str10);
    this.httppost.setHeader("NETWORKTYPE", str11);
    int i = 5;
    while (true)
    {
      if (i >= 0);
      try
      {
        if (this.header != null);
        while (true)
          while (true)
          {
            this.httpResponse = this.httpclient.execute(this.httppost);
            String str13 = this.httpResponse.getFirstHeader("DEVICE_ID").getValue();
            return str13;
            try
            {
              this.httpResponse = this.httpclient.execute(this.httppost);
              this.header = this.httpResponse.getFirstHeader("DEVICE_ID");
              i--;
            }
            catch (Exception localException2)
            {
              localException2.printStackTrace();
            }
          }
      }
      catch (Exception localException1)
      {
        localException1.printStackTrace();
      }
    }
    return null;
  }

  protected void onPostExecute(String paramString)
  {
    if (paramString != null)
    {
      this.devicePrefes = this.ctx.getSharedPreferences("devicePrefes", 0);
      SharedPreferences.Editor localEditor = this.devicePrefes.edit();
      localEditor.putString("deviceId", paramString);
      localEditor.commit();
    }
    Intent localIntent = new Intent();
    PushConfig.deviceId = paramString;
    localIntent.setAction("com.silverpush.DEVICE_REGISTER");
    localIntent.putExtra("deviceId", paramString);
    this.ctx.sendBroadcast(localIntent);
    super.onPostExecute(paramString);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.Registarion
 * JD-Core Version:    0.6.2
 */