package com.silverpush;

import android.content.res.Configuration;
import android.content.res.Resources;
import com.google.analytics.tracking.android.TrackedListActivity;

public class GAPushListActivity extends TrackedListActivity
{
  protected void onStart()
  {
    PushUtility.logData(this, getLocalClassName(), "onstart", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    super.onStart();
  }

  protected void onStop()
  {
    super.onStop();
    PushUtility.logData(this, getLocalClassName(), "onstop", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.GAPushListActivity
 * JD-Core Version:    0.6.2
 */