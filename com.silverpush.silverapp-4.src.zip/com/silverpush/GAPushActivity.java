package com.silverpush;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import com.google.analytics.tracking.android.TrackedActivity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

public class GAPushActivity extends TrackedActivity
  implements View.OnClickListener, View.OnTouchListener
{
  public void onClick(View paramView)
  {
    if ((paramView instanceof Button))
    {
      Button localButton = (Button)paramView;
      PushUtility.logData(this, localButton.getContentDescription(), "button_clicked", "close", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    }
  }

  protected void onCreate(Bundle paramBundle, String paramString)
  {
    PushUtility.logData(this, getLocalClassName(), "oncreate", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    new PushConfig(this, paramString);
    super.onCreate(paramBundle);
  }

  public void onCreateFinish()
  {
    PushUtility.logData(this, getLocalClassName(), "onloaded", "close", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
  }

  protected void onDestroy()
  {
    PushUtility.logData(this, getLocalClassName(), "ondestroy", "close", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    super.onDestroy();
  }

  protected void onPause()
  {
    PushUtility.logData(this, getLocalClassName(), "onpause", "close", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    new UploadLog(getApplicationContext()).execute(new Context[0]);
    super.onPause();
  }

  protected void onResume()
  {
    PushUtility.logData(this, getLocalClassName(), "onresume", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    super.onResume();
  }

  protected void onStart()
  {
    PushUtility.logData(this, getLocalClassName(), "onstart", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    super.onStart();
  }

  protected void onStop()
  {
    PushUtility.logData(this, getLocalClassName(), "onstop", "close", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    super.onStop();
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    return false;
  }

  public void searchAction(final String paramString1, final String paramString2, final long paramLong1, long paramLong2, final String paramString3)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        String str = PushUtility.buildUrl("ReceiveQuerySearchData", null);
        DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
        HttpPost localHttpPost = new HttpPost(str);
        localHttpPost.setHeader("Content-Type", "text/html");
        localHttpPost.setHeader("DEVICE_ID", PushUtility.getDeviceID(GAPushActivity.this.getApplicationContext()));
        localHttpPost.setHeader("APP_ID", PushUtility.getAppID(GAPushActivity.this.getApplicationContext()));
        localHttpPost.setHeader("from_place", paramString1);
        localHttpPost.setHeader("to_place", paramString2);
        localHttpPost.setHeader("from_date", paramLong1);
        localHttpPost.setHeader("to_date", paramString3);
        localHttpPost.setHeader("class_type", this.val$class_type);
        try
        {
          localDefaultHttpClient.execute(localHttpPost);
          return;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }).start();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.GAPushActivity
 * JD-Core Version:    0.6.2
 */