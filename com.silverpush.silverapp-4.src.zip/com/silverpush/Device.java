package com.silverpush;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import java.util.Properties;
import java.util.TimeZone;

public class Device
{
  private static Context ctx;
  static String url;
  String AndroidId;
  String App_Id;
  String C2dmKey;
  String Imei;
  String MacId;
  String ManufacturerName;
  String OsVersion;
  String PackageName;
  String PhoneNo;
  String Time_Zone;
  TelephonyManager manager;
  String model_name;
  String networkType;
  String opratorName;
  Properties silverProp;

  public Device(Context paramContext)
  {
    ctx = paramContext;
    this.silverProp = new Properties();
    this.manager = ((TelephonyManager)ctx.getSystemService("phone"));
    PushUtility.loadProp("silverpush.properties", this.silverProp);
  }

  public String getAndroidId()
  {
    this.AndroidId = Settings.Secure.getString(ctx.getContentResolver(), "android_id");
    return this.AndroidId;
  }

  public String getAppId()
  {
    return this.silverProp.getProperty("appId");
  }

  public String getC2dmKey()
  {
    return this.silverProp.getProperty("c2dmid");
  }

  public String getImei()
  {
    this.Imei = ((TelephonyManager)ctx.getSystemService("phone")).getDeviceId();
    return this.Imei;
  }

  public String getMacId()
  {
    this.MacId = ((WifiManager)ctx.getSystemService("wifi")).getConnectionInfo().getMacAddress();
    return this.MacId;
  }

  public String getManufacturerName()
  {
    this.ManufacturerName = Build.MANUFACTURER;
    return this.ManufacturerName;
  }

  public String getModelName()
  {
    this.model_name = Build.MODEL;
    return this.model_name;
  }

  public String getOsVersion()
  {
    this.OsVersion = Build.VERSION.RELEASE;
    return this.OsVersion;
  }

  public String getPackageName()
  {
    this.PackageName = ctx.getPackageName();
    return this.PackageName;
  }

  public String getPhone()
  {
    this.PhoneNo = this.manager.getLine1Number();
    this.PhoneNo = "0000";
    return this.PhoneNo;
  }

  public String getTimeZone()
  {
    this.Time_Zone = TimeZone.getDefault().getID();
    return this.Time_Zone;
  }

  public String getnetworkType()
  {
    switch (this.manager.getNetworkType())
    {
    default:
    case 7:
    case 4:
    case 2:
    case 14:
    case 5:
    case 6:
    case 12:
    case 1:
    case 8:
    case 10:
    case 15:
    case 9:
    case 11:
    case 13:
    case 3:
    case 0:
    }
    while (true)
    {
      return this.networkType;
      this.networkType = "1xRTT";
      continue;
      this.networkType = "CDMA";
      continue;
      this.networkType = "EDGE";
      continue;
      this.networkType = "eHRPD";
      continue;
      this.networkType = "EVDO rev.0";
      continue;
      this.networkType = "EVDO rev.A";
      continue;
      this.networkType = "EVDO rev.B";
      continue;
      this.networkType = "GPRS";
      continue;
      this.networkType = "HSDPA";
      continue;
      this.networkType = "HSPA";
      continue;
      this.networkType = "HSPA_3.5G";
      continue;
      this.networkType = "HSUPA";
      continue;
      this.networkType = "iDen";
      continue;
      this.networkType = "LTE";
      continue;
      this.networkType = "UMTS";
      continue;
      this.networkType = "Unknown";
    }
  }

  public String getopratorName()
  {
    this.opratorName = this.manager.getNetworkOperatorName();
    return this.opratorName;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.Device
 * JD-Core Version:    0.6.2
 */