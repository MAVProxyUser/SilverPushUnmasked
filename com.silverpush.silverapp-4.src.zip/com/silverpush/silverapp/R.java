package com.silverpush.silverapp;

public final class R
{
  public static final class attr
  {
  }

  public static final class drawable
  {
    public static final int d1 = 2130837504;
    public static final int download = 2130837505;
    public static final int gsf = 2130837506;
    public static final int gsflogo = 2130837507;
    public static final int ic_action_search = 2130837508;
    public static final int ic_launcher = 2130837509;
  }

  public static final class id
  {
    public static final int gsflogo = 2131165185;
    public static final int lo = 2131165187;
    public static final int menu_settings = 2131165188;
    public static final int text = 2131165186;
    public static final int webview = 2131165184;
  }

  public static final class layout
  {
    public static final int activity_main = 2130903040;
    public static final int activity_splash = 2130903041;
  }

  public static final class menu
  {
    public static final int activity_main = 2131099648;
    public static final int activity_splash = 2131099649;
  }

  public static final class string
  {
    public static final int app_name = 2130968576;
    public static final int hello_world = 2130968577;
    public static final int menu_settings = 2130968578;
    public static final int title_activity_main = 2130968579;
    public static final int title_activity_splash = 2130968580;
  }

  public static final class style
  {
    public static final int AppTheme = 2131034112;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.silverapp.R
 * JD-Core Version:    0.6.2
 */