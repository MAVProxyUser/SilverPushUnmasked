package com.silverpush.silverapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import com.silverpush.PushActivity;

public class SplashActivity extends PushActivity
{
  final Runnable kill = new Runnable()
  {
    public void run()
    {
      SplashActivity.this.finish();
      Intent localIntent = new Intent(SplashActivity.this, MainActivity.class);
      SplashActivity.this.startActivity(localIntent);
    }
  };

  public void onBackPressed()
  {
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    new Handler().postDelayed(this.kill, 3000L);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.silverapp.SplashActivity
 * JD-Core Version:    0.6.2
 */