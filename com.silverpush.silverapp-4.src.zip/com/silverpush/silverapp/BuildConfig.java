package com.silverpush.silverapp;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.silverapp.BuildConfig
 * JD-Core Version:    0.6.2
 */