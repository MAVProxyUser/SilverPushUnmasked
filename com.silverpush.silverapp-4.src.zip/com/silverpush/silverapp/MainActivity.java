package com.silverpush.silverapp;

import android.annotation.SuppressLint;
import android.content.res.Configuration;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.silverpush.PushActivity;

@SuppressLint({"SetJavaScriptEnabled"})
public class MainActivity extends PushActivity
{
  WebView mWebView;

  public void onBackPressed()
  {
    if (this.mWebView.canGoBack())
    {
      this.mWebView.goBack();
      return;
    }
    super.onBackPressed();
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    this.mWebView = ((WebView)findViewById(2131165184));
    this.mWebView.loadUrl("file:///android_asset/index.html");
    this.mWebView.getSettings().setJavaScriptEnabled(true);
    this.mWebView.setWebViewClient(new WebViewClient());
    onCreateFinish();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.silverapp.MainActivity
 * JD-Core Version:    0.6.2
 */