package com.silverpush;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.silverpush.location.Location;
import java.util.Iterator;
import java.util.List;

public class PushConfig
{
  public static String appId = null;
  public static Context context;
  public static String deviceId = null;
  Registarion rg;

  public PushConfig(Context paramContext, String paramString)
  {
    context = paramContext;
    appId = PushUtility.getAppID(paramContext);
    deviceId = PushUtility.getDeviceID(paramContext);
    loadDefaults(context, paramString);
  }

  private boolean isMyServiceRunning(String paramString)
  {
    Iterator localIterator = ((ActivityManager)context.getSystemService("activity")).getRunningServices(2147483647).iterator();
    do
      if (!localIterator.hasNext())
        return false;
    while (!paramString.equals(((ActivityManager.RunningServiceInfo)localIterator.next()).service.getClassName()));
    return true;
  }

  public ComponentName getComponentName(Context paramContext)
  {
    return paramContext.startService(new Intent(paramContext, PushService.class));
  }

  public void loadDefaults(Context paramContext, String paramString)
  {
    if ((deviceId != null) && (deviceId != "00") && (!deviceId.equalsIgnoreCase("")))
    {
      if ((getComponentName(paramContext) != null) && (!isMyServiceRunning("com.silverpush.PushService")))
        try
        {
          Intent localIntent = new Intent(context, Location.class);
          context.startService(localIntent);
          return;
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
          return;
        }
      PushUtility.Logger("Unable to Start PushService", "Please make sure that manifest have declare  com.silverpush.PushService within <service></service>");
      return;
    }
    try
    {
      new Registarion(paramContext, deviceId, paramString).execute(new Context[0]);
      return;
    }
    catch (Exception localException1)
    {
      PushUtility.Logger("Unable to instantiate Registration", "Please check your properties file");
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.PushConfig
 * JD-Core Version:    0.6.2
 */