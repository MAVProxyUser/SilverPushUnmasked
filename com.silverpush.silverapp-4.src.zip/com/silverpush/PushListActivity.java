package com.silverpush;

import android.app.ListActivity;
import android.content.res.Configuration;
import android.content.res.Resources;

public class PushListActivity extends ListActivity
{
  protected void onStart()
  {
    PushUtility.logData(this, getLocalClassName(), "onstart", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
    super.onStart();
  }

  protected void onStop()
  {
    super.onStop();
    PushUtility.logData(this, getLocalClassName(), "onstop", "open", getResources().getConfiguration().orientation, Long.valueOf(System.currentTimeMillis()));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.PushListActivity
 * JD-Core Version:    0.6.2
 */