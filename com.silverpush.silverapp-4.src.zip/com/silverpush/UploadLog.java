package com.silverpush;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UploadLog extends AsyncTask<Context, Void, String>
{
  Context context;
  int i = 0;

  public UploadLog(Context paramContext)
  {
    this.context = paramContext;
  }

  protected String doInBackground(Context[] paramArrayOfContext)
  {
    try
    {
      Thread.sleep(5000L);
      label6: int j = 0;
      DataLogger localDataLogger = new DataLogger(this.context);
      Cursor localCursor = localDataLogger.loadData();
      JSONArray localJSONArray = new JSONArray();
      int k = 0;
      while (true)
      {
        if (!localCursor.moveToNext())
        {
          localCursor.close();
          localDataLogger.close();
          return j;
        }
        k++;
        JSONObject localJSONObject = new JSONObject();
        try
        {
          localJSONObject.put("activity_name", localCursor.getString(0));
          localJSONObject.put("called_method", localCursor.getString(1));
          localJSONObject.put("orientation_type", localCursor.getInt(2));
          localJSONObject.put("event_type", localCursor.getString(4));
          localJSONObject.put("event_time", localCursor.getLong(3));
          localJSONArray.put(localJSONObject);
          if (k != 50)
            continue;
        }
        catch (JSONException localJSONException)
        {
          try
          {
            Header localHeader2 = PushUtility.uploadToServer(localJSONArray).getFirstHeader("DATA_RECEIVED");
            localHeader1 = localHeader2;
            if (localHeader1 != null)
            {
              j += Integer.parseInt(localHeader1.getValue());
              localJSONArray = new JSONArray();
              k = 0;
              continue;
              localJSONException = localJSONException;
              localJSONException.printStackTrace();
            }
          }
          catch (Exception localException2)
          {
            while (true)
            {
              localException2.printStackTrace();
              Header localHeader1 = null;
              continue;
              j += 0;
            }
          }
        }
      }
    }
    catch (Exception localException1)
    {
      break label6;
    }
  }

  protected void onPostExecute(String paramString)
  {
    if (Integer.parseInt(paramString) > 1)
    {
      DataLogger localDataLogger = new DataLogger(this.context);
      SQLiteDatabase localSQLiteDatabase = localDataLogger.getWritableDatabase();
      localDataLogger.onUpgrade(localSQLiteDatabase, 1, 1);
      localSQLiteDatabase.close();
      localDataLogger.close();
    }
    super.onPostExecute(paramString);
  }

  protected void onPreExecute()
  {
    super.onPreExecute();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.UploadLog
 * JD-Core Version:    0.6.2
 */