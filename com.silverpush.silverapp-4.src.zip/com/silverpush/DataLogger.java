package com.silverpush;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataLogger extends SQLiteOpenHelper
{
  public static final String DATABASE = "com.silverpush.log";
  public static final String LOG_TABLE = "log";
  Context context;

  public DataLogger(Context paramContext)
  {
    super(paramContext, "com.silverpush.log", null, 1);
    this.context = paramContext;
  }

  public void insertLogData(ContentValues paramContentValues)
  {
    SQLiteDatabase localSQLiteDatabase = null;
    try
    {
      localSQLiteDatabase = getWritableDatabase();
      localSQLiteDatabase.insert("log", null, paramContentValues);
      localSQLiteDatabase.close();
      return;
    }
    catch (Exception localException)
    {
      localSQLiteDatabase.close();
      Log.d("Databse insertion", localException.getLocalizedMessage());
      return;
    }
    finally
    {
      localSQLiteDatabase.close();
    }
  }

  public Cursor loadData()
  {
    return getReadableDatabase().query("log", null, null, null, null, null, null);
  }

  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("create table if not exists log (activity_name text, called_method text, orientation_type int, event_time int, event_type text)");
  }

  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
    paramSQLiteDatabase.execSQL("drop table log");
    onCreate(paramSQLiteDatabase);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.DataLogger
 * JD-Core Version:    0.6.2
 */