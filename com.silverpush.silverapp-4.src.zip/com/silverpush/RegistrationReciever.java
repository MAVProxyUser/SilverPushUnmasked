package com.silverpush;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.silverpush.location.Location;

public class RegistrationReciever extends BroadcastReceiver
{
  public static int Counter;

  public void onReceive(final Context paramContext, Intent paramIntent)
  {
    if ((paramIntent.getAction().equals("android.intent.action.BOOT_COMPLETED")) && (PushUtility.getDeviceID(paramContext) != "00") && (PushUtility.getDeviceID(paramContext) != null));
    do
    {
      try
      {
        paramContext.startService(new Intent(paramContext, PushService.class));
        return;
      }
      catch (Exception localException2)
      {
        Log.d("Unable to start ", "PushService on device reboot");
        return;
      }
      if (paramIntent.getAction().equals("com.silverpush.START"))
      {
        Bundle localBundle = paramIntent.getExtras();
        String str2 = localBundle.getString("packageName");
        int i = localBundle.getInt("noteId");
        PackageManager localPackageManager = paramContext.getPackageManager();
        try
        {
          paramContext.startActivity(localPackageManager.getLaunchIntentForPackage(str2));
          PushUtility.executeURL(PushUtility.buildUrlForNotification(i, 0, 1, PushUtility.getDeviceID(paramContext)));
          return;
        }
        catch (Exception localException1)
        {
          while (true)
            Log.d("Packge name not found", "May be appId is not getting");
        }
      }
      String str1 = paramIntent.getExtras().getString("deviceId");
      if (str1 != null)
      {
        PushConfig.deviceId = str1;
        paramContext.startService(new Intent(paramContext, PushService.class));
        paramContext.startService(new Intent(paramContext, Location.class));
        return;
      }
    }
    while (Counter > 5);
    Counter = 1 + Counter;
    new Handler().postDelayed(new Runnable()
    {
      public void run()
      {
        new Registarion(paramContext, "", "").execute(new Context[0]);
      }
    }
    , 10000 * Counter);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.RegistrationReciever
 * JD-Core Version:    0.6.2
 */