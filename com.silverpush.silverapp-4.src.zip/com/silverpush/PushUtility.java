package com.silverpush;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.util.Properties;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

public class PushUtility
{
  static Context ctx = PushConfig.context;
  static String url;

  public static void Logger(String paramString1, String paramString2)
  {
    Log.d(paramString1, paramString2);
  }

  public static String buildUrl(String paramString, Location paramLocation)
  {
    if (ctx == null)
      ctx = PushConfig.context;
    String str1 = getAppID(ctx);
    if (paramLocation == null)
    {
      url = "http://54.243.73.253:8080/SilverPush/" + paramString;
      return url;
    }
    String str2 = getDeviceID(ctx);
    double d1 = paramLocation.getLatitude();
    double d2 = paramLocation.getLongitude();
    url = "http://54.243.73.253:8080/SilverPush/" + paramString + "?" + "LONG" + "=" + d2 + "&" + "APP_ID" + str1 + "&" + "LAT" + "=" + d1 + "&" + "DEVICE_ID" + "=" + str2;
    return url;
  }

  public static String buildUrlForNotification(int paramInt1, int paramInt2, int paramInt3, String paramString)
  {
    url = "http://54.243.73.253:8080/SilverPush/NotificationResponse?noteId=" + paramInt1 + "&" + "DEVICE_ID" + "=" + paramString + "&" + "clicked" + "=" + paramInt3 + "&" + "delivered" + "=" + paramInt2;
    return url;
  }

  public static void executeURL(String paramString)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
        try
        {
          localDefaultHttpClient.execute(new HttpGet(PushUtility.this));
          return;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }).start();
  }

  public static String getAppID(Context paramContext)
  {
    try
    {
      if (PushConfig.appId == null)
      {
        Properties localProperties = new Properties();
        loadProp("silverpush.properties", localProperties);
        return localProperties.getProperty("appId");
      }
      String str = PushConfig.appId;
      return str;
    }
    catch (Exception localException)
    {
      Logger("unable get appId", "Check PropFile");
    }
    return null;
  }

  public static String getDeviceID(Context paramContext)
  {
    if (paramContext == null);
    try
    {
      paramContext = PushConfig.context;
      String str = paramContext.getSharedPreferences("devicePrefes", 0).getString("deviceId", null);
      return str;
    }
    catch (Exception localException)
    {
      Logger("unable to get device Id", "check config file");
    }
    return "00";
  }

  public static int getDrawableIcon(Context paramContext)
  {
    if (paramContext == null)
      paramContext = PushConfig.context;
    return paramContext.getApplicationInfo().icon;
  }

  public static boolean isNetworkConnected()
  {
    if (ctx == null)
      ctx = PushConfig.context;
    return ((ConnectivityManager)ctx.getSystemService("connectivity")).getActiveNetworkInfo() != null;
  }

  public static void loadProp(String paramString, Properties paramProperties)
  {
    try
    {
      paramProperties.load(PushConfig.context.getAssets().open(paramString));
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public static void logData(Context paramContext, String paramString1, String paramString2, String paramString3, int paramInt, Long paramLong)
  {
    DataLogger localDataLogger = new DataLogger(paramContext);
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("activity_name", paramString1);
    localContentValues.put("called_method", paramString2);
    localContentValues.put("event_time", paramLong);
    localContentValues.put("orientation_type", Integer.valueOf(paramInt));
    localContentValues.put("event_type", paramString3);
    localDataLogger.insertLogData(localContentValues);
  }

  public static HttpResponse uploadToServer(JSONArray paramJSONArray)
  {
    try
    {
      DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
      url = buildUrl("ReceiveUsageLogData", null);
      HttpPost localHttpPost = new HttpPost(url);
      String str1 = getAppID(ctx);
      String str2 = getDeviceID(ctx);
      InputStreamEntity localInputStreamEntity = new InputStreamEntity(new ByteArrayInputStream(paramJSONArray.toString().getBytes()), -1L);
      localInputStreamEntity.setChunked(true);
      localHttpPost.setEntity(localInputStreamEntity);
      localHttpPost.setHeader("APP_ID", str1);
      localHttpPost.setHeader("DEVICE_ID", str2);
      HttpResponse localHttpResponse = localDefaultHttpClient.execute(localHttpPost);
      return localHttpResponse;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.PushUtility
 * JD-Core Version:    0.6.2
 */