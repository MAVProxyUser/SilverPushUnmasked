package com.silverpush;

public abstract interface Defaults
{
  public static final String JSONHEADER = "json_header";
  public static final String TOPIC_NAME = "silverpush";
  public static final double distance = 500.0D;
  public static final String hostName = "54.243.73.253";
  public static final String hosturl = "http://54.243.73.253:8080/SilverPush/";
  public static final String locationServlet = "DeviceLocation";
  public static final long locationTime = 5000L;
  public static final String logServlet = "ReceiveUsageLogData";
  public static final String notificationResponseServlet = "NotificationResponse";
  public static final String registartionServlet = "DeviceRegistrationServlet";
  public static final String searchServlet = "ReceiveQuerySearchData";
  public static final String warName = "SilverPush";

  public static class DATABASE_COLUMNS
  {
    public static final String ACTIVITY_NAME = "activity_name";
    public static final String CALLED_METHOD = "called_method";
    public static final String CLASS_TYPE = "class_type";
    public static final String DEPART_DATE = "from_date";
    public static final String EVENT_TIME = "event_time";
    public static final String EVENT_TYPE = "event_type";
    public static final String FROM_PLACE = "from_place";
    public static final String ORIENTATION_TYPE = "orientation_type";
    public static final String RETURN_DATE = "to_date";
    public static final String TO_PLACE = "to_place";
  }

  public static class INTENT_NAME
  {
    public static final String INTENT_DEVICE_REGISTER = "com.silverpush.DEVICE_REGISTER";
    public static final String PUSH_MSG_RECEIVED_INTENT = "com.silverpush.AlertReceived";
    public static final String PUSH_MSG_RECEIVED_MSG = "com.silverpush.AlertReceived";
    public static final String PUSH_MSG_RECEIVED_TOPIC = "com.silverpush.AlertReceived";
    public static final String PUSH_PING_ACTION = "com.silverpush.mqtt.PING";
    public static final String PUSH_STATUS_INTENT = "com.silverpush.mqtt.STATUS";
  }

  public static class LOG_PARAMETER
  {
    public static final String BUTTON_CLICKED = "button_clicked";
    public static final String EventTypeClose = "close";
    public static final String EventTypeOpen = "open";
    public static final String OnCreate = "oncreate";
    public static final String OnCreateFinish = "onloaded";
    public static final String OnDestroy = "ondestroy";
    public static final String OnPause = "onpause";
    public static final String OnResume = "onresume";
    public static final String OnStart = "onstart";
    public static final String OnStop = "onstop";
  }

  public static class MESSAGE_PARAMS
  {
    public static final String APP_NAME = "appName";
    public static final String APP_PACKAGE = "appPackage";
    public static final String CALL_NUM = "call_num";
    public static final String MESSAGE = "message";
    public static final String NOTE_ID = "note_Id";
    public static final String SMS_MSG = "sms_msg";
    public static final String SMS_NUM = "sms_num";
    public static final String URL = "url";
  }

  public static class NETWORK_TYPE
  {
    public static final String CDMA = "CDMA";
    public static final String EGDE = "EDGE";
    public static final String EHRPD = "eHRPD";
    public static final String EVO_0 = "EVDO rev.0";
    public static final String EVO_A = "EVDO rev.A";
    public static final String EVO_B = "EVDO rev.B";
    public static final String GPRS = "GPRS";
    public static final String HSDPA = "HSDPA";
    public static final String HSPA = "HSPA";
    public static final String HSPA_PLUS = "HSPA_3.5G";
    public static final String HSUPA = "HSUPA";
    public static final String IDEN = "iDen";
    public static final String LTE = "LTE";
    public static final String UMTS = "UMTS";
    public static final String UNKNOWN = "Unknown";
    public static final String XRTT = "1xRTT";
  }

  public static class ORIENTATION_TYPE
  {
    public static final int ORIENTATION_LANDSCAPE = 2;
    public static final int ORIENTATION_PORTRAIT = 1;
    public static final int ORIENTATION_SQUARE = 3;
  }

  public static class REQUEST_PARAMETERS
  {
    public static final String ANDROID_ID = "ANDROID_ID";
    public static final String APP_ID = "APP_ID";
    public static final String DEVICE_ID = "DEVICE_ID";
    public static final String IMEI = "IMEI";
    public static final String IS_CLICKED = "clicked";
    public static final String IS_DELIVERED = "delivered";
    public static final String LAT = "LAT";
    public static final String LONG = "LONG";
    public static final String MAC = "MAC";
    public static final String MANUFACTURER = "MANUFACTURE";
    public static final String MODEL_NAME = "MODELNAME";
    public static final String NETWRK_TYPE = "NETWORKTYPE";
    public static final String NOTE_ID = "noteId";
    public static final String OPRATOR_NAME = "OPRATOR_NAME";
    public static final String OS_VERSION = "OS_VERSION";
    public static final String PHONE_NO = "PHONENO";
    public static final String TIME_ZONE = "TIMEZONE";
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.Defaults
 * JD-Core Version:    0.6.2
 */