package com.silverpush;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import com.ibm.mqtt.IMqttClient;
import com.ibm.mqtt.MqttClient;
import com.ibm.mqtt.MqttException;
import com.ibm.mqtt.MqttNotConnectedException;
import com.ibm.mqtt.MqttPersistence;
import com.ibm.mqtt.MqttPersistenceException;
import com.ibm.mqtt.MqttSimpleCallback;
import java.lang.ref.WeakReference;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

public class PushService extends Service
  implements MqttSimpleCallback
{
  public static final int MAX_MQTT_CLIENTID_LENGTH = 22;
  public static String Subscribeid = PushConfig.deviceId;
  public static int notification_id = 0;
  private String brokerHostName = "54.243.73.253";
  private int brokerPortNumber = 1883;
  private boolean cleanStart = false;
  private PUSHConnectionStatus connectionStatus = PUSHConnectionStatus.INITIAL;
  Context context;
  private Hashtable<String, String> dataCache = new Hashtable();
  private BackgroundDataChangeIntentReceiver dataEnabledReceiver;
  int iconId = 0;
  private short keepAliveSeconds = 1200;
  private LocalBinder<PushService> mBinder;
  private MQTTMessageReceiver messageIntentReceiver;
  private IMqttClient mqttClient = null;
  private String mqttClientId = null;
  private NetworkConnectionIntentReceiver netConnReceiver;
  private PingSender pingSender;
  private int[] qualitiesOfService = new int[1];
  private MqttPersistence usePersistence = null;

  private boolean addReceivedMessageToStore(String paramString1, String paramString2)
  {
    if (paramString2.length() == 0);
    for (String str = (String)this.dataCache.remove(paramString1); (str != null) && (str.equals(paramString2)); str = (String)this.dataCache.put(paramString1, paramString2))
      return false;
    return true;
  }

  private void broadcastReceivedMessage(String paramString1, String paramString2)
  {
    Intent localIntent = new Intent();
    localIntent.setAction("com.silverpush.AlertReceived");
    localIntent.putExtra("com.silverpush.AlertReceived", paramString1);
    localIntent.putExtra("com.silverpush.AlertReceived", paramString2);
    sendBroadcast(localIntent);
  }

  private void broadcastServiceStatus(String paramString)
  {
    Intent localIntent = new Intent();
    localIntent.setAction("com.silverpush.mqtt.STATUS");
    localIntent.putExtra("com.silverpush.AlertReceived", paramString);
    sendBroadcast(localIntent);
  }

  private boolean connectToBroker()
  {
    try
    {
      this.mqttClient.connect(this.mqttClientId, this.cleanStart, this.keepAliveSeconds);
      broadcastServiceStatus("Connected");
      this.connectionStatus = PUSHConnectionStatus.CONNECTED;
      scheduleNextPing();
      return true;
    }
    catch (MqttException localMqttException)
    {
      localMqttException.printStackTrace();
      this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_UNKNOWNREASON;
      broadcastServiceStatus("Unable to connect");
      Log.d("PushService", "Unable to connect-will retry later");
      scheduleNextPing();
    }
    return false;
  }

  private void defineConnectionToBroker(String paramString)
  {
    String str = "tcp://" + paramString + "@" + this.brokerPortNumber;
    try
    {
      this.mqttClient = MqttClient.createMqttClient(str, this.usePersistence);
      this.mqttClient.registerSimpleHandler(this);
      return;
    }
    catch (MqttException localMqttException)
    {
      this.mqttClient = null;
      this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_UNKNOWNREASON;
      broadcastServiceStatus("Invalid connection parameters");
      Log.d("PushService", "Unable to connect");
    }
  }

  private void disconnectFromBroker()
  {
    try
    {
      if (this.netConnReceiver != null)
      {
        unregisterReceiver(this.netConnReceiver);
        this.netConnReceiver = null;
      }
      if (this.pingSender != null)
      {
        unregisterReceiver(this.pingSender);
        this.pingSender = null;
      }
    }
    catch (Exception localException)
    {
      try
      {
        while (true)
        {
          if (this.mqttClient != null)
            this.mqttClient.disconnect();
          this.mqttClient = null;
          ((NotificationManager)getSystemService("notification")).cancelAll();
          return;
          localException = localException;
          Log.e("mqtt", "unregister failed", localException);
        }
      }
      catch (MqttPersistenceException localMqttPersistenceException)
      {
        while (true)
        {
          Log.e("mqtt", "disconnect failed - persistence exception", localMqttPersistenceException);
          this.mqttClient = null;
        }
      }
      finally
      {
        this.mqttClient = null;
      }
    }
  }

  private boolean isAlreadyConnected()
  {
    return (this.mqttClient != null) && (this.mqttClient.isConnected());
  }

  private boolean isOnline()
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)this.context.getSystemService("connectivity");
    return (localConnectivityManager.getActiveNetworkInfo() != null) && (localConnectivityManager.getActiveNetworkInfo().isAvailable()) && (localConnectivityManager.getActiveNetworkInfo().isConnected());
  }

  private void scheduleNextPing()
  {
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent("com.silverpush.mqtt.PING"), 134217728);
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.add(13, this.keepAliveSeconds);
    ((AlarmManager)getSystemService("alarm")).set(0, localCalendar.getTimeInMillis(), localPendingIntent);
  }

  private void subscribeToTopic()
  {
    if (this.mqttClientId == null)
      this.mqttClientId = ("silverpush" + Subscribeid);
    if (!isAlreadyConnected())
      new Thread(new Runnable()
      {
        public void run()
        {
          PushService.this.handleStart();
        }
      }).start();
    try
    {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = this.mqttClientId;
      this.mqttClient.subscribe(arrayOfString, this.qualitiesOfService);
      i = 1;
      if (i == 0)
        broadcastServiceStatus("Unable to subscribe");
      return;
    }
    catch (MqttNotConnectedException localMqttNotConnectedException)
    {
      while (true)
      {
        Log.e("mqtt", "subscribe failed - MQTT not connected", localMqttNotConnectedException);
        i = 0;
      }
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      while (true)
      {
        Log.e("mqtt", "subscribe failed - illegal argument", localIllegalArgumentException);
        i = 0;
      }
    }
    catch (MqttException localMqttException)
    {
      while (true)
      {
        Log.e("mqtt", "subscribe failed - MQTT exception", localMqttException);
        int i = 0;
      }
    }
  }

  public void connectionLost()
    throws Exception
  {
    PowerManager.WakeLock localWakeLock = ((PowerManager)getSystemService("power")).newWakeLock(1, "MQTT");
    localWakeLock.acquire();
    if (!isOnline())
    {
      this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_WAITINGFORINTERNET;
      broadcastServiceStatus("Connection lost - no network connection");
      Log.d("PushService", "Connection lost - no network connection");
    }
    while (true)
    {
      localWakeLock.release();
      return;
      this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_UNKNOWNREASON;
      broadcastServiceStatus("Connection lost - reconnecting...");
      if (connectToBroker())
        subscribeToTopic();
    }
  }

  public void disconnect()
  {
    disconnectFromBroker();
    this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_USERDISCONNECT;
    broadcastServiceStatus("Disconnected");
  }

  public PUSHConnectionStatus getConnectionStatus()
  {
    return this.connectionStatus;
  }

  void handleStart()
  {
    while (true)
    {
      try
      {
        if (this.mqttClient == null)
          defineConnectionToBroker(this.brokerHostName);
        if (!((ConnectivityManager)getSystemService("connectivity")).getBackgroundDataSetting())
        {
          this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_DATADISABLED;
          broadcastServiceStatus("Not connected - background data disabled");
          return;
        }
        rebroadcastStatus();
        rebroadcastReceivedMessages();
        if (!isAlreadyConnected())
        {
          if (!isOnline())
            break label168;
          if (connectToBroker())
            subscribeToTopic();
        }
        if (this.netConnReceiver == null)
        {
          this.netConnReceiver = new NetworkConnectionIntentReceiver(null);
          registerReceiver(this.netConnReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }
        if (this.pingSender != null)
          continue;
        this.pingSender = new PingSender();
        registerReceiver(this.pingSender, new IntentFilter("com.silverpush.mqtt.PING"));
        continue;
      }
      finally
      {
      }
      label168: this.connectionStatus = PUSHConnectionStatus.NOTCONNECTED_WAITINGFORINTERNET;
      broadcastServiceStatus("Waiting for network connection");
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    return this.mBinder;
  }

  public void onCreate()
  {
    this.iconId = PushUtility.getDrawableIcon(this);
    this.context = this;
    super.onCreate();
    if (Subscribeid == null)
      Subscribeid = PushUtility.getDeviceID(this);
    this.mqttClientId = ("silverpush" + Subscribeid);
    this.connectionStatus = PUSHConnectionStatus.INITIAL;
    this.mBinder = new LocalBinder(this);
    registerReceiver(this.dataEnabledReceiver, new IntentFilter("android.net.conn.BACKGROUND_DATA_SETTING_CHANGED"));
    defineConnectionToBroker(this.brokerHostName);
    this.messageIntentReceiver = new MQTTMessageReceiver();
    IntentFilter localIntentFilter = new IntentFilter("com.silverpush.AlertReceived");
    localIntentFilter.addAction("com.action.CALL_SERVER_LOG_UPDATE");
    registerReceiver(this.messageIntentReceiver, localIntentFilter);
    new Thread(new Runnable()
    {
      public void run()
      {
        PushService.this.handleStart();
      }
    }).start();
  }

  public void onDestroy()
  {
    disconnectFromBroker();
    broadcastServiceStatus("Disconnected");
    if (this.dataEnabledReceiver != null)
    {
      unregisterReceiver(this.dataEnabledReceiver);
      this.dataEnabledReceiver = null;
    }
    if (this.mBinder != null)
    {
      this.mBinder.close();
      this.mBinder = null;
    }
    super.onDestroy();
  }

  public void onStart(Intent paramIntent, int paramInt)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        PushService.this.handleStart();
      }
    }
    , "Pushservice").start();
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        PushService.this.handleStart();
      }
    }
    , "Pushservice").start();
    return 1;
  }

  public void publishArrived(String paramString, byte[] paramArrayOfByte, int paramInt, boolean paramBoolean)
  {
    Intent localIntent = new Intent();
    localIntent.setAction("com.silverpush.AlertReceived");
    localIntent.putExtra("data", new String(paramArrayOfByte));
    sendBroadcast(localIntent);
    PowerManager.WakeLock localWakeLock = ((PowerManager)getSystemService("power")).newWakeLock(1, "PUSH_SERVICE");
    localWakeLock.acquire();
    scheduleNextPing();
    localWakeLock.release();
  }

  public void rebroadcastReceivedMessages()
  {
    Enumeration localEnumeration = this.dataCache.keys();
    while (true)
    {
      if (!localEnumeration.hasMoreElements())
        return;
      String str = (String)localEnumeration.nextElement();
      broadcastReceivedMessage(str, (String)this.dataCache.get(str));
    }
  }

  public void rebroadcastStatus()
  {
    String str = "";
    switch ($SWITCH_TABLE$com$silverpush$PushService$PUSHConnectionStatus()[this.connectionStatus.ordinal()])
    {
    default:
    case 1:
    case 2:
    case 3:
    case 7:
    case 5:
    case 6:
    case 4:
    }
    while (true)
    {
      broadcastServiceStatus(str);
      return;
      str = "Please wait";
      continue;
      str = "Connecting...";
      continue;
      str = "Connected";
      continue;
      str = "Not connected - waiting for network connection";
      continue;
      str = "Disconnected";
      continue;
      str = "Not connected - background data disabled";
      continue;
      str = "Unable to connect";
    }
  }

  private class BackgroundDataChangeIntentReceiver extends BroadcastReceiver
  {
    private BackgroundDataChangeIntentReceiver()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      PowerManager.WakeLock localWakeLock = ((PowerManager)PushService.this.getSystemService("power")).newWakeLock(1, "PUSH_SERVICE");
      localWakeLock.acquire();
      if (((ConnectivityManager)PushService.this.getSystemService("connectivity")).getBackgroundDataSetting())
        new Thread(new Runnable()
        {
          public void run()
          {
            PushService.this.defineConnectionToBroker(PushService.this.brokerHostName);
            PushService.this.handleStart();
          }
        }).start();
      while (true)
      {
        localWakeLock.release();
        return;
        PushService.this.connectionStatus = PushService.PUSHConnectionStatus.NOTCONNECTED_DATADISABLED;
        PushService.this.broadcastServiceStatus("Not connected - background data disabled");
        PushService.this.disconnectFromBroker();
      }
    }
  }

  public class LocalBinder<S> extends Binder
  {
    private WeakReference<S> mService;

    public LocalBinder()
    {
      Object localObject;
      this.mService = new WeakReference(localObject);
    }

    public void close()
    {
      this.mService = null;
    }

    public S getService()
    {
      return this.mService.get();
    }
  }

  public class MQTTMessageReceiver extends BroadcastReceiver
  {
    public MQTTMessageReceiver()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      String str1;
      NotificationManager localNotificationManager;
      Notification localNotification;
      HashMap localHashMap;
      String[] arrayOfString;
      int j;
      String str3;
      String str4;
      int k;
      PendingIntent localPendingIntent;
      if (paramIntent.getAction().equals("com.silverpush.AlertReceived"))
      {
        str1 = paramIntent.getStringExtra("data");
        localNotificationManager = (NotificationManager)PushService.this.getSystemService("notification");
        localNotification = new Notification(PushService.this.iconId, "A new notification", System.currentTimeMillis());
        localNotification.defaults = (0x4 | localNotification.defaults);
        localNotification.defaults = (0x1 | localNotification.defaults);
        localNotification.flags = (0x10 | localNotification.flags);
        localHashMap = new HashMap();
        arrayOfString = str1.split("&");
        int i = arrayOfString.length;
        j = 0;
        if (j < i)
          break label294;
        str3 = (String)localHashMap.get("message");
        str4 = (String)localHashMap.get("appName");
        k = Integer.parseInt((String)localHashMap.get("note_Id"));
        PushUtility.executeURL(PushUtility.buildUrlForNotification(k, 1, 0, PushService.Subscribeid));
        if (!str1.contains("url"))
          break label331;
        StringBuilder localStringBuilder1 = new StringBuilder("http://");
        String str5 = (String)localHashMap.get("url");
        Intent localIntent1 = new Intent("android.intent.action.VIEW");
        localIntent1.setData(Uri.parse(str5));
        localPendingIntent = PendingIntent.getActivity(paramContext, 0, localIntent1, 1073741824);
      }
      while (true)
      {
        localNotification.setLatestEventInfo(paramContext, str4, str3, localPendingIntent);
        localNotification.number = (1 + localNotification.number);
        int m = 1 + PushService.notification_id;
        PushService.notification_id = m;
        localNotificationManager.notify(m, localNotification);
        return;
        label294: String str2 = arrayOfString[j];
        localHashMap.put(str2.split("=")[0], str2.split("=")[1]);
        j++;
        break;
        label331: if (str1.contains("call"))
        {
          StringBuilder localStringBuilder2 = new StringBuilder("tel:");
          Uri localUri1 = Uri.parse((String)localHashMap.get("call_num"));
          Intent localIntent2 = new Intent("android.intent.action.DIAL", localUri1);
          localPendingIntent = PendingIntent.getActivity(paramContext, 0, localIntent2, 1073741824);
        }
        else if (str1.contains("sms"))
        {
          String str7 = (String)localHashMap.get("sms_msg");
          StringBuilder localStringBuilder3 = new StringBuilder("smsto:");
          Uri localUri2 = Uri.parse((String)localHashMap.get("sms_num"));
          Intent localIntent4 = new Intent("android.intent.action.VIEW", localUri2);
          localIntent4.putExtra("sms_body", str7);
          localPendingIntent = PendingIntent.getActivity(paramContext, 0, localIntent4, 1073741824);
        }
        else
        {
          String str6 = (String)localHashMap.get("appPackage");
          Intent localIntent3 = new Intent(PushService.this, RegistrationReciever.class);
          localIntent3.setAction("com.silverpush.START");
          localIntent3.putExtra("packageName", str6);
          localIntent3.putExtra("noteId", k);
          localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent3, 1073741824);
        }
      }
    }
  }

  private class NetworkConnectionIntentReceiver extends BroadcastReceiver
  {
    private NetworkConnectionIntentReceiver()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      PowerManager.WakeLock localWakeLock = ((PowerManager)PushService.this.getSystemService("power")).newWakeLock(1, "PUSH_SERVICE");
      localWakeLock.acquire();
      new Thread(new Runnable()
      {
        public void run()
        {
          if ((PushService.this.isOnline()) && (PushService.this.connectToBroker()))
            PushService.this.subscribeToTopic();
        }
      }).start();
      localWakeLock.release();
    }
  }

  public static enum PUSHConnectionStatus
  {
    static
    {
      CONNECTING = new PUSHConnectionStatus("CONNECTING", 1);
      CONNECTED = new PUSHConnectionStatus("CONNECTED", 2);
      NOTCONNECTED_WAITINGFORINTERNET = new PUSHConnectionStatus("NOTCONNECTED_WAITINGFORINTERNET", 3);
      NOTCONNECTED_USERDISCONNECT = new PUSHConnectionStatus("NOTCONNECTED_USERDISCONNECT", 4);
      NOTCONNECTED_DATADISABLED = new PUSHConnectionStatus("NOTCONNECTED_DATADISABLED", 5);
      NOTCONNECTED_UNKNOWNREASON = new PUSHConnectionStatus("NOTCONNECTED_UNKNOWNREASON", 6);
      PUSHConnectionStatus[] arrayOfPUSHConnectionStatus = new PUSHConnectionStatus[7];
      arrayOfPUSHConnectionStatus[0] = INITIAL;
      arrayOfPUSHConnectionStatus[1] = CONNECTING;
      arrayOfPUSHConnectionStatus[2] = CONNECTED;
      arrayOfPUSHConnectionStatus[3] = NOTCONNECTED_WAITINGFORINTERNET;
      arrayOfPUSHConnectionStatus[4] = NOTCONNECTED_USERDISCONNECT;
      arrayOfPUSHConnectionStatus[5] = NOTCONNECTED_DATADISABLED;
      arrayOfPUSHConnectionStatus[6] = NOTCONNECTED_UNKNOWNREASON;
    }
  }

  public class PingSender extends BroadcastReceiver
  {
    public PingSender()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      while (true)
      {
        try
        {
          PushService.this.mqttClient.ping();
          if ((!PushService.this.isAlreadyConnected()) && (PushService.this.connectToBroker()))
            PushService.this.subscribeToTopic();
          PushService.this.scheduleNextPing();
          return;
        }
        catch (MqttException localMqttException)
        {
          Log.e("mqtt", "ping failed - PushService client exception", localMqttException);
        }
        try
        {
          PushService.this.mqttClient.disconnect();
          if (!PushService.this.connectToBroker())
            continue;
          PushService.this.subscribeToTopic();
        }
        catch (MqttPersistenceException localMqttPersistenceException)
        {
          while (true)
            Log.e("mqtt", "disconnect failed - persistence exception", localMqttPersistenceException);
        }
      }
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.PushService
 * JD-Core Version:    0.6.2
 */