package com.silverpush.location;

import android.app.Service;
import android.content.Intent;
import android.location.Criteria;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import com.silverpush.PushUtility;

public class Location extends Service
  implements LocationListener
{
  android.location.Location loc;
  LocationManager locm;

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    try
    {
      this.locm = ((LocationManager)getSystemService("location"));
      Criteria localCriteria = new Criteria();
      localCriteria.setAccuracy(2);
      localCriteria.setAltitudeRequired(false);
      localCriteria.setBearingRequired(false);
      localCriteria.setCostAllowed(true);
      String str = this.locm.getBestProvider(localCriteria, true);
      this.loc = this.locm.getLastKnownLocation(str);
      if (this.loc == null)
        this.locm.requestLocationUpdates("network", 5000L, 500.0F, this);
      this.loc = this.locm.getLastKnownLocation(str);
      this.locm.requestLocationUpdates(str, 5000L, 500.0F, this);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public void onLocationChanged(android.location.Location paramLocation)
  {
    PushUtility.executeURL(PushUtility.buildUrl("DeviceLocation", paramLocation));
  }

  public void onProviderDisabled(String paramString)
  {
  }

  public void onProviderEnabled(String paramString)
  {
  }

  public void onStart(Intent paramIntent, int paramInt)
  {
    super.onStart(paramIntent, paramInt);
  }

  public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com.silverpush.silverapp-4_dex2jar.jar
 * Qualified Name:     com.silverpush.location.Location
 * JD-Core Version:    0.6.2
 */