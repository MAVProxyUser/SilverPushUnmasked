package in.excogitation.lib_simplehttpclient;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "in.excogitation.lib_simplehttpclient";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.0";
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com silverpush bannerpixelizationtest_apkpure.com.jar
 * Qualified Name:     in.excogitation.lib_simplehttpclient.BuildConfig
 * JD-Core Version:    0.6.2
 */