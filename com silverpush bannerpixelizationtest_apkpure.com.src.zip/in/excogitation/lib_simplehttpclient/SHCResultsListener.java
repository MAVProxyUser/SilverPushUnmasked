package in.excogitation.lib_simplehttpclient;

public abstract interface SHCResultsListener
{
  public abstract void onFailure(String paramString);

  public abstract void onSuccess(String paramString);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com silverpush bannerpixelizationtest_apkpure.com.jar
 * Qualified Name:     in.excogitation.lib_simplehttpclient.SHCResultsListener
 * JD-Core Version:    0.6.2
 */