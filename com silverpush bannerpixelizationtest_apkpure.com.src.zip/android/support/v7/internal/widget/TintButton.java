package android.support.v7.internal.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

public class TintButton extends Button
{
  private static final int[] TINT_ATTRS = { 16842964, 16842804 };
  private final TintManager mTintManager;

  public TintButton(Context paramContext)
  {
    this(paramContext, null);
  }

  public TintButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16842824);
  }

  public TintButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, TINT_ATTRS, paramInt, 0);
    if (localTintTypedArray.hasValue(0))
      setBackgroundDrawable(localTintTypedArray.getDrawable(0));
    this.mTintManager = localTintTypedArray.getTintManager();
  }

  public void setBackgroundResource(int paramInt)
  {
    setBackgroundDrawable(this.mTintManager.getDrawable(paramInt));
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com silverpush bannerpixelizationtest_apkpure.com.jar
 * Qualified Name:     android.support.v7.internal.widget.TintButton
 * JD-Core Version:    0.6.2
 */