package android.support.v4.media;

public class TransportStateListener
{
  public void onPlayingChanged(TransportController paramTransportController)
  {
  }

  public void onTransportControlsChanged(TransportController paramTransportController)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com silverpush bannerpixelizationtest_apkpure.com.jar
 * Qualified Name:     android.support.v4.media.TransportStateListener
 * JD-Core Version:    0.6.2
 */