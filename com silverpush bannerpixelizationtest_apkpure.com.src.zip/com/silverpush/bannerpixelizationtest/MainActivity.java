package com.silverpush.bannerpixelizationtest;

import android.annotation.TargetApi;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import in.excogitation.lib_simplehttpclient.SHCResultsListener;
import in.excogitation.lib_simplehttpclient.SimpleHttpClient;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends ActionBarActivity
{
  private String SERVER = "http://54.243.149.109:8021/";
  ArrayAdapter<String> adapter;
  private boolean enableDebugging = false;
  SHCResultsListener httpListener = new SHCResultsListener()
  {
    public void onFailure(String paramAnonymousString)
    {
    }

    public void onSuccess(String paramAnonymousString)
    {
      System.out.println(paramAnonymousString);
      if (paramAnonymousString != null)
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          try
          {
            if (localJSONObject.getInt("success") == 1)
            {
              if (MainActivity.this.enableDebugging)
                System.out.println(localJSONObject);
              MainActivity.this.txt_status.setText("Server found a match successfully!");
              String str2 = Uri.decode(localJSONObject.optString("img_small_url", "NA"));
              String str3 = Uri.decode(localJSONObject.optString("img_big_url", "NA"));
              String str4 = localJSONObject.optString("ad_name", "NA");
              if (!str4.equals("NA"))
                MainActivity.this.txt_status.setText("Loaded ads for " + str4);
              if (!str3.equals("NA"))
                MainActivity.access$102(MainActivity.this, str3);
              if (!str2.equals("N/A"))
                MainActivity.access$002(MainActivity.this, str2);
            }
            else
            {
              String str1 = localJSONObject.optString("error", "N/A");
              MainActivity.this.txt_status.setText(str1);
              MainActivity.this.resetView();
              return;
            }
          }
          catch (JSONException localJSONException1)
          {
            label207: localJSONException1.printStackTrace();
            return;
          }
        }
        catch (JSONException localJSONException2)
        {
          break label207;
        }
    }
  };
  SimpleHttpClient httpclient;
  ArrayList<String> listItems = new ArrayList();
  ListView myListView;
  String tagVal;
  private String tag_big_url = "NA";
  private String tag_small_url = "NA";
  TextView txt_ad_type;
  TextView txt_status;
  WebView wv;

  public void onBackPressed()
  {
    finish();
    overridePendingTransition(17432578, 17432579);
  }

  @TargetApi(11)
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130968598);
    this.txt_ad_type = ((TextView)findViewById(2131296319));
    this.txt_status = ((TextView)findViewById(2131296323));
    this.httpclient = new SimpleHttpClient();
    this.httpclient.setMethod(1);
    this.httpclient.setMode(2);
    this.httpclient.setUrl(this.SERVER + "pattern");
    this.wv = ((WebView)findViewById(2131296322));
    this.wv.getSettings().setJavaScriptEnabled(true);
    resetView();
    this.listItems.add("Tag : 320x50");
    this.listItems.add("Tag : 300x250");
    this.myListView = ((ListView)findViewById(2131296320));
    this.adapter = new ArrayAdapter(this, 17367043, this.listItems);
    this.myListView.setAdapter(this.adapter);
    this.myListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
    {
      public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
      {
        switch (paramAnonymousInt)
        {
        default:
          return;
        case 0:
          if (!MainActivity.this.tag_small_url.equals("NA"))
          {
            MainActivity.this.tagVal = MainActivity.this.tag_small_url;
            String str2 = "<html><body>" + MainActivity.this.tagVal + "</body></html>";
            MainActivity.this.wv.loadData(str2, "text/html", "utf-8");
            return;
          }
          Toast.makeText(MainActivity.this, "Select a type of tag from toolbar!", 0).show();
          return;
        case 1:
        }
        if (!MainActivity.this.tag_big_url.equals("NA"))
        {
          MainActivity.this.tagVal = MainActivity.this.tag_big_url;
          String str1 = "<html><body>" + MainActivity.this.tagVal + "</body></html>";
          MainActivity.this.wv.loadData(str1, "text/html", "utf-8");
          return;
        }
        Toast.makeText(MainActivity.this, "Select a type of tag from toolbar!", 0).show();
      }
    });
  }

  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131558400, paramMenu);
    return true;
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131296324)
    {
      resetView();
      this.txt_ad_type.setText("Retina Ads");
      HashMap localHashMap2 = new HashMap();
      localHashMap2.put("pattern", "RETINA");
      this.httpclient.setParams(localHashMap2);
      this.httpclient.makeRequest(this, this.httpListener);
      return true;
    }
    if (i == 2131296325)
    {
      resetView();
      this.txt_ad_type.setText("HTML Ads");
      HashMap localHashMap1 = new HashMap();
      localHashMap1.put("pattern", "HTML");
      this.httpclient.setParams(localHashMap1);
      this.httpclient.makeRequest(this, this.httpListener);
      return true;
    }
    if (i == 2131296326)
    {
      Toast.makeText(this, "Resetting Views !!", 0).show();
      resetView();
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }

  void resetView()
  {
    this.txt_ad_type.setText("Banner Ad Type");
    this.txt_status.setText("...Status...");
    this.tag_big_url = "NA";
    this.tag_small_url = "NA";
    this.wv.loadData("<html><head><style>body{background-color:#ce3333;color:white;}</style></head><body>Click on the links to load the banner ad (^.^)</body></html>", "text/html", "utf-8");
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/SilverPushUnmasked/com silverpush bannerpixelizationtest_apkpure.com.jar
 * Qualified Name:     com.silverpush.bannerpixelizationtest.MainActivity
 * JD-Core Version:    0.6.2
 */