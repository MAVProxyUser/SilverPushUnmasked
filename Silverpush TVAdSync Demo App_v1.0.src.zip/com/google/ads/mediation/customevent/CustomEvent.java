package com.google.ads.mediation.customevent;

@Deprecated
public abstract interface CustomEvent
{
  public abstract void destroy();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEvent
 * JD-Core Version:    0.6.2
 */