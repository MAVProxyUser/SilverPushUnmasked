package com.google.android.gms.ads.identifier;

import android.content.Context;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.internal.zzx;
import com.google.android.gms.common.zza;
import com.google.android.gms.internal.zzav;
import com.google.android.gms.internal.zzav.zza;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class AdvertisingIdClient
{
  private static boolean zzoh = false;
  private final Context mContext;
  zza zzob;
  zzav zzoc;
  boolean zzod;
  Object zzoe = new Object();
  zza zzof;
  final long zzog;

  public AdvertisingIdClient(Context paramContext)
  {
    this(paramContext, 30000L);
  }

  public AdvertisingIdClient(Context paramContext, long paramLong)
  {
    zzx.zzw(paramContext);
    this.mContext = paramContext;
    this.zzod = false;
    this.zzog = paramLong;
  }

  public static Info getAdvertisingIdInfo(Context paramContext)
    throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
  {
    AdvertisingIdClient localAdvertisingIdClient = new AdvertisingIdClient(paramContext, -1L);
    try
    {
      localAdvertisingIdClient.zzb(false);
      Info localInfo = localAdvertisingIdClient.getInfo();
      return localInfo;
    }
    finally
    {
      localAdvertisingIdClient.finish();
    }
  }

  public static void setShouldSkipGmsCoreVersionCheck(boolean paramBoolean)
  {
    zzoh = paramBoolean;
  }

  static zzav zza(Context paramContext, zza paramzza)
    throws IOException
  {
    try
    {
      zzav localzzav = zzav.zza.zzb(paramzza.zzno());
      return localzzav;
    }
    catch (InterruptedException localInterruptedException)
    {
      throw new IOException("Interrupted exception");
    }
    catch (Throwable localThrowable)
    {
      throw new IOException(localThrowable);
    }
  }

  private void zzaJ()
  {
    synchronized (this.zzoe)
    {
      if (this.zzof != null)
        this.zzof.cancel();
    }
    try
    {
      this.zzof.join();
      label28: if (this.zzog > 0L)
        this.zzof = new zza(this, this.zzog);
      return;
      localObject2 = finally;
      throw localObject2;
    }
    catch (InterruptedException localInterruptedException)
    {
      break label28;
    }
  }

  // ERROR //
  static zza zzo(Context paramContext)
    throws IOException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 119	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   4: ldc 121
    //   6: iconst_0
    //   7: invokevirtual 127	android/content/pm/PackageManager:getPackageInfo	(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   10: pop
    //   11: getstatic 23	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzoh	Z
    //   14: ifeq +67 -> 81
    //   17: ldc 129
    //   19: ldc 131
    //   21: invokestatic 137	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   24: pop
    //   25: invokestatic 143	com/google/android/gms/common/GoogleApiAvailability:getInstance	()Lcom/google/android/gms/common/GoogleApiAvailability;
    //   28: aload_0
    //   29: invokevirtual 147	com/google/android/gms/common/GoogleApiAvailability:isGooglePlayServicesAvailable	(Landroid/content/Context;)I
    //   32: tableswitch	default:+28 -> 60, 0:+53->85, 1:+28->60, 2:+53->85
    //   61: nop
    //   62: aaload
    //   63: dup
    //   64: ldc 149
    //   66: invokespecial 92	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   69: athrow
    //   70: astore_1
    //   71: new 54	com/google/android/gms/common/GooglePlayServicesNotAvailableException
    //   74: dup
    //   75: bipush 9
    //   77: invokespecial 152	com/google/android/gms/common/GooglePlayServicesNotAvailableException:<init>	(I)V
    //   80: athrow
    //   81: aload_0
    //   82: invokestatic 157	com/google/android/gms/common/GooglePlayServicesUtil:zzaa	(Landroid/content/Context;)V
    //   85: new 78	com/google/android/gms/common/zza
    //   88: dup
    //   89: invokespecial 158	com/google/android/gms/common/zza:<init>	()V
    //   92: astore 4
    //   94: new 160	android/content/Intent
    //   97: dup
    //   98: ldc 162
    //   100: invokespecial 163	android/content/Intent:<init>	(Ljava/lang/String;)V
    //   103: astore 5
    //   105: aload 5
    //   107: ldc 165
    //   109: invokevirtual 169	android/content/Intent:setPackage	(Ljava/lang/String;)Landroid/content/Intent;
    //   112: pop
    //   113: invokestatic 175	com/google/android/gms/common/stats/zzb:zzqh	()Lcom/google/android/gms/common/stats/zzb;
    //   116: aload_0
    //   117: aload 5
    //   119: aload 4
    //   121: iconst_1
    //   122: invokevirtual 178	com/google/android/gms/common/stats/zzb:zza	(Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   125: istore 8
    //   127: iload 8
    //   129: ifeq +28 -> 157
    //   132: aload 4
    //   134: areturn
    //   135: astore_3
    //   136: new 50	java/io/IOException
    //   139: dup
    //   140: aload_3
    //   141: invokespecial 95	java/io/IOException:<init>	(Ljava/lang/Throwable;)V
    //   144: athrow
    //   145: astore 7
    //   147: new 50	java/io/IOException
    //   150: dup
    //   151: aload 7
    //   153: invokespecial 95	java/io/IOException:<init>	(Ljava/lang/Throwable;)V
    //   156: athrow
    //   157: new 50	java/io/IOException
    //   160: dup
    //   161: ldc 180
    //   163: invokespecial 92	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   166: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	11	70	android/content/pm/PackageManager$NameNotFoundException
    //   81	85	135	com/google/android/gms/common/GooglePlayServicesNotAvailableException
    //   113	127	145	java/lang/Throwable
  }

  protected void finalize()
    throws Throwable
  {
    finish();
    super.finalize();
  }

  // ERROR //
  public void finish()
  {
    // Byte code:
    //   0: ldc 187
    //   2: invokestatic 190	com/google/android/gms/common/internal/zzx:zzcj	(Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 42	com/google/android/gms/ads/identifier/AdvertisingIdClient:mContext	Landroid/content/Context;
    //   11: ifnull +10 -> 21
    //   14: aload_0
    //   15: getfield 192	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzob	Lcom/google/android/gms/common/zza;
    //   18: ifnonnull +6 -> 24
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: aload_0
    //   25: getfield 44	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzod	Z
    //   28: ifeq +17 -> 45
    //   31: invokestatic 175	com/google/android/gms/common/stats/zzb:zzqh	()Lcom/google/android/gms/common/stats/zzb;
    //   34: aload_0
    //   35: getfield 42	com/google/android/gms/ads/identifier/AdvertisingIdClient:mContext	Landroid/content/Context;
    //   38: aload_0
    //   39: getfield 192	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzob	Lcom/google/android/gms/common/zza;
    //   42: invokevirtual 195	com/google/android/gms/common/stats/zzb:zza	(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    //   45: aload_0
    //   46: iconst_0
    //   47: putfield 44	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzod	Z
    //   50: aload_0
    //   51: aconst_null
    //   52: putfield 197	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzoc	Lcom/google/android/gms/internal/zzav;
    //   55: aload_0
    //   56: aconst_null
    //   57: putfield 192	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzob	Lcom/google/android/gms/common/zza;
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: astore_1
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_1
    //   67: athrow
    //   68: astore_2
    //   69: ldc 199
    //   71: ldc 201
    //   73: aload_2
    //   74: invokestatic 205	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   77: pop
    //   78: goto -33 -> 45
    //
    // Exception table:
    //   from	to	target	type
    //   7	21	63	finally
    //   21	23	63	finally
    //   24	45	63	finally
    //   45	62	63	finally
    //   64	66	63	finally
    //   69	78	63	finally
    //   24	45	68	java/lang/IllegalArgumentException
  }

  // ERROR //
  public Info getInfo()
    throws IOException
  {
    // Byte code:
    //   0: ldc 187
    //   2: invokestatic 190	com/google/android/gms/common/internal/zzx:zzcj	(Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 44	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzod	Z
    //   11: ifne +91 -> 102
    //   14: aload_0
    //   15: getfield 34	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzoe	Ljava/lang/Object;
    //   18: astore 7
    //   20: aload 7
    //   22: monitorenter
    //   23: aload_0
    //   24: getfield 98	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzof	Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$zza;
    //   27: ifnull +13 -> 40
    //   30: aload_0
    //   31: getfield 98	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzof	Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$zza;
    //   34: invokevirtual 213	com/google/android/gms/ads/identifier/AdvertisingIdClient$zza:zzaK	()Z
    //   37: ifne +26 -> 63
    //   40: new 50	java/io/IOException
    //   43: dup
    //   44: ldc 215
    //   46: invokespecial 92	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   49: athrow
    //   50: astore 8
    //   52: aload 7
    //   54: monitorexit
    //   55: aload 8
    //   57: athrow
    //   58: astore_1
    //   59: aload_0
    //   60: monitorexit
    //   61: aload_1
    //   62: athrow
    //   63: aload 7
    //   65: monitorexit
    //   66: aload_0
    //   67: iconst_0
    //   68: invokevirtual 62	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzb	(Z)V
    //   71: aload_0
    //   72: getfield 44	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzod	Z
    //   75: ifne +27 -> 102
    //   78: new 50	java/io/IOException
    //   81: dup
    //   82: ldc 217
    //   84: invokespecial 92	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   87: athrow
    //   88: astore 9
    //   90: new 50	java/io/IOException
    //   93: dup
    //   94: ldc 217
    //   96: aload 9
    //   98: invokespecial 220	java/io/IOException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   101: athrow
    //   102: aload_0
    //   103: getfield 192	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzob	Lcom/google/android/gms/common/zza;
    //   106: invokestatic 40	com/google/android/gms/common/internal/zzx:zzw	(Ljava/lang/Object;)Ljava/lang/Object;
    //   109: pop
    //   110: aload_0
    //   111: getfield 197	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzoc	Lcom/google/android/gms/internal/zzav;
    //   114: invokestatic 40	com/google/android/gms/common/internal/zzx:zzw	(Ljava/lang/Object;)Ljava/lang/Object;
    //   117: pop
    //   118: new 222	com/google/android/gms/ads/identifier/AdvertisingIdClient$Info
    //   121: dup
    //   122: aload_0
    //   123: getfield 197	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzoc	Lcom/google/android/gms/internal/zzav;
    //   126: invokeinterface 228 1 0
    //   131: aload_0
    //   132: getfield 197	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzoc	Lcom/google/android/gms/internal/zzav;
    //   135: iconst_1
    //   136: invokeinterface 232 2 0
    //   141: invokespecial 235	com/google/android/gms/ads/identifier/AdvertisingIdClient$Info:<init>	(Ljava/lang/String;Z)V
    //   144: astore 4
    //   146: aload_0
    //   147: monitorexit
    //   148: aload_0
    //   149: invokespecial 237	com/google/android/gms/ads/identifier/AdvertisingIdClient:zzaJ	()V
    //   152: aload 4
    //   154: areturn
    //   155: astore 5
    //   157: ldc 199
    //   159: ldc 239
    //   161: aload 5
    //   163: invokestatic 205	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   166: pop
    //   167: new 50	java/io/IOException
    //   170: dup
    //   171: ldc 241
    //   173: invokespecial 92	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   176: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   23	40	50	finally
    //   40	50	50	finally
    //   52	55	50	finally
    //   63	66	50	finally
    //   7	23	58	finally
    //   55	58	58	finally
    //   59	61	58	finally
    //   66	71	58	finally
    //   71	88	58	finally
    //   90	102	58	finally
    //   102	118	58	finally
    //   118	146	58	finally
    //   146	148	58	finally
    //   157	177	58	finally
    //   66	71	88	java/lang/Exception
    //   118	146	155	android/os/RemoteException
  }

  public void start()
    throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
  {
    zzb(true);
  }

  protected void zzb(boolean paramBoolean)
    throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
  {
    zzx.zzcj("Calling this from your main thread can lead to deadlock");
    try
    {
      if (this.zzod)
        finish();
      this.zzob = zzo(this.mContext);
      this.zzoc = zza(this.mContext, this.zzob);
      this.zzod = true;
      if (paramBoolean)
        zzaJ();
      return;
    }
    finally
    {
    }
  }

  public static final class Info
  {
    private final String zzom;
    private final boolean zzon;

    public Info(String paramString, boolean paramBoolean)
    {
      this.zzom = paramString;
      this.zzon = paramBoolean;
    }

    public String getId()
    {
      return this.zzom;
    }

    public boolean isLimitAdTrackingEnabled()
    {
      return this.zzon;
    }

    public String toString()
    {
      return "{" + this.zzom + "}" + this.zzon;
    }
  }

  static class zza extends Thread
  {
    private WeakReference<AdvertisingIdClient> zzoi;
    private long zzoj;
    CountDownLatch zzok;
    boolean zzol;

    public zza(AdvertisingIdClient paramAdvertisingIdClient, long paramLong)
    {
      this.zzoi = new WeakReference(paramAdvertisingIdClient);
      this.zzoj = paramLong;
      this.zzok = new CountDownLatch(1);
      this.zzol = false;
      start();
    }

    private void disconnect()
    {
      AdvertisingIdClient localAdvertisingIdClient = (AdvertisingIdClient)this.zzoi.get();
      if (localAdvertisingIdClient != null)
      {
        localAdvertisingIdClient.finish();
        this.zzol = true;
      }
    }

    public void cancel()
    {
      this.zzok.countDown();
    }

    public void run()
    {
      try
      {
        if (!this.zzok.await(this.zzoj, TimeUnit.MILLISECONDS))
          disconnect();
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        disconnect();
      }
    }

    public boolean zzaK()
    {
      return this.zzol;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.identifier.AdvertisingIdClient
 * JD-Core Version:    0.6.2
 */