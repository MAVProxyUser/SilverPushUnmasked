package com.google.android.gms.ads.doubleclick;

public abstract interface OnCustomRenderedAdLoadedListener
{
  public abstract void onCustomRenderedAdLoaded(CustomRenderedAd paramCustomRenderedAd);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.doubleclick.OnCustomRenderedAdLoadedListener
 * JD-Core Version:    0.6.2
 */