package com.google.android.gms.ads.doubleclick;

public abstract interface AppEventListener
{
  public abstract void onAppEvent(String paramString1, String paramString2);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.doubleclick.AppEventListener
 * JD-Core Version:    0.6.2
 */