package com.google.android.gms.ads;

public abstract class AdListener
{
  public void onAdClosed()
  {
  }

  public void onAdFailedToLoad(int paramInt)
  {
  }

  public void onAdLeftApplication()
  {
  }

  public void onAdLoaded()
  {
  }

  public void onAdOpened()
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.AdListener
 * JD-Core Version:    0.6.2
 */