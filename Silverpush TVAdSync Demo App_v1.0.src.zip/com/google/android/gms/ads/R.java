package com.google.android.gms.ads;

public final class R
{
  public static final class attr
  {
    public static final int adSize = 2130771999;
    public static final int adSizes = 2130772000;
    public static final int adUnitId = 2130772001;
    public static final int circleCrop = 2130772023;
    public static final int imageAspectRatio = 2130772022;
    public static final int imageAspectRatioAdjust = 2130772021;
  }

  public static final class color
  {
    public static final int common_action_bar_splitter = 2131427349;
    public static final int common_signin_btn_dark_text_default = 2131427350;
    public static final int common_signin_btn_dark_text_disabled = 2131427351;
    public static final int common_signin_btn_dark_text_focused = 2131427352;
    public static final int common_signin_btn_dark_text_pressed = 2131427353;
    public static final int common_signin_btn_default_background = 2131427354;
    public static final int common_signin_btn_light_text_default = 2131427355;
    public static final int common_signin_btn_light_text_disabled = 2131427356;
    public static final int common_signin_btn_light_text_focused = 2131427357;
    public static final int common_signin_btn_light_text_pressed = 2131427358;
    public static final int common_signin_btn_text_dark = 2131427409;
    public static final int common_signin_btn_text_light = 2131427410;
  }

  public static final class drawable
  {
    public static final int common_full_open_on_phone = 2130837568;
    public static final int common_ic_googleplayservices = 2130837569;
  }

  public static final class id
  {
    public static final int adjust_height = 2131492891;
    public static final int adjust_width = 2131492892;
    public static final int none = 2131492878;
    public static final int normal = 2131492874;
    public static final int wrap_content = 2131492898;
  }

  public static final class integer
  {
    public static final int google_play_services_version = 2131361796;
  }

  public static final class raw
  {
  }

  public static final class string
  {
    public static final int accept = 2131099696;
    public static final int auth_google_play_services_client_facebook_display_name = 2131099698;
    public static final int auth_google_play_services_client_google_display_name = 2131099699;
    public static final int common_android_wear_notification_needs_update_text = 2131099665;
    public static final int common_android_wear_update_text = 2131099666;
    public static final int common_android_wear_update_title = 2131099667;
    public static final int common_google_play_services_api_unavailable_text = 2131099668;
    public static final int common_google_play_services_enable_button = 2131099669;
    public static final int common_google_play_services_enable_text = 2131099670;
    public static final int common_google_play_services_enable_title = 2131099671;
    public static final int common_google_play_services_error_notification_requested_by_msg = 2131099672;
    public static final int common_google_play_services_install_button = 2131099673;
    public static final int common_google_play_services_install_text_phone = 2131099674;
    public static final int common_google_play_services_install_text_tablet = 2131099675;
    public static final int common_google_play_services_install_title = 2131099676;
    public static final int common_google_play_services_invalid_account_text = 2131099677;
    public static final int common_google_play_services_invalid_account_title = 2131099678;
    public static final int common_google_play_services_needs_enabling_title = 2131099679;
    public static final int common_google_play_services_network_error_text = 2131099680;
    public static final int common_google_play_services_network_error_title = 2131099681;
    public static final int common_google_play_services_notification_needs_update_title = 2131099682;
    public static final int common_google_play_services_notification_ticker = 2131099683;
    public static final int common_google_play_services_sign_in_failed_text = 2131099684;
    public static final int common_google_play_services_sign_in_failed_title = 2131099685;
    public static final int common_google_play_services_unknown_issue = 2131099686;
    public static final int common_google_play_services_unsupported_text = 2131099687;
    public static final int common_google_play_services_unsupported_title = 2131099688;
    public static final int common_google_play_services_update_button = 2131099689;
    public static final int common_google_play_services_update_text = 2131099690;
    public static final int common_google_play_services_update_title = 2131099691;
    public static final int common_google_play_services_updating_text = 2131099692;
    public static final int common_google_play_services_updating_title = 2131099693;
    public static final int common_open_on_phone = 2131099694;
    public static final int create_calendar_message = 2131099700;
    public static final int create_calendar_title = 2131099701;
    public static final int decline = 2131099702;
    public static final int store_picture_message = 2131099703;
    public static final int store_picture_title = 2131099704;
  }

  public static final class style
  {
    public static final int Theme_IAPTheme = 2131230952;
  }

  public static final class styleable
  {
    public static final int[] AdsAttrs = { 2130771999, 2130772000, 2130772001 };
    public static final int AdsAttrs_adSize = 0;
    public static final int AdsAttrs_adSizes = 1;
    public static final int AdsAttrs_adUnitId = 2;
    public static final int[] LoadingImageView = { 2130772021, 2130772022, 2130772023 };
    public static final int LoadingImageView_circleCrop = 2;
    public static final int LoadingImageView_imageAspectRatio = 1;
    public static final int LoadingImageView_imageAspectRatioAdjust;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.R
 * JD-Core Version:    0.6.2
 */