package com.google.android.gms.ads.internal.overlay;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.client.zzb;
import com.google.android.gms.ads.internal.zzp;
import com.google.android.gms.internal.zzgr;
import com.google.android.gms.internal.zzid;

@zzgr
public class zza
{
  public boolean zza(Context paramContext, AdLauncherIntentInfoParcel paramAdLauncherIntentInfoParcel, zzn paramzzn)
  {
    if (paramAdLauncherIntentInfoParcel == null)
    {
      zzb.zzaH("No intent data for launcher overlay.");
      return false;
    }
    Intent localIntent = new Intent();
    if (TextUtils.isEmpty(paramAdLauncherIntentInfoParcel.url))
    {
      zzb.zzaH("Open GMSG did not contain a URL.");
      return false;
    }
    if (!TextUtils.isEmpty(paramAdLauncherIntentInfoParcel.mimeType))
      localIntent.setDataAndType(Uri.parse(paramAdLauncherIntentInfoParcel.url), paramAdLauncherIntentInfoParcel.mimeType);
    String[] arrayOfString;
    while (true)
    {
      localIntent.setAction("android.intent.action.VIEW");
      if (!TextUtils.isEmpty(paramAdLauncherIntentInfoParcel.packageName))
        localIntent.setPackage(paramAdLauncherIntentInfoParcel.packageName);
      if (TextUtils.isEmpty(paramAdLauncherIntentInfoParcel.zzAL))
        break label178;
      arrayOfString = paramAdLauncherIntentInfoParcel.zzAL.split("/", 2);
      if (arrayOfString.length >= 2)
        break;
      zzb.zzaH("Could not parse component name from open GMSG: " + paramAdLauncherIntentInfoParcel.zzAL);
      return false;
      localIntent.setData(Uri.parse(paramAdLauncherIntentInfoParcel.url));
    }
    localIntent.setClassName(arrayOfString[0], arrayOfString[1]);
    label178: String str = paramAdLauncherIntentInfoParcel.zzAM;
    if (!TextUtils.isEmpty(str));
    try
    {
      int j = Integer.parseInt(str);
      i = j;
      localIntent.addFlags(i);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      try
      {
        zzb.v("Launching an intent: " + localIntent.toURI());
        zzp.zzbv().zzb(paramContext, localIntent);
        if (paramzzn != null)
          paramzzn.zzaO();
        return true;
        localNumberFormatException = localNumberFormatException;
        zzb.zzaH("Could not parse intent flags.");
        int i = 0;
      }
      catch (ActivityNotFoundException localActivityNotFoundException)
      {
        zzb.zzaH(localActivityNotFoundException.getMessage());
      }
    }
    return false;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.internal.overlay.zza
 * JD-Core Version:    0.6.2
 */