package com.google.android.gms.ads.internal.client;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.formats.zzi;
import com.google.android.gms.internal.zzcw;
import com.google.android.gms.internal.zzcw.zza;
import com.google.android.gms.internal.zzcx;
import com.google.android.gms.internal.zzcx.zza;
import com.google.android.gms.internal.zzcy;
import com.google.android.gms.internal.zzcy.zza;
import com.google.android.gms.internal.zzcz;
import com.google.android.gms.internal.zzcz.zza;

public abstract interface zzq extends IInterface
{
  public abstract void zza(NativeAdOptionsParcel paramNativeAdOptionsParcel)
    throws RemoteException;

  public abstract void zza(zzcw paramzzcw)
    throws RemoteException;

  public abstract void zza(zzcx paramzzcx)
    throws RemoteException;

  public abstract void zza(String paramString, zzcz paramzzcz, zzcy paramzzcy)
    throws RemoteException;

  public abstract void zzb(zzo paramzzo)
    throws RemoteException;

  public abstract zzp zzbk()
    throws RemoteException;

  public static abstract class zza extends Binder
    implements zzq
  {
    public zza()
    {
      attachInterface(this, "com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
    }

    public static zzq zzi(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
      if ((localIInterface != null) && ((localIInterface instanceof zzq)))
        return (zzq)localIInterface;
      return new zza(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        return true;
      case 1:
        paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        zzp localzzp = zzbk();
        paramParcel2.writeNoException();
        IBinder localIBinder = null;
        if (localzzp != null)
          localIBinder = localzzp.asBinder();
        paramParcel2.writeStrongBinder(localIBinder);
        return true;
      case 2:
        paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        zzb(zzo.zza.zzg(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 3:
        paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        zza(zzcw.zza.zzz(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 4:
        paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        zza(zzcx.zza.zzA(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 5:
        paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
        zza(paramParcel1.readString(), zzcz.zza.zzC(paramParcel1.readStrongBinder()), zzcy.zza.zzB(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 6:
      }
      paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
      int i = paramParcel1.readInt();
      NativeAdOptionsParcel localNativeAdOptionsParcel = null;
      if (i != 0)
        localNativeAdOptionsParcel = NativeAdOptionsParcel.CREATOR.zze(paramParcel1);
      zza(localNativeAdOptionsParcel);
      paramParcel2.writeNoException();
      return true;
    }

    private static class zza
      implements zzq
    {
      private IBinder zznJ;

      zza(IBinder paramIBinder)
      {
        this.zznJ = paramIBinder;
      }

      public IBinder asBinder()
      {
        return this.zznJ;
      }

      public void zza(NativeAdOptionsParcel paramNativeAdOptionsParcel)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
          if (paramNativeAdOptionsParcel != null)
          {
            localParcel1.writeInt(1);
            paramNativeAdOptionsParcel.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.zznJ.transact(6, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void zza(zzcw paramzzcw)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
          if (paramzzcw != null);
          for (IBinder localIBinder = paramzzcw.asBinder(); ; localIBinder = null)
          {
            localParcel1.writeStrongBinder(localIBinder);
            this.zznJ.transact(3, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void zza(zzcx paramzzcx)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
          if (paramzzcx != null);
          for (IBinder localIBinder = paramzzcx.asBinder(); ; localIBinder = null)
          {
            localParcel1.writeStrongBinder(localIBinder);
            this.zznJ.transact(4, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void zza(String paramString, zzcz paramzzcz, zzcy paramzzcy)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
          localParcel1.writeString(paramString);
          if (paramzzcz != null);
          for (IBinder localIBinder1 = paramzzcz.asBinder(); ; localIBinder1 = null)
          {
            localParcel1.writeStrongBinder(localIBinder1);
            IBinder localIBinder2 = null;
            if (paramzzcy != null)
              localIBinder2 = paramzzcy.asBinder();
            localParcel1.writeStrongBinder(localIBinder2);
            this.zznJ.transact(5, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void zzb(zzo paramzzo)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
          if (paramzzo != null);
          for (IBinder localIBinder = paramzzo.asBinder(); ; localIBinder = null)
          {
            localParcel1.writeStrongBinder(localIBinder);
            this.zznJ.transact(2, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public zzp zzbk()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdLoaderBuilder");
          this.zznJ.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          zzp localzzp = zzp.zza.zzh(localParcel2.readStrongBinder());
          return localzzp;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.internal.client.zzq
 * JD-Core Version:    0.6.2
 */