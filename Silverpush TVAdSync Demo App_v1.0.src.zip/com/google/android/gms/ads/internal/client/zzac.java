package com.google.android.gms.ads.internal.client;

public class zzac
{
  public String getTrackingId()
  {
    return null;
  }

  public boolean isGoogleAnalyticsEnabled()
  {
    return false;
  }

  public void zzO(String paramString)
  {
  }

  public void zzk(boolean paramBoolean)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.internal.client.zzac
 * JD-Core Version:    0.6.2
 */