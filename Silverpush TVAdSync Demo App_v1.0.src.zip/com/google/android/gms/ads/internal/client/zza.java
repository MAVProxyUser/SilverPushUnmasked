package com.google.android.gms.ads.internal.client;

public abstract interface zza
{
  public abstract void onAdClicked();
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     com.google.android.gms.ads.internal.client.zza
 * JD-Core Version:    0.6.2
 */