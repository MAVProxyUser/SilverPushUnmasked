package android.support.v7.internal.transition;

import android.view.ViewGroup;

public class ActionBarTransition
{
  private static final boolean TRANSITIONS_ENABLED = false;
  private static final int TRANSITION_DURATION = 120;

  public static void beginDelayedTransition(ViewGroup paramViewGroup)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v7.internal.transition.ActionBarTransition
 * JD-Core Version:    0.6.2
 */