package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.internal.text.AllCapsTransformationMethod;
import android.support.v7.internal.widget.ThemeUtils;
import android.util.AttributeSet;
import android.widget.TextView;

class AppCompatTextHelper
{
  private static final int[] TEXT_APPEARANCE_ATTRS = arrayOfInt;
  private static final int[] VIEW_ATTRS = { 16842804 };
  private final TextView mView;

  static
  {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = R.attr.textAllCaps;
  }

  AppCompatTextHelper(TextView paramTextView)
  {
    this.mView = paramTextView;
  }

  void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt)
  {
    Context localContext = this.mView.getContext();
    TypedArray localTypedArray1 = localContext.obtainStyledAttributes(paramAttributeSet, VIEW_ATTRS, paramInt, 0);
    int i = localTypedArray1.getResourceId(0, -1);
    localTypedArray1.recycle();
    if (i != -1)
    {
      TypedArray localTypedArray3 = localContext.obtainStyledAttributes(i, R.styleable.TextAppearance);
      if (localTypedArray3.hasValue(R.styleable.TextAppearance_textAllCaps))
        setAllCaps(localTypedArray3.getBoolean(R.styleable.TextAppearance_textAllCaps, false));
      localTypedArray3.recycle();
    }
    TypedArray localTypedArray2 = localContext.obtainStyledAttributes(paramAttributeSet, TEXT_APPEARANCE_ATTRS, paramInt, 0);
    if (localTypedArray2.hasValue(0))
      setAllCaps(localTypedArray2.getBoolean(0, false));
    localTypedArray2.recycle();
    ColorStateList localColorStateList = this.mView.getTextColors();
    if ((localColorStateList != null) && (!localColorStateList.isStateful()))
      if (Build.VERSION.SDK_INT >= 21)
        break label173;
    label173: for (int j = ThemeUtils.getDisabledThemeAttrColor(localContext, 16842808); ; j = ThemeUtils.getThemeAttrColor(localContext, 16842808))
    {
      this.mView.setTextColor(ThemeUtils.createDisabledStateList(localColorStateList.getDefaultColor(), j));
      return;
    }
  }

  void onSetTextAppearance(Context paramContext, int paramInt)
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramInt, TEXT_APPEARANCE_ATTRS);
    if (localTypedArray.hasValue(0))
      setAllCaps(localTypedArray.getBoolean(0, false));
    localTypedArray.recycle();
  }

  void setAllCaps(boolean paramBoolean)
  {
    TextView localTextView = this.mView;
    if (paramBoolean);
    for (AllCapsTransformationMethod localAllCapsTransformationMethod = new AllCapsTransformationMethod(this.mView.getContext()); ; localAllCapsTransformationMethod = null)
    {
      localTextView.setTransformationMethod(localAllCapsTransformationMethod);
      return;
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v7.widget.AppCompatTextHelper
 * JD-Core Version:    0.6.2
 */