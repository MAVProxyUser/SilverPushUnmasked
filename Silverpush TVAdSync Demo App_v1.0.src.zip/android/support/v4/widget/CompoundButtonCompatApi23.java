package android.support.v4.widget;

import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

class CompoundButtonCompatApi23
{
  static Drawable getButtonDrawable(CompoundButton paramCompoundButton)
  {
    return paramCompoundButton.getButtonDrawable();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.widget.CompoundButtonCompatApi23
 * JD-Core Version:    0.6.2
 */