package android.support.v4.app;

import android.app.Activity;
import android.net.Uri;

class ActivityCompat22
{
  public static Uri getReferrer(Activity paramActivity)
  {
    return paramActivity.getReferrer();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.app.ActivityCompat22
 * JD-Core Version:    0.6.2
 */