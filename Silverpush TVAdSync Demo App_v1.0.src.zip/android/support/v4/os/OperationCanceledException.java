package android.support.v4.os;

public class OperationCanceledException extends RuntimeException
{
  public OperationCanceledException()
  {
    this(null);
  }

  public OperationCanceledException(String paramString)
  {
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.os.OperationCanceledException
 * JD-Core Version:    0.6.2
 */