package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatApi22
{
  public static Drawable wrapForTinting(Drawable paramDrawable)
  {
    return paramDrawable;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.graphics.drawable.DrawableCompatApi22
 * JD-Core Version:    0.6.2
 */