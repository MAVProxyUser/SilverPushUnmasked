package android.support.v4.text;

import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

public class ICUCompatApi23
{
  private static final String TAG = "ICUCompatIcs";
  private static Method sAddLikelySubtagsMethod;

  static
  {
    try
    {
      sAddLikelySubtagsMethod = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", new Class[] { Locale.class });
      return;
    }
    catch (Exception localException)
    {
      throw new IllegalStateException(localException);
    }
  }

  public static String maximizeAndGetScript(Locale paramLocale)
  {
    try
    {
      Object[] arrayOfObject = { paramLocale };
      String str = ((Locale)sAddLikelySubtagsMethod.invoke(null, arrayOfObject)).getScript();
      return str;
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      Log.w("ICUCompatIcs", localInvocationTargetException);
      return paramLocale.getScript();
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
        Log.w("ICUCompatIcs", localIllegalAccessException);
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.text.ICUCompatApi23
 * JD-Core Version:    0.6.2
 */