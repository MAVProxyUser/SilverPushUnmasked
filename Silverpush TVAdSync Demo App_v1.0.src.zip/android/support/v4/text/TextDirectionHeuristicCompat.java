package android.support.v4.text;

public abstract interface TextDirectionHeuristicCompat
{
  public abstract boolean isRtl(CharSequence paramCharSequence, int paramInt1, int paramInt2);

  public abstract boolean isRtl(char[] paramArrayOfChar, int paramInt1, int paramInt2);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.text.TextDirectionHeuristicCompat
 * JD-Core Version:    0.6.2
 */