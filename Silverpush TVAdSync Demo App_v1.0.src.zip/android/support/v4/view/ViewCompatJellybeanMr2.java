package android.support.v4.view;

import android.graphics.Rect;
import android.view.View;

class ViewCompatJellybeanMr2
{
  public static Rect getClipBounds(View paramView)
  {
    return paramView.getClipBounds();
  }

  public static void setClipBounds(View paramView, Rect paramRect)
  {
    paramView.setClipBounds(paramRect);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush TVAdSync Demo App_v1.0.jar
 * Qualified Name:     android.support.v4.view.ViewCompatJellybeanMr2
 * JD-Core Version:    0.6.2
 */