package com.silverpush.syncadsdemo;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.silverpush.syncadsdemo";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 2;
  public static final String VERSION_NAME = "1.0.1";
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     com.silverpush.syncadsdemo.BuildConfig
 * JD-Core Version:    0.6.2
 */