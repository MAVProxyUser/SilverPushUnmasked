package android.support.v4.app;

import android.app.ActivityManager;

class ActivityManagerCompatKitKat
{
  public static boolean isLowRamDevice(ActivityManager paramActivityManager)
  {
    return paramActivityManager.isLowRamDevice();
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     android.support.v4.app.ActivityManagerCompatKitKat
 * JD-Core Version:    0.6.2
 */