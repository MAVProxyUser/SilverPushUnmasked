package android.support.v4.app;

import android.text.Html;

class ShareCompatJB
{
  public static String escapeHtml(CharSequence paramCharSequence)
  {
    return Html.escapeHtml(paramCharSequence);
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     android.support.v4.app.ShareCompatJB
 * JD-Core Version:    0.6.2
 */