package android.support.v4.view;

import android.view.View;

public abstract interface ViewPropertyAnimatorUpdateListener
{
  public abstract void onAnimationUpdate(View paramView);
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     android.support.v4.view.ViewPropertyAnimatorUpdateListener
 * JD-Core Version:    0.6.2
 */