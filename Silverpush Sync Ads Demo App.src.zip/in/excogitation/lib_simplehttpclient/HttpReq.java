package in.excogitation.lib_simplehttpclient;

import android.os.AsyncTask;
import android.os.Build.VERSION;

public class HttpReq extends AsyncTask<HttpReqPkg, String, String>
{
  SHCResultsListener listener;
  private int resCode = 0;
  private String resMsg = "na";

  private void disableConnectionReuseIfNecessary()
  {
    if (Build.VERSION.SDK_INT < 8)
      System.setProperty("http.keepAlive", "false");
  }

  // ERROR //
  protected String doInBackground(HttpReqPkg[] paramArrayOfHttpReqPkg)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: iconst_0
    //   4: aaload
    //   5: invokevirtual 54	in/excogitation/lib_simplehttpclient/HttpReqPkg:getUsername	()Ljava/lang/String;
    //   8: astore_3
    //   9: aload_1
    //   10: iconst_0
    //   11: aaload
    //   12: invokevirtual 57	in/excogitation/lib_simplehttpclient/HttpReqPkg:getPassword	()Ljava/lang/String;
    //   15: astore 4
    //   17: aconst_null
    //   18: astore 5
    //   20: aload_3
    //   21: ifnull +51 -> 72
    //   24: aconst_null
    //   25: astore 5
    //   27: aload 4
    //   29: ifnull +43 -> 72
    //   32: new 59	java/lang/String
    //   35: dup
    //   36: new 61	java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial 62	java/lang/StringBuilder:<init>	()V
    //   43: aload_3
    //   44: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: ldc 68
    //   49: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: aload 4
    //   54: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   57: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   60: invokevirtual 75	java/lang/String:getBytes	()[B
    //   63: iconst_0
    //   64: invokestatic 81	android/util/Base64:encode	([BI)[B
    //   67: invokespecial 84	java/lang/String:<init>	([B)V
    //   70: astore 5
    //   72: aload_1
    //   73: iconst_0
    //   74: aaload
    //   75: invokevirtual 87	in/excogitation/lib_simplehttpclient/HttpReqPkg:getUri	()Ljava/lang/String;
    //   78: astore 6
    //   80: aload_1
    //   81: iconst_0
    //   82: aaload
    //   83: invokevirtual 90	in/excogitation/lib_simplehttpclient/HttpReqPkg:getMethod	()Ljava/lang/String;
    //   86: ldc 92
    //   88: invokevirtual 96	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   91: ifeq +34 -> 125
    //   94: new 61	java/lang/StringBuilder
    //   97: dup
    //   98: invokespecial 62	java/lang/StringBuilder:<init>	()V
    //   101: aload 6
    //   103: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: ldc 98
    //   108: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: aload_1
    //   112: iconst_0
    //   113: aaload
    //   114: invokevirtual 101	in/excogitation/lib_simplehttpclient/HttpReqPkg:getEncodedParams	()Ljava/lang/String;
    //   117: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   123: astore 6
    //   125: new 103	java/net/URL
    //   128: dup
    //   129: aload 6
    //   131: invokespecial 106	java/net/URL:<init>	(Ljava/lang/String;)V
    //   134: astore 7
    //   136: aload 7
    //   138: invokevirtual 110	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   141: checkcast 112	java/net/HttpURLConnection
    //   144: astore 13
    //   146: aload 5
    //   148: ifnull +30 -> 178
    //   151: aload 13
    //   153: ldc 114
    //   155: new 61	java/lang/StringBuilder
    //   158: dup
    //   159: invokespecial 62	java/lang/StringBuilder:<init>	()V
    //   162: ldc 116
    //   164: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: aload 5
    //   169: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   175: invokevirtual 120	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   178: aload_1
    //   179: iconst_0
    //   180: aaload
    //   181: invokevirtual 90	in/excogitation/lib_simplehttpclient/HttpReqPkg:getMethod	()Ljava/lang/String;
    //   184: ldc 122
    //   186: invokevirtual 96	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   189: ifeq +16 -> 205
    //   192: aload 13
    //   194: ldc 122
    //   196: invokevirtual 125	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   199: aload 13
    //   201: iconst_1
    //   202: invokevirtual 129	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   205: aload 13
    //   207: sipush 10000
    //   210: invokevirtual 133	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   213: aload 13
    //   215: sipush 10000
    //   218: invokevirtual 136	java/net/HttpURLConnection:setReadTimeout	(I)V
    //   221: aload 13
    //   223: ldc 138
    //   225: ldc 140
    //   227: invokevirtual 120	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   230: aload 13
    //   232: invokevirtual 143	java/net/HttpURLConnection:connect	()V
    //   235: aload_1
    //   236: iconst_0
    //   237: aaload
    //   238: invokevirtual 90	in/excogitation/lib_simplehttpclient/HttpReqPkg:getMethod	()Ljava/lang/String;
    //   241: ldc 122
    //   243: invokevirtual 96	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   246: istore 14
    //   248: aconst_null
    //   249: astore_2
    //   250: iload 14
    //   252: ifeq +38 -> 290
    //   255: new 145	java/io/OutputStreamWriter
    //   258: dup
    //   259: aload 13
    //   261: invokevirtual 149	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   264: invokespecial 152	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   267: astore 15
    //   269: aload 15
    //   271: aload_1
    //   272: iconst_0
    //   273: aaload
    //   274: invokevirtual 101	in/excogitation/lib_simplehttpclient/HttpReqPkg:getEncodedParams	()Ljava/lang/String;
    //   277: invokevirtual 155	java/io/OutputStreamWriter:write	(Ljava/lang/String;)V
    //   280: aload 15
    //   282: invokevirtual 158	java/io/OutputStreamWriter:flush	()V
    //   285: aload 15
    //   287: invokevirtual 161	java/io/OutputStreamWriter:close	()V
    //   290: aload_0
    //   291: aload 13
    //   293: invokevirtual 165	java/net/HttpURLConnection:getResponseCode	()I
    //   296: putfield 17	in/excogitation/lib_simplehttpclient/HttpReq:resCode	I
    //   299: aload_0
    //   300: aload 13
    //   302: invokevirtual 168	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
    //   305: putfield 21	in/excogitation/lib_simplehttpclient/HttpReq:resMsg	Ljava/lang/String;
    //   308: aload_0
    //   309: getfield 17	in/excogitation/lib_simplehttpclient/HttpReq:resCode	I
    //   312: istore 16
    //   314: aconst_null
    //   315: astore_2
    //   316: iload 16
    //   318: sipush 400
    //   321: if_icmplt +112 -> 433
    //   324: aload 13
    //   326: invokevirtual 172	java/net/HttpURLConnection:getErrorStream	()Ljava/io/InputStream;
    //   329: astore 17
    //   331: new 174	java/io/InputStreamReader
    //   334: dup
    //   335: aload 17
    //   337: invokespecial 177	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   340: astore 18
    //   342: new 179	java/io/BufferedReader
    //   345: dup
    //   346: aload 18
    //   348: invokespecial 182	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   351: astore 19
    //   353: new 61	java/lang/StringBuilder
    //   356: dup
    //   357: invokespecial 62	java/lang/StringBuilder:<init>	()V
    //   360: astore 20
    //   362: aload 19
    //   364: invokevirtual 185	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   367: astore 21
    //   369: aload 21
    //   371: ifnull +76 -> 447
    //   374: aload 20
    //   376: new 61	java/lang/StringBuilder
    //   379: dup
    //   380: invokespecial 62	java/lang/StringBuilder:<init>	()V
    //   383: aload 21
    //   385: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   388: ldc 187
    //   390: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   393: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   396: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   399: pop
    //   400: goto -38 -> 362
    //   403: astore 8
    //   405: aload 19
    //   407: astore_2
    //   408: aload 8
    //   410: invokevirtual 190	java/lang/Exception:printStackTrace	()V
    //   413: aload 8
    //   415: athrow
    //   416: astore 11
    //   418: aload 11
    //   420: invokevirtual 191	java/io/IOException:printStackTrace	()V
    //   423: aload_2
    //   424: ifnull +7 -> 431
    //   427: aload_2
    //   428: invokevirtual 192	java/io/BufferedReader:close	()V
    //   431: aconst_null
    //   432: areturn
    //   433: aload 13
    //   435: invokevirtual 195	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   438: astore 26
    //   440: aload 26
    //   442: astore 17
    //   444: goto -113 -> 331
    //   447: aload 20
    //   449: aload_0
    //   450: getfield 17	in/excogitation/lib_simplehttpclient/HttpReq:resCode	I
    //   453: invokevirtual 198	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   456: ldc 200
    //   458: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   461: aload_0
    //   462: getfield 21	in/excogitation/lib_simplehttpclient/HttpReq:resMsg	Ljava/lang/String;
    //   465: invokevirtual 66	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   468: pop
    //   469: aload 20
    //   471: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   474: astore 24
    //   476: aload 19
    //   478: ifnull +8 -> 486
    //   481: aload 19
    //   483: invokevirtual 192	java/io/BufferedReader:close	()V
    //   486: aload 24
    //   488: areturn
    //   489: astore 25
    //   491: aload 25
    //   493: invokevirtual 191	java/io/IOException:printStackTrace	()V
    //   496: goto -10 -> 486
    //   499: astore 12
    //   501: aload 12
    //   503: invokevirtual 191	java/io/IOException:printStackTrace	()V
    //   506: goto -75 -> 431
    //   509: astore 9
    //   511: aload_2
    //   512: ifnull +7 -> 519
    //   515: aload_2
    //   516: invokevirtual 192	java/io/BufferedReader:close	()V
    //   519: aload 9
    //   521: athrow
    //   522: astore 10
    //   524: aload 10
    //   526: invokevirtual 191	java/io/IOException:printStackTrace	()V
    //   529: goto -10 -> 519
    //   532: astore 9
    //   534: aload 19
    //   536: astore_2
    //   537: goto -26 -> 511
    //   540: astore 8
    //   542: aconst_null
    //   543: astore_2
    //   544: goto -136 -> 408
    //
    // Exception table:
    //   from	to	target	type
    //   353	362	403	java/lang/Exception
    //   362	369	403	java/lang/Exception
    //   374	400	403	java/lang/Exception
    //   447	476	403	java/lang/Exception
    //   413	416	416	java/io/IOException
    //   481	486	489	java/io/IOException
    //   427	431	499	java/io/IOException
    //   125	146	509	finally
    //   151	178	509	finally
    //   178	205	509	finally
    //   205	248	509	finally
    //   255	290	509	finally
    //   290	314	509	finally
    //   324	331	509	finally
    //   331	353	509	finally
    //   408	413	509	finally
    //   413	416	509	finally
    //   418	423	509	finally
    //   433	440	509	finally
    //   515	519	522	java/io/IOException
    //   353	362	532	finally
    //   362	369	532	finally
    //   374	400	532	finally
    //   447	476	532	finally
    //   125	146	540	java/lang/Exception
    //   151	178	540	java/lang/Exception
    //   178	205	540	java/lang/Exception
    //   205	248	540	java/lang/Exception
    //   255	290	540	java/lang/Exception
    //   290	314	540	java/lang/Exception
    //   324	331	540	java/lang/Exception
    //   331	353	540	java/lang/Exception
    //   433	440	540	java/lang/Exception
  }

  protected void onPostExecute(String paramString)
  {
    if (this.listener != null)
    {
      if (paramString != null)
        this.listener.onSuccess(paramString);
    }
    else
      return;
    this.listener.onFailure(Integer.toString(this.resCode) + " : " + this.resMsg);
  }

  protected void onPreExecute()
  {
    disableConnectionReuseIfNecessary();
  }

  public void setOnResultsListener(SHCResultsListener paramSHCResultsListener)
  {
    this.listener = paramSHCResultsListener;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     in.excogitation.lib_simplehttpclient.HttpReq
 * JD-Core Version:    0.6.2
 */