package in.excogitation.lib_simplehttpclient;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import java.io.PrintStream;
import java.util.HashMap;

public class SimpleHttpClient
{
  public static final int METHOD_GET = 0;
  public static final int METHOD_POST = 1;
  public static final int MODE_PARALLEL = 3;
  public static final int MODE_SEQ = 2;
  private int method;
  private int mode;
  private HashMap<String, String> params = new HashMap();
  private String uriHandle;
  private String url;

  public SimpleHttpClient()
  {
    setMode(2);
    setMethod(0);
    setUrl("http://google.com/");
  }

  @TargetApi(11)
  private static void ParallelAsyncTask(HttpReq paramHttpReq, HttpReqPkg paramHttpReqPkg, SHCResultsListener paramSHCResultsListener)
  {
    paramHttpReq.setOnResultsListener(paramSHCResultsListener);
    if (Build.VERSION.SDK_INT >= 11)
    {
      paramHttpReq.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new HttpReqPkg[] { paramHttpReqPkg });
      return;
    }
    paramHttpReq.execute(new HttpReqPkg[] { paramHttpReqPkg });
  }

  private static void SeqAsyncTask(HttpReq paramHttpReq, HttpReqPkg paramHttpReqPkg, SHCResultsListener paramSHCResultsListener)
  {
    paramHttpReq.setOnResultsListener(paramSHCResultsListener);
    paramHttpReq.execute(new HttpReqPkg[] { paramHttpReqPkg });
  }

  private static boolean isOnline(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
    return (localNetworkInfo != null) && (localNetworkInfo.isConnected());
  }

  public int getMethod()
  {
    return this.method;
  }

  public int getMode()
  {
    return this.mode;
  }

  public HashMap<String, String> getParams()
  {
    return this.params;
  }

  public String getUrl()
  {
    return this.url;
  }

  public void makeRequest(Context paramContext, SHCResultsListener paramSHCResultsListener)
  {
    HttpReqPkg localHttpReqPkg = new HttpReqPkg();
    if (this.method == 0)
    {
      localHttpReqPkg.setMethod("GET");
      System.out.println("GET Req");
    }
    do
      while (true)
      {
        localHttpReqPkg.setParams(this.params);
        localHttpReqPkg.setUri(this.url);
        if (!isOnline(paramContext))
          break label119;
        if (this.mode != 2)
          break;
        SeqAsyncTask(new HttpReq(), localHttpReqPkg, paramSHCResultsListener);
        return;
        if (this.method == 1)
        {
          localHttpReqPkg.setMethod("POST");
          System.out.println("POST Req");
        }
      }
    while (this.mode != 3);
    ParallelAsyncTask(new HttpReq(), localHttpReqPkg, paramSHCResultsListener);
    return;
    label119: System.out.println("Not connected to internet ! No request made !");
  }

  public void setMethod(int paramInt)
  {
    this.method = paramInt;
  }

  public void setMode(int paramInt)
  {
    this.mode = paramInt;
  }

  public void setParams(HashMap<String, String> paramHashMap)
  {
    this.params = paramHashMap;
  }

  public void setUrl(String paramString)
  {
    this.url = paramString;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     in.excogitation.lib_simplehttpclient.SimpleHttpClient
 * JD-Core Version:    0.6.2
 */