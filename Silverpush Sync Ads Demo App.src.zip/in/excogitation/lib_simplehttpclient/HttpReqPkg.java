package in.excogitation.lib_simplehttpclient;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HttpReqPkg
{
  private String method = "GET";
  private Map<String, String> params = new HashMap();
  private String password = null;
  private String uri;
  private String username = null;

  public String getEncodedParams()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Object localObject = null;
    Iterator localIterator = this.params.keySet().iterator();
    while (true)
      if (localIterator.hasNext())
      {
        String str1 = (String)localIterator.next();
        try
        {
          String str2 = URLEncoder.encode((String)this.params.get(str1), "UTF-8");
          localObject = str2;
          if (localStringBuilder.length() > 0)
            localStringBuilder.append("&");
          localStringBuilder.append(str1 + "=" + localObject);
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          while (true)
            localUnsupportedEncodingException.printStackTrace();
        }
      }
    return localStringBuilder.toString();
  }

  public String getMethod()
  {
    return this.method;
  }

  public Map<String, String> getParams()
  {
    return this.params;
  }

  String getPassword()
  {
    return this.uri;
  }

  public String getUri()
  {
    return this.uri;
  }

  public String getUsername()
  {
    return this.username;
  }

  public void setMethod(String paramString)
  {
    this.method = paramString;
  }

  public void setParam(String paramString1, String paramString2)
  {
    this.params.put(paramString1, paramString2);
  }

  public void setParams(Map<String, String> paramMap)
  {
    this.params = paramMap;
  }

  public void setPassword(String paramString)
  {
    this.password = paramString;
  }

  public void setUri(String paramString)
  {
    this.uri = paramString;
  }

  public void setUsername(String paramString)
  {
    this.username = paramString;
  }
}

/* Location:           /Users/kfinisterre/Desktop/SilverPush/Silverpush Sync Ads Demo App.jar
 * Qualified Name:     in.excogitation.lib_simplehttpclient.HttpReqPkg
 * JD-Core Version:    0.6.2
 */